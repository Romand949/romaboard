package com.byhas.aikeyboard

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.HorizontalScrollView
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.ContextWrapper
import android.view.inputmethod.InputConnection
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class KeyboardController(base: Context, private val host: Host) : ContextWrapper(base) {
    interface Host {
        val overlay: Boolean
        fun ic(): InputConnection?
        fun editorAction(): Boolean
        fun rebuild()
        fun stopPermanent()
        fun collapse()
        fun hideIme()
        fun startPermanentMode() {}
        val minimized: Boolean get() = false
        fun restore() {}
        /** Sembunyikan keyboard sebentar saat membaca layar, lalu munculkan lagi. */
        fun hideForCapture() {}
        fun showAfterCapture() {}
    }

    private val currentInputConnection: InputConnection? get() = host.ic()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var th: KbTheme
    private lateinit var audio: AudioManager
    private var buildSig = ""
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var sugg: LinearLayout
    private var mode = "letters"
    private var shift = false
    private var caps = false
    private var lastShift = 0L
    private val clips = ArrayList<String>()
    private val pins = ArrayList<String>()
    private var trDone = false
    private var screenCtx = ""
    private var promptMode = false
    private val buf = StringBuilder()
    private var promptView: TextView? = null
    private var promptScroll: ScrollView? = null
    private var aiAnswer: String? = null
    private var aiSel: String = ""
    private var emojiTab = 1
    private val recent = ArrayList<String>()
    private val wordFreq = HashMap<String, Int>()
    private var rec: SpeechRecognizer? = null
    private var listening = false
    private var lastKey = ""
    private var rootView: View? = null
    private var lastSugg = ""
    private var pulse: ObjectAnimator? = null

    private val builtIn = ("yang dan di ke dari untuk dengan tidak ini itu saya aku kamu kita kami mereka adalah akan sudah belum bisa boleh mau ingin " +
        "tolong terima kasih maaf selamat pagi siang sore malam apa siapa kapan dimana kenapa bagaimana berapa besok kemarin sekarang nanti tadi " +
        "hari minggu bulan tahun jam menit rumah kerja sekolah makan minum tidur pergi pulang datang lihat dengar bicara telepon pesan kirim " +
        "baik buruk bagus senang sedih capek lapar haus sibuk santai teman keluarga orang anak bapak ibu kakak adik sama juga lagi masih sangat " +
        "sekali banget aja dong deh nih sih oke siap gimana kalau kalo tapi karena jadi supaya atau jika maka saat ketika sebelum sesudah setelah " +
        "dalam pada oleh bahwa hanya semua setiap beberapa banyak sedikit lebih kurang paling assalamualaikum waalaikumsalam " +
        "hello thanks please sorry good morning night today tomorrow yesterday because about would could should with from have this that what when where which").split(" ")

    private val emojiGroups = listOf(
        "😀" to listOf("😀","😃","😄","😁","😆","😅","😂","🤣","😊","😇","🙂","😉","😍","🥰","😘","😋","😜","🤪","😎","🤩","🥳","😏","😒","🙄","😬","😔","😢","😭","😤","😡","🤯","😱","🥺","😴","🤔","🤭","🤗","😶","🫠","🤝"),
        "👍" to listOf("👍","👎","👏","🙌","🙏","💪","👌","✌️","🤞","🤟","👋","🤙","👀","💋","❤️","🧡","💛","💚","💙","💜","🖤","🤍","💔","💕","💖","💯","🔥","✨","⭐","🎉","🎁","✅","❌","⚡","💥","💤"),
        "🐶" to listOf("🐶","🐱","🐭","🐰","🦊","🐻","🐼","🦁","🐯","🐸","🐵","🐔","🐧","🦅","🐢","🐍","🐬","🐳","🦋","🌹","🌸","🌞","🌙","🌈","🍕","🍔","🍟","🍜","🍣","🍩","🍰","🍫","☕","🍺","🍹","🥤"),
        "⚽" to listOf("⚽","🏀","🏈","🎮","🎵","🎧","🎤","🎬","📷","📱","💻","⌚","🚗","🏍️","✈️","🚀","🏠","🏫","💰","💳","📚","✏️","🔒","🔑","💡","🕌","⛅","🌍","🎂","🏆","🥇","🎯"),
        "(ツ)" to listOf("¯\\_(ツ)_/¯", "(╯°□°)╯︵ ┻━┻", "ʕ•ᴥ•ʔ", "(づ｡◕‿‿◕｡)づ", "(≧▽≦)", "(｡•́︿•̀｡)", "( ͡° ͜ʖ ͡°)", "ᕕ( ᐛ )ᕗ", "(ง •̀_•́)ง", "(✿◠‿◠)", "(¬_¬)", "(ノ◕ヮ◕)ノ*:･ﾟ✧")
    )

    fun create() {
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        recent.addAll(Prefs.recent(this).split(" ").filter { it.isNotBlank() })
        loadWords()
        pins.addAll(Stash.pins(this))
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank() && !pins.contains(t)) { clips.remove(t); clips.add(0, t); if (clips.size > 30) clips.removeAt(30) }
        }
    }

    fun finishInput() { saveWords() }

    fun playAppear() {
        val r = rootView ?: return
        KeyAnim.appear(r, Prefs.animAppear(this), Prefs.animSpeed(this) / 100f, resources.displayMetrics.density)
    }

    fun startInput() {
        if (buildSig != sig()) host.rebuild()
        mode = "letters"; shift = false; caps = false
        promptMode = false; buf.setLength(0); aiAnswer = null; screenCtx = ""
        render()
        autoShift()
    }

    private fun sig() = Prefs.appearanceSig(this)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- words ----------
    private fun loadWords() {
        Prefs.words(this).split("\n").forEach { l ->
            val p = l.split("\t")
            if (p.size == 2) {
                val n = p[1].toIntOrNull()
                if (n != null) wordFreq[p[0]] = n
            }
        }
    }

    private fun saveWords() {
        val top = wordFreq.entries.sortedByDescending { it.value }.take(400)
        Prefs.setWords(this, top.joinToString("\n") { it.key + "\t" + it.value })
    }

    private fun curWord(): String {
        val b = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString() ?: return ""
        var i = b.length
        while (i > 0 && (b[i - 1].isLetter() || b[i - 1] == '\'')) i--
        return b.substring(i)
    }

    private fun updateSuggestions() {
        if (!::sugg.isInitialized) return
        sugg.removeAllViews()
        if (!Prefs.suggest(this) || promptMode || mode != "letters") { sugg.visibility = View.GONE; return }
        sugg.visibility = View.VISIBLE
        val w = curWord()
        val lw = w.lowercase()
        val list = if (lw.isEmpty()) emptyList() else
            (builtIn + wordFreq.keys).filter { it.startsWith(lw) && it != lw }.distinct()
                .sortedWith(compareByDescending<String> { wordFreq[it] ?: 0 }.thenBy { it.length }).take(3)
        val sk = list.joinToString("|")
        val changed = sk != lastSugg
        lastSugg = sk
        for (s in list) {
            val shown = if (w.isNotEmpty() && w[0].isUpperCase()) s.replaceFirstChar { it.uppercase() } else s
            val c = chip(shown) { applySuggestion(w, shown) }
            if (changed) { c.alpha = 0f; c.animate().alpha(1f).setDuration(120).start() }
            sugg.addView(c)
        }
        if (list.isEmpty()) {
            val sp = View(this)
            sp.layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f)
            sugg.addView(sp)
        }
    }

    private fun applySuggestion(w: String, s: String) {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText("$s ", 1)
        val l = s.lowercase()
        wordFreq[l] = (wordFreq[l] ?: 0) + 1
        autoShift()
        updateSuggestions()
    }

    // ---------- views ----------
    var miniIcon: View? = null

    /** Tampilan saat keyboard permanen diperkecil: hanya satu ikon bulat yang bisa digeser. Ketuk untuk membuka lagi. */
    private fun buildMini(): View {
        val dm = resources.displayMetrics
        val size = dp(50)
        val w = dm.widthPixels
        val hh = (dm.heightPixels * 0.85f).toInt().coerceAtLeast(size + dp(20))
        val frame = android.widget.FrameLayout(this)
        frame.layoutParams = android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, hh)
        val ic = View(this)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(th.accent)
        circle.setStroke(dp(2), th.bg)
        val ink = if (androidx.core.graphics.ColorUtils.calculateLuminance(th.accent) > 0.5) Color.BLACK else Color.WHITE
        ic.background = android.graphics.drawable.LayerDrawable(arrayOf(circle, IconDrawable("keyboard", ink, dp(26).toFloat())))
        ic.elevation = dp(8).toFloat()
        val lp = android.widget.FrameLayout.LayoutParams(size, size)
        lp.leftMargin = (Prefs.miniFx(this) * (w - size)).toInt()
        lp.topMargin = (Prefs.miniFy(this) * (hh - size)).toInt()
        ic.layoutParams = lp
        var dx0 = 0f; var dy0 = 0f; var l0 = 0; var t0 = 0; var moved = false
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        ic.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx0 = e.rawX; dy0 = e.rawY; l0 = lp.leftMargin; t0 = lp.topMargin; moved = false
                    v.animate().cancel(); v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - dx0; val dy = e.rawY - dy0
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                        moved = true
                        v.animate().cancel(); v.animate().scaleX(1.18f).scaleY(1.18f).alpha(0.85f).setDuration(100).start()
                    }
                    if (moved) {
                        lp.leftMargin = (l0 + dx).toInt().coerceIn(0, w - size)
                        lp.topMargin = (t0 + dy).toInt().coerceIn(0, hh - size)
                        v.layoutParams = lp
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.animate().cancel(); v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).setInterpolator(OvershootInterpolator(2f)).start()
                    if (moved) Prefs.setMiniPos(this, lp.leftMargin.toFloat() / (w - size), lp.topMargin.toFloat() / (hh - size))
                    else { feedback(v); host.restore() }
                }
                MotionEvent.ACTION_CANCEL -> { v.animate().cancel(); v.scaleX = 1f; v.scaleY = 1f; v.alpha = 1f }
            }
            true
        }
        frame.addView(ic)
        miniIcon = ic
        rootView = frame
        return frame
    }

    fun build(): View {
        th = Prefs.currentTheme(this)
        buildSig = sig()
        if (host.minimized && host.overlay) return buildMini()
        miniIcon = null
        val root = LinearLayout(this)
        rootView = root
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(th.bg)
        val hand = Prefs.hand(this)
        val extra = (resources.displayMetrics.widthPixels * 0.2f).toInt()
        val sp0 = Prefs.sidePad(this)
        root.setPadding(dp(sp0) + (if (hand == 2) extra else 0), dp(Prefs.topPad(this)), dp(sp0) + (if (hand == 1) extra else 0), dp(Prefs.bottomPad(this)))

        val bar = row()
        for (id in Prefs.toolbarOrder(this)) for (v in toolbarViews(id)) bar.addView(v)
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(bar)
        root.addView(hs)

        status = TextView(this)
        status.setTextColor(th.accent)
        status.textSize = 12f
        status.setPadding(dp(8), 0, dp(8), 0)
        status.visibility = View.GONE
        root.addView(status)

        sugg = LinearLayout(this)
        sugg.orientation = LinearLayout.HORIZONTAL
        root.addView(sugg)

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        root.addView(body)
        render()
        return root
    }

    private fun say(s: String?, busy: Boolean = false) {
        pulse?.cancel(); pulse = null
        status.animate().cancel()
        if (s == null) { status.visibility = View.GONE; status.alpha = 1f; return }
        val wasHidden = status.visibility != View.VISIBLE
        status.text = s
        status.visibility = View.VISIBLE
        status.alpha = 1f
        if (wasHidden) { status.alpha = 0f; status.animate().alpha(1f).setDuration(150).start() }
        if (busy) {
            val p = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.35f)
            p.duration = 700
            p.repeatMode = ValueAnimator.REVERSE
            p.repeatCount = ValueAnimator.INFINITE
            p.startDelay = 200
            p.start()
            pulse = p
        }
    }

    private fun pressAnim(v: View, down: Boolean, x: Float = v.width / 2f, y: Float = v.height / 2f) {
        KeyAnim.press(v, down, Prefs.animPress(this), Prefs.animSpeed(this) / 100f, x, y)
    }

    private fun release(bg: GradientDrawable, normal: Int) {
        val a = ValueAnimator.ofObject(ArgbEvaluator(), th.accent, normal)
        a.duration = (200 / (Prefs.animSpeed(this) / 100f)).toLong()
        a.addUpdateListener { bg.setColor(it.animatedValue as Int) }
        a.start()
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun feedback(v: View) {
        if (Prefs.haptic(this)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (Prefs.sound(this)) audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
    }

    private fun chip(label: String, onTap: () -> Unit): TextView {
        val t = TextView(this)
        val rip = Prefs.animPress(this) == KeyAnim.RIPPLE
        var iconKind: String? = null
        var shown = label
        if (label.startsWith("@")) {
            val sp = label.indexOf(' ')
            iconKind = if (sp < 0) label.substring(1) else label.substring(1, sp)
            shown = if (sp < 0) "" else label.substring(sp + 1)
        }
        t.text = shown
        t.gravity = Gravity.CENTER
        t.textSize = 15f * Prefs.fontScale(this) / 100f
        t.typeface = Prefs.typeface(this)
        t.maxLines = 1
        t.setTextColor(th.text)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(Prefs.radius(this)).toFloat()
        bg.setColor(th.fn)
        t.background = bg
        val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        t.layoutParams = lp
        t.setOnClickListener { feedback(t); onTap() }
        return t
    }

    private fun btn(label: String, w: Float = 1f, special: Boolean = false, size: Float = 18f, fast: Boolean = false, tint: Int? = null, onClick: () -> Unit): TextView {
        val t = TextView(this)
        val rip = Prefs.animPress(this) == KeyAnim.RIPPLE
        var iconKind: String? = null
        var shown = label
        if (label.startsWith("@")) {
            val sp = label.indexOf(' ')
            iconKind = if (sp < 0) label.substring(1) else label.substring(1, sp)
            shown = if (sp < 0) "" else label.substring(sp + 1)
        }
        t.text = shown
        t.gravity = Gravity.CENTER
        t.textSize = size * Prefs.fontScale(this) / 100f
        t.typeface = Prefs.typeface(this)
        t.maxLines = 1
        t.setTextColor(th.text)
        val normal = tint ?: (if (special) th.fn else th.key)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(Prefs.radius(this)).toFloat()
        bg.setColor(normal)
        bg.alpha = Prefs.keyAlpha(this) * 255 / 100
        // Jarak visual antar tombol dibuat lewat inset, bukan margin, supaya tidak ada celah mati
        // yang bikin ketukan meleset (penyebab typo).
        val inset = android.graphics.drawable.InsetDrawable(bg, dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)))
        if (iconKind != null) {
            val ink = if (tint != null && androidx.core.graphics.ColorUtils.calculateLuminance(tint) > 0.5) Color.BLACK
                      else if (tint != null) Color.WHITE else th.text
            val withText = shown.isNotEmpty()
            val isz = if (withText) dp(18).toFloat() else 0f
            val gap = if (withText) dp(6).toFloat() else 0f
            if (withText) t.setPadding((isz + gap).toInt(), 0, 0, 0)
            t.setTextColor(ink)
            t.background = android.graphics.drawable.LayerDrawable(arrayOf(inset, IconDrawable(iconKind, ink, isz, if (withText) t else null, gap)))
        } else {
            t.background = inset
        }
        if (rip) t.background = KeyAnim.ripple(t.background, dp(Prefs.radius(this)).toFloat(), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), th.accent)
        val lp = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), w)
        t.layoutParams = lp
        if (fast) {
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { if (!rip) bg.setColor(th.accent); pressAnim(v, true, e.x, e.y); feedback(v); onClick() }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressAnim(v, false); if (!rip) release(bg, normal) }
                }
                true
            }
        } else {
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { if (!rip) bg.setColor(th.accent); pressAnim(v, true, e.x, e.y) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressAnim(v, false); if (!rip) release(bg, normal) }
                }
                false
            }
            t.setOnClickListener { feedback(t); onClick() }
        }
        return t
    }

    private fun backspace(w: Float): TextView {
        val t = btn("@back", w, true) {}
        val rep = object : Runnable {
            override fun run() { del(); main.postDelayed(this, 55) }
        }
        t.setOnClickListener(null)
        t.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { pressAnim(v, true, e.x, e.y); feedback(v); del(); main.postDelayed(rep, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressAnim(v, false); main.removeCallbacks(rep) }
            }
            true
        }
        return t
    }

    // ---------- input ----------
    private fun del() {
        trDone = false
        if (promptMode) {
            if (buf.isNotEmpty()) buf.setLength(buf.offsetByCodePoints(buf.length, -1))
            updatePrompt(); return
        }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
        updateSuggestions()
    }

    private fun type(s: String) {
        trDone = false
        if (promptMode) { buf.append(s); updatePrompt(); return }
        currentInputConnection?.commitText(s, 1)
        updateSuggestions()
    }

    private fun typeEmoji(e: String) {
        type(e)
        recent.remove(e); recent.add(0, e)
        while (recent.size > 24) recent.removeAt(recent.size - 1)
        Prefs.setRecent(this, recent.joinToString(" "))
    }

    private fun enter() {
        if (promptMode) { sendPrompt(); return }
        val ic = currentInputConnection ?: return
        if (Stash.autoTr(this)) {
            if (trDone) trDone = false
            else if (translateBeforeSend()) return
        }
        if (!host.editorAction()) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        main.postDelayed({ autoShift(); updateSuggestions() }, 60)
    }

    private fun spaceTap() {
        if (promptMode) { buf.append(" "); updatePrompt(); return }
        val ic = currentInputConnection ?: return
        val w = curWord().lowercase()
        if (w.length >= 2) {
            val hit = snipList().firstOrNull { it.first.isNotEmpty() && it.first.equals(w, true) }
            if (hit != null) {
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(hit.second + " ", 1)
                autoShift(); updateSuggestions()
                return
            }
            wordFreq[w] = (wordFreq[w] ?: 0) + 1
        }
        val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (Prefs.dblSpace(this) && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
        } else ic.commitText(" ", 1)
        autoShift()
        updateSuggestions()
    }

    private fun autoShift() {
        if (promptMode) return
        if (!Prefs.autoCap(this) || mode != "letters" || caps) return
        val b = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        val want = b.isEmpty() || b.endsWith(". ") || b.endsWith("! ") || b.endsWith("? ") || b.endsWith("\n")
        if (want != shift) { shift = want; render() }
    }

    private fun key(code: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun switchKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun toolbarViews(id: String): List<View> = when (id) {
        "pin" -> if (host.overlay) {
            val st = tb("@stop STOP", Color.parseColor("#D32F2F")) { host.stopPermanent() }
            st.setTextColor(Color.WHITE)
            st.layoutParams = LinearLayout.LayoutParams(dp(Prefs.tbW(this) + 16), dp(Prefs.tbH(this))).also { it.setMargins(dp(2), dp(2), dp(2), dp(2)) }
            listOf(st, tb("@down") { host.collapse() })
        } else listOf(tb("@pin") { startPermanent() })
        "abc" -> listOf(tb("ABC", if (mode == "letters") th.accent else null) { mode = "letters"; render() })
        "ai" -> listOf(tb("@sparkle", if (mode == "ai" || mode == "hist") th.accent else null) { mode = "ai"; render() })
        "emoji" -> listOf(tb("@smile", if (mode == "emoji") th.accent else null) { mode = "emoji"; render() })
        "style" -> listOf(tb("Aa", if (mode == "style") th.accent else null) { mode = "style"; render() })
        "snip" -> listOf(tb("@bolt", if (mode == "snip") th.accent else null) { mode = "snip"; render() })
        "clip" -> listOf(tb("@clip", if (mode == "clip") th.accent else null) { mode = "clip"; render() })
        "mic" -> listOf(tb("@mic") { startVoice() })
        "read" -> listOf(tb("@read") { readScreen() })
        "swap" -> listOf(tb("@swap") {
            Prefs.setHand(this, (Prefs.hand(this) + 1) % 3)
            host.rebuild()
        })
        "gear" -> listOf(tb("@gear") {
            val i = Intent(this, SettingsActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        else -> emptyList()
    }

    private fun render() {
        body.removeAllViews()
        say(null)
        when (mode) {
            "letters" -> letters()
            "symbols" -> symbols()
            "emoji" -> emoji()
            "clip" -> clipboard()
            "snip" -> snippets()
            "style" -> styles()
            "ai" -> ai()
            "hist" -> aiHistory()
        }
        updateSuggestions()
        val k = mode + promptMode
        if (k != lastKey) {
            lastKey = k
            KeyAnim.transition(body, Prefs.animTrans(this), Prefs.animSpeed(this) / 100f, resources.displayMetrics.density)
        }
    }

    private fun bottomRow(label: String, target: String): LinearLayout {
        val bottom = row()
        bottom.addView(btn(label, 1.5f, true, 15f, true) { mode = target; render() })
        bottom.addView(btn("@globe", 1f, true, 16f, true) { switchKeyboard() })
        bottom.addView(btn(",", 1f, false, 18f, true) { type(",") })
        bottom.addView(btn("space", 4f, false, 16f, true) { spaceTap() })
        bottom.addView(btn(".", 1f, false, 18f, true) { type(".") })
        bottom.addView(btn(if (promptMode) "@send" else "@enter", 1.5f, true, 18f, true) { enter() })
        return bottom
    }

    private fun letters() {
        if (promptMode) {
            val ans = aiAnswer
            if (ans != null) {
                val sv = ScrollView(this)
                val av = TextView(this)
                av.setTextColor(th.text); av.textSize = 14f
                av.setPadding(dp(10), dp(6), dp(10), dp(6))
                av.text = ans
                sv.addView(av)
                val bga = GradientDrawable(); bga.cornerRadius = dp(8).toFloat(); bga.setColor(th.fn)
                sv.background = bga
                val lpa = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(110)); lpa.setMargins(dp(2), dp(3), dp(2), dp(3))
                sv.layoutParams = lpa
                body.addView(sv)
                val ar = row()
                ar.addView(btn("@insert Taruh semua", 2.2f, true, 14f, false, th.accent) { insertAnswer() })
                ar.addView(btn("@copy Salin", 1.6f, true, 14f) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("AI", ans)); say("Disalin.")
                })
                ar.addView(btn("@close", 0.8f, true) { aiAnswer = null; render() })
                body.addView(ar)
            }
            val h = row()
            val tv = TextView(this)
            tv.setTextColor(th.text); tv.textSize = 14f
            tv.setPadding(dp(10), dp(6), dp(10), dp(6))
            val sv = ScrollView(this)
            sv.addView(tv)
            val bgp = GradientDrawable(); bgp.cornerRadius = dp(8).toFloat(); bgp.setColor(th.fn)
            sv.background = bgp
            val lp = LinearLayout.LayoutParams(0, dp(56), 4f); lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            sv.layoutParams = lp
            promptView = tv
            promptScroll = sv
            h.addView(sv)
            h.addView(btn("@close", 0.8f, true) { promptMode = false; buf.setLength(0); aiAnswer = null; screenCtx = ""; render() })
            h.addView(btn("Kirim", 1.3f, true, 14f) { sendPrompt() })
            body.addView(h)
            updatePrompt()
        }
        if (Prefs.numRow(this)) {
            val nr = row()
            for (c in "1234567890") nr.addView(btn(c.toString(), 1f, false, 15f, true) { type(c.toString()) })
            body.addView(nr)
        }
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        for ((i, r) in rows.withIndex()) {
            val row = row()
            if (i == 1) row.setPadding(dp(14), 0, dp(14), 0)
            if (i == 2) row.addView(btn(if (caps) "@caps" else if (shift) "@shift_on" else "@shift", 1.5f, true, 18f, true) {
                val now = System.currentTimeMillis()
                if (caps) { caps = false; shift = false }
                else if (shift && now - lastShift < 400) { caps = true; shift = false }
                else if (shift) { shift = false }
                else { shift = true }
                lastShift = now
                render()
            })
            for (c in r) {
                val ch = if (shift || caps) c.uppercaseChar().toString() else c.toString()
                row.addView(btn(ch, 1f, false, 18f, true) {
                    type(ch)
                    if (shift) { shift = false; render() }
                })
            }
            if (i == 2) row.addView(backspace(1.5f))
            body.addView(row)
        }
        body.addView(bottomRow("123", "symbols"))
    }

    private fun symbols() {
        val rows = listOf("1234567890", "@#$%&-+()/", "*\"':;!?_=")
        for ((i, r) in rows.withIndex()) {
            val row = row()
            for (c in r) row.addView(btn(c.toString(), 1f, false, 18f, true) { type(c.toString()) })
            if (i == 2) row.addView(backspace(1.5f))
            body.addView(row)
        }
        body.addView(bottomRow("ABC", "letters"))
    }

    private fun emoji() {
        val tabs = row()
        tabs.addView(btn("@clock", 1f, emojiTab != 0, 16f) { emojiTab = 0; render() })
        emojiGroups.forEachIndexed { i, g ->
            tabs.addView(btn(g.first, 1f, emojiTab != i + 1, 16f) { emojiTab = i + 1; render() })
        }
        body.addView(tabs)
        if (emojiTab > 0 && emojiGroups[emojiTab - 1].first == "(ツ)") {
            listPanel(emojiGroups[emojiTab - 1].second, "")
            val kb = row()
            kb.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
            kb.addView(btn("space", 5f, false, 16f) { spaceTap() })
            kb.addView(backspace(1.5f))
            body.addView(kb)
            return
        }
        val list = if (emojiTab == 0) recent.toList() else emojiGroups[emojiTab - 1].second
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (list.isEmpty()) {
            val t = TextView(this)
            t.text = "Belum ada emoji terakhir."
            t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
            col.addView(t)
        }
        list.chunked(8).forEach { chunk ->
            val r = row()
            chunk.forEach { e -> r.addView(btn(e, 1f, false, 20f) { typeEmoji(e) }) }
            repeat(8 - chunk.size) {
                val sp = View(this)
                sp.layoutParams = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), 1f)
                r.addView(sp)
            }
            col.addView(r)
        }
        sv.addView(col)
        body.addView(sv)
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("space", 5f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    private fun listPanel(items: List<String>, empty: String) {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = empty
            t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
            col.addView(t)
        }
        items.forEach { c ->
            val t = btn(if (c.length > 60) c.take(60) + "…" else c, 1f, false, 14f) { type(c) }
            t.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).also {
                it.setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            t.setPadding(dp(10), 0, dp(10), 0)
            t.gravity = Gravity.CENTER_VERTICAL
            col.addView(t)
        }
        sv.addView(col)
        body.addView(sv)
    }

    private fun scrollPanel(build: (LinearLayout) -> Unit) {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        build(col)
        sv.addView(col)
        body.addView(sv)
    }

    private fun emptyNote(col: LinearLayout, s: String) {
        val t = TextView(this)
        t.text = s
        t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
        col.addView(t)
    }

    private fun itemRow(label: String, onTap: () -> Unit, acts: List<Pair<String, () -> Unit>>): LinearLayout {
        val r = row()
        val one = label.replace("\n", " ")
        val m = btn(if (one.length > 60) one.take(60) + "…" else one, 1f, false, 14f) { onTap() }
        m.layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).also { it.setMargins(dp(2), dp(3), dp(2), dp(3)) }
        m.setPadding(dp(10), 0, dp(10), 0)
        m.gravity = Gravity.CENTER_VERTICAL
        r.addView(m)
        for (a in acts) {
            val b = btn(a.first, 1f, true, 12f) { a.second() }
            b.layoutParams = LinearLayout.LayoutParams(dp(52), dp(42)).also { it.setMargins(dp(2), dp(3), dp(2), dp(3)) }
            r.addView(b)
        }
        return r
    }

    private fun clipboard() {
        val tools = row()
        tools.addView(btn("@left", 1f, true, 14f) { key(KeyEvent.KEYCODE_DPAD_LEFT) })
        tools.addView(btn("@right", 1f, true, 14f) { key(KeyEvent.KEYCODE_DPAD_RIGHT) })
        tools.addView(btn("Semua", 1.4f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.selectAll) })
        tools.addView(btn("Salin", 1.2f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.copy) })
        tools.addView(btn("Potong", 1.3f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.cut) })
        tools.addView(btn("Tempel", 1.3f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.paste) })
        body.addView(tools)
        scrollPanel { col ->
            if (pins.isEmpty() && clips.isEmpty()) emptyNote(col, "Belum ada riwayat salinan. Salin teks, nanti muncul di sini. Tekan Pin supaya teks tersimpan terus.")
            for (p in ArrayList(pins)) {
                col.addView(itemRow("★ " + p, { type(p) }, listOf(Pair("Lepas", {
                    pins.remove(p); Stash.setPins(this, pins)
                    if (!clips.contains(p)) clips.add(0, p)
                    render()
                }))))
            }
            for (c in ArrayList(clips)) {
                col.addView(itemRow(c, { type(c) }, listOf(
                    Pair("Pin", { clips.remove(c); pins.add(0, c); Stash.setPins(this, pins); render() }),
                    Pair("×", { clips.remove(c); render() })
                )))
            }
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("Hapus riwayat", 2f, true, 14f) { clips.clear(); render() })
        body.addView(bottom)
    }

    /** Satu baris teks cepat. Format "singkatan=teks panjang" (singkatan huruf saja, maks 12) akan
     *  otomatis berubah saat ditulis lalu tekan spasi. Baris tanpa "=" hanya jadi tombol teks. */
    private fun snipList(): List<Pair<String, String>> {
        return Prefs.snippets(this).split("\n").map { it.trim() }.filter { it.isNotEmpty() }.map { l ->
            val i = l.indexOf('=')
            val a = if (i in 1..12) l.substring(0, i).trim() else ""
            val v = if (i > 0) l.substring(i + 1).trim() else ""
            if (a.isNotEmpty() && v.isNotEmpty() && a.all { it.isLetter() }) Pair(a, v) else Pair("", l)
        }
    }

    private fun snippets() {
        val list = snipList()
        scrollPanel { col ->
            if (list.isEmpty()) emptyNote(col, "Belum ada teks cepat. Isi di aplikasi Romaboard, atau tekan Simpan untuk menyimpan teks yang terakhir disalin.")
            for (e in list) {
                val label = if (e.first.isNotEmpty()) e.first + " → " + e.second else e.second
                col.addView(itemRow(label, { type(e.second) }, emptyList()))
            }
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("Simpan", 1.6f, true, 14f) {
            val t = clips.firstOrNull()
            if (t == null) say("Belum ada teks yang disalin.")
            else {
                Prefs.setSnippets(this, (Prefs.snippets(this).trimEnd() + "\n" + t.replace("\n", " ")).trim())
                render()
                say("Tersimpan sebagai teks cepat.")
            }
        })
        bottom.addView(btn("space", 3f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    private fun aiHistory() {
        val list = Stash.aiHist(this)
        scrollPanel { col ->
            if (list.isEmpty()) emptyNote(col, "Belum ada riwayat hasil AI. Setiap hasil AI akan tersimpan di sini.")
            for (h in list) {
                col.addView(itemRow(h, { type(h) }, listOf(Pair("×", {
                    val l = Stash.aiHist(this); l.remove(h); Stash.setAiHist(this, l); render()
                }))))
            }
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("Menu AI", 1.6f, true, 14f) { mode = "ai"; render() })
        bottom.addView(btn("Hapus semua", 2f, true, 14f) { Stash.setAiHist(this, emptyList()); render() })
        body.addView(bottom)
    }

    /** Baca teks di layar (lewat aksesibilitas). Keyboard disembunyikan sebentar supaya tidak ikut terbaca
     *  dan isi aplikasi yang tadinya tertutup keyboard ikut terlihat, lalu dimunculkan lagi. */
    private fun readScreen() {
        val svc = PermanentService.instance
        if (svc == null) {
            say("Nyalakan layanan aksesibilitas Romaboard dulu (buka app Romaboard → Buka pengaturan aksesibilitas).")
            return
        }
        val ic = currentInputConnection
        val sel = ic?.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic?.getTextBeforeCursor(300, 0)?.toString() ?: "") else ""
        val ins = (if (sel.isNotEmpty()) sel else before).trim()
        host.hideForCapture()
        main.postDelayed({
            Thread {
                val txt = try { svc.readScreenText().take(6000) } catch (e: Exception) { "" }
                main.post {
                    host.showAfterCapture()
                    if (txt.isBlank()) {
                        say("Tidak ada teks yang terbaca di layar (gambar atau game tidak bisa dibaca).")
                    } else {
                        askScreen(txt, ins)
                    }
                }
            }.start()
        }, 500)
    }

    private fun askScreen(txt: String, ins: String) {
        val task = if (ins.isNotEmpty()) "Instruksi pengguna: $ins"
            else "Find the main question or problem in the screen text and answer it. If it is multiple choice, give the correct option and a one-line reason."
        val sys = "You are a helpful assistant inside a phone keyboard. You receive raw text captured from the user's screen, which may contain interface noise (menus, buttons, timestamps); ignore the noise. Answer in the same language as the screen text unless asked otherwise. Be concise. Output plain text, no markdown."
        say("Bertanya ke AI…", true)
        AiClient.askAuto(this, Prefs.model(this), sys, "Teks di layar:\n$txt\n\n$task", { out ->
            screenCtx = txt
            aiAnswer = out; aiSel = ""
            Stash.addAi(this, out)
            promptMode = true; buf.setLength(0); mode = "letters"; shift = false
            render()
        }, { err -> say(err) })
    }

    private fun translateBeforeSend(): Boolean {
        val ic = currentInputConnection ?: return false
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic.getTextBeforeCursor(1500, 0)?.toString() ?: "") else ""
        val src = if (sel.isNotEmpty()) sel else before
        if (src.isBlank()) return false
        val lang = Prefs.lang(this)
        say("Menerjemahkan ke $lang…", true)
        AiClient.askAuto(this, Prefs.model(this), "Translate to $lang. Output only the translation.", src, { out ->
            val c = currentInputConnection
            if (c != null) {
                if (sel.isEmpty()) c.deleteSurroundingText(before.length, 0)
                c.commitText(out, 1)
                undoOrig = src; undoOut = out
                trDone = true
                Stash.addAi(this, out)
                say("Sudah dalam $lang. Tekan kirim lagi untuk mengirim, atau Batal di menu AI.")
            }
        }, { err -> say(err) })
        return true
    }

    fun destroy() {
        saveWords()
        rec?.destroy()
    }

    private fun startPermanent() {
        // Mode permanen memakai keyboard asli (bukan overlay), jadi cukup menyalakan flag.
        host.startPermanentMode()
    }

    private fun tb(label: String, tint: Int? = null, onClick: () -> Unit): TextView {
        val t = btn(label, 1f, true, 15f, false, tint, onClick)
        val lp = LinearLayout.LayoutParams(dp(Prefs.tbW(this)), dp(Prefs.tbH(this)))
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        t.layoutParams = lp
        return t
    }

    // ---------- suara ke teks ----------
    private fun startVoice() {
        if (listening) { rec?.stopListening(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val i = Intent(this, PermissionActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            say("Izinkan mikrofon, lalu tekan tombol mikrofon lagi.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Pengenalan suara tidak tersedia di HP ini (butuh aplikasi Google).")
            return
        }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; say("Bicara sekarang… (tekan tombol mikrofon lagi untuk selesai)", true) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { say("Memproses suara…", true) }
            override fun onError(error: Int) {
                listening = false
                say(when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Tidak terdengar, coba lagi."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Izin mikrofon belum diberikan."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Butuh internet untuk pengenalan suara."
                    else -> "Suara gagal (kode $error)."
                })
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) { say("Tidak terdengar, coba lagi."); return }
                say(null)
                val before = if (promptMode) buf.toString() else (currentInputConnection?.getTextBeforeCursor(1, 0)?.toString() ?: "")
                val lead = if (before.isNotEmpty() && !before.endsWith(" ") && !before.endsWith("\n")) " " else ""
                type(lead + t.trim() + " ")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) say("Hasil suara: $t")
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.voiceLang(this))
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    // ---------- gaya teks ----------
    private val smallCaps = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"
    private val upside = "ɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz"

    private fun mapRange(s: String, up: Int, low: Int, dig: Int = -1): String {
        val sb = StringBuilder()
        for (ch in s) {
            when {
                ch in 'A'..'Z' -> sb.appendCodePoint(up + (ch - 'A'))
                ch in 'a'..'z' -> sb.appendCodePoint(low + (ch - 'a'))
                ch in '0'..'9' && dig >= 0 -> sb.appendCodePoint(dig + (ch - '0'))
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private val styleList: List<Pair<String, (String) -> String>> = listOf(
        Pair("Tebal", { s: String -> mapRange(s, 0x1D400, 0x1D41A, 0x1D7CE) }),
        Pair("Miring", { s: String -> mapRange(s, 0x1D434, 0x1D44E).replace(String(Character.toChars(0x1D455)), "ℎ") }),
        Pair("Tebal Miring", { s: String -> mapRange(s, 0x1D468, 0x1D482) }),
        Pair("Skrip", { s: String -> mapRange(s, 0x1D4D0, 0x1D4EA) }),
        Pair("Gotik", { s: String -> mapRange(s, 0x1D56C, 0x1D586) }),
        Pair("Mono", { s: String -> mapRange(s, 0x1D670, 0x1D68A, 0x1D7F6) }),
        Pair("Sans Tebal", { s: String -> mapRange(s, 0x1D5D4, 0x1D5EE, 0x1D7EC) }),
        Pair("Bulat", { s: String ->
            val sb = StringBuilder()
            for (ch in s) {
                when {
                    ch in 'A'..'Z' -> sb.appendCodePoint(0x24B6 + (ch - 'A'))
                    ch in 'a'..'z' -> sb.appendCodePoint(0x24D0 + (ch - 'a'))
                    ch in '1'..'9' -> sb.appendCodePoint(0x2460 + (ch - '1'))
                    ch == '0' -> sb.appendCodePoint(0x24EA)
                    else -> sb.append(ch)
                }
            }
            sb.toString()
        }),
        Pair("Kotak", { s: String -> mapRange(s, 0x1F130, 0x1F130) }),
        Pair("Kecil", { s: String -> s.map { c -> val l = c.lowercaseChar(); if (l in 'a'..'z') smallCaps[l - 'a'] else c }.joinToString("") }),
        Pair("Terbalik", { s: String -> s.lowercase().map { c -> if (c in 'a'..'z') upside[c - 'a'] else c }.reversed().joinToString("") }),
        Pair("Coret", { s: String -> s.map { c -> "$c̶" }.joinToString("") }),
        Pair("Garis bawah", { s: String -> s.map { c -> "$c̲" }.joinToString("") })
    )

    private fun applyStyle(fn: (String) -> String) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        if (sel.isNotEmpty()) {
            ic.commitText(fn(sel), 1)
        } else {
            val before = ic.getTextBeforeCursor(1500, 0)?.toString() ?: ""
            if (before.isEmpty()) { say("Ketik atau pilih teks dulu."); return }
            ic.deleteSurroundingText(before.length, 0)
            ic.commitText(fn(before), 1)
        }
    }

    private fun styles() {
        val hint = TextView(this)
        hint.text = "Pilih teks lalu tekan gaya. Kalau tidak ada yang dipilih, semua teks sebelum kursor diubah."
        hint.setTextColor(th.text); hint.textSize = 11f
        hint.setPadding(dp(8), dp(2), dp(8), dp(2))
        body.addView(hint)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(165))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        styleList.chunked(3).forEach { tri ->
            val r = row()
            tri.forEach { (name, fn) ->
                r.addView(btn(fn("Abc 12"), 1f, false, 14f) { applyStyle(fn) })
            }
            repeat(3 - tri.size) {
                val sp = View(this)
                sp.layoutParams = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), 1f)
                r.addView(sp)
            }
            col.addView(r)
        }
        sv.addView(col)
        body.addView(sv)
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("space", 4f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    // ---------- AI ----------
    private fun updatePrompt() {
        promptView?.text = if (buf.isEmpty()) "Ketik pertanyaan / perintah ke AI…" else buf.toString()
        promptScroll?.post { promptScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun insertAnswer() {
        val out = aiAnswer ?: return
        val c = currentInputConnection ?: return
        val ins = if (aiSel.isNotEmpty()) aiSel + "\n" + out else out
        c.commitText(ins, 1)
        undoOrig = aiSel; undoOut = ins
        aiAnswer = null; promptMode = false; buf.setLength(0); screenCtx = ""
        render()
    }

    private fun startPrompt() {
        promptMode = true; buf.setLength(0); mode = "letters"; shift = false; render()
    }

    private fun sendPrompt() {
        val q = buf.toString().trim()
        if (q.isEmpty()) { say("Ketik pertanyaannya dulu."); return }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val user = if (screenCtx.isNotEmpty()) "Teks di layar:\n$screenCtx\n\nPermintaan: $q"
            else if (sel.isNotEmpty()) "Teks terpilih:\n$sel\n\nPermintaan: $q" else q
        val sys = "You are a helpful assistant inside a phone keyboard. Answer concisely in the same language as the user's request. Output only the answer as plain text, no markdown."
        say("AI sedang menjawab…", true)
        AiClient.askAuto(this, Prefs.model(this), sys, user, { out ->
            aiAnswer = out; aiSel = sel
            Stash.addAi(this, out)
            render()
        }, { err -> say(err) })
    }

    private var undoOrig: String? = null
    private var undoOut: String? = null

    private fun undoAi() {
        val ic = currentInputConnection ?: return
        val o = undoOut; val orig = undoOrig
        if (o == null || orig == null) { say("Belum ada hasil AI untuk dibatalkan."); return }
        val before = ic.getTextBeforeCursor(o.length, 0)?.toString() ?: ""
        if (before != o) { say("Teks sudah berubah, tidak bisa dibatalkan."); return }
        ic.deleteSurroundingText(o.length, 0)
        ic.commitText(orig, 1)
        undoOut = null; undoOrig = null
        say("Dibatalkan.")
    }

    private fun ai() {
        val lang = Prefs.lang(this)
        val items = listOf(
            Triple("Perbaiki", "Fix grammar, spelling and punctuation. Keep the same language and meaning. Output only the corrected text.", true),
            Triple("Formal", "Rewrite in a formal, polite tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Santai", "Rewrite in a casual, friendly, natural chat tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Sopan", "Rewrite politely and respectfully, suitable to send to a boss or an elder. Keep the same language. Output only the rewritten text.", true),
            Triple("Lucu", "Rewrite in a funny, witty tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Ringkas", "Make it shorter and clearer. Keep the same language. Output only the result.", true),
            Triple("Singkat", "Make it extremely short, keeping only the key meaning. Same language. Output only the result.", true),
            Triple("Baku", "Rewrite in standard formal Indonesian with correct spelling (PUEBI). Output only the text.", true),
            Triple("Emoji-in", "Add fitting emojis to this text without changing the words. Output only the text.", true),
            Triple("Terjemah $lang", "Translate to $lang. Output only the translation.", true),
            Triple("Caption", "Turn this into a catchy social media caption. Keep the same language. Output only the caption.", true),
            Triple("Judul", "Write a short catchy title for this text in the same language. Output only the title.", false),
            Triple("Hashtag", "Suggest 8 relevant hashtags for this text. Output only the hashtags separated by spaces.", false),
            Triple("Jelaskan", "Explain this simply and briefly in the same language. Output only the explanation.", false),
            Triple("Balas", "The text is a message I received. Write a short, natural reply in the same language. Output only the reply.", false),
            Triple("Lanjutkan", "Continue writing this text naturally in the same language and style. Output only the continuation.", false),
            Triple("Poin-poin", "Rewrite as concise bullet points. Keep the same language. Output only the bullet points.", true),
            Triple("Riwayat AI", "HIST", true),
            Triple(if (Stash.autoTr(this)) "Auto-TR ON" else "Auto-TR OFF", "AUTOTR", true),
            Triple("Kustom", "CUSTOM", true),
            Triple("@chat Tanya AI", "ASK", true)
        )
        val hint = TextView(this)
        hint.text = "Ketik/pilih teks lalu tekan fitur. Auto-TR: teks otomatis diterjemahkan saat tekan kirim. Geser ke bawah untuk fitur lain."
        hint.setTextColor(th.text); hint.textSize = 11f
        hint.setPadding(dp(8), dp(2), dp(8), dp(2))
        body.addView(hint)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(165))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        items.chunked(3).forEach { tri ->
            val r = row()
            tri.forEach { (label, prompt, replace) ->
                val on = prompt == "AUTOTR" && Stash.autoTr(this)
                r.addView(btn(label, 1f, false, 14f, tint = if (on) th.accent else null) {
                    if (prompt == "HIST") { mode = "hist"; render() }
                    else if (prompt == "AUTOTR") {
                        Stash.setAutoTr(this, !Stash.autoTr(this))
                        render()
                        say(if (Stash.autoTr(this)) "Auto-TR aktif: saat tekan kirim, teks diterjemahkan ke ${Prefs.lang(this)} dulu." else "Auto-TR mati.")
                    } else if (prompt == "CUSTOM") {
                        val c = Prefs.custom(this)
                        if (c.isBlank()) say("Isi prompt kustom di aplikasi Romaboard.")
                        else runAi("$c Output only the result.", true)
                    } else if (prompt == "ASK") startPrompt() else runAi(prompt, replace)
                })
            }
            col.addView(r)
        }
        sv.addView(col)
        body.addView(sv)
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("@undo Batal", 1.6f, true, 14f) { undoAi() })
        bottom.addView(btn("space", 3f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    private fun runAi(system: String, replace: Boolean) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic.getTextBeforeCursor(1500, 0)?.toString() ?: "") else ""
        val src = if (sel.isNotEmpty()) sel else before
        if (src.isBlank()) { say("Ketik atau pilih teks dulu."); return }
        say("AI sedang memproses…", true)
        AiClient.askAuto(this, Prefs.model(this), system, src, { out ->
            Stash.addAi(this, out)
            val c = currentInputConnection
            if (c != null) {
                if (replace) {
                    if (sel.isEmpty()) c.deleteSurroundingText(before.length, 0)
                    c.commitText(out, 1)
                    undoOrig = src; undoOut = out
                } else {
                    val ins = (if (sel.isEmpty() && !before.endsWith(" ")) " " else "") + out
                    c.commitText(ins, 1)
                    undoOrig = ""; undoOut = ins
                }
            }
            say(null)
        }, { err -> say(err) })
    }
}
