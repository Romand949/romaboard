package com.byhas.aikeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import java.io.File

class KbTheme(val name: String, val bg: Int, val key: Int, val fn: Int, val text: Int, val accent: Int, val hi: Int = accent)

object Prefs {
    val themes = listOf(
        KbTheme("Gelap", Color.parseColor("#1E1E24"), Color.parseColor("#34343E"), Color.parseColor("#26262E"), Color.WHITE, Color.parseColor("#7C5CFF")),
        KbTheme("Terang", Color.parseColor("#E4E6EB"), Color.WHITE, Color.parseColor("#C9CCD3"), Color.parseColor("#111111"), Color.parseColor("#2E7DFF")),
        KbTheme("Samudra", Color.parseColor("#0B2239"), Color.parseColor("#17405F"), Color.parseColor("#10304A"), Color.WHITE, Color.parseColor("#27D3C3")),
        KbTheme("Sakura", Color.parseColor("#FBE4EC"), Color.WHITE, Color.parseColor("#F4C2D4"), Color.parseColor("#4A1F30"), Color.parseColor("#E94B83")),
        KbTheme("Kustom", Color.parseColor("#1E1E24"), Color.parseColor("#34343E"), Color.parseColor("#26262E"), Color.WHITE, Color.parseColor("#7C5CFF")),
        // index 5: tema bawaan baru (abu-abu gelap bergaya keyboard modern). Kustom harus tetap di index 4.
        KbTheme("Klasik", Color.parseColor("#222222"), Color.parseColor("#5E5E5E"), Color.parseColor("#303030"), Color.parseColor("#F1F1F1"), Color.parseColor("#8C8C8C"), Color.parseColor("#8AB4F8")),
        KbTheme("iOS Terang", Color.parseColor("#D1D4D9"), Color.WHITE, Color.parseColor("#ADB2BC"), Color.BLACK, Color.parseColor("#ADB2BC"), Color.parseColor("#007AFF")),
        KbTheme("iOS Gelap", Color.parseColor("#1F1F21"), Color.parseColor("#6B6B6E"), Color.parseColor("#454547"), Color.WHITE, Color.parseColor("#454547"), Color.parseColor("#0A84FF"))
    )
    val colorKeys = listOf("cBg" to "Latar keyboard", "cKey" to "Tombol huruf", "cFn" to "Tombol fungsi", "cText" to "Warna teks", "cAccent" to "Warna saat ditekan")
    fun parseHex(v: String?): Int? = try { Color.parseColor(if (v!!.startsWith("#")) v else "#$v") } catch (e: Exception) { null }
    fun colorHex(c: Context, key: String): String {
        val d = themes[4]
        val def = when (key) { "cBg" -> d.bg; "cKey" -> d.key; "cFn" -> d.fn; "cText" -> d.text; else -> d.accent }
        return sp(c).getString(key, null) ?: String.format("#%06X", def and 0xFFFFFF)
    }
    fun setColorHex(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()
    fun customTheme(c: Context): KbTheme {
        fun col(k: String) = parseHex(colorHex(c, k)) ?: Color.GRAY
        return KbTheme("Kustom", col("cBg"), col("cKey"), col("cFn"), col("cText"), col("cAccent"))
    }
    fun currentTheme(c: Context): KbTheme {
        val i = theme(c)
        return if (i == 4) customTheme(c) else themes[i]
    }

    // ---- tampilan yang bisa diatur ----
    fun keyHeightDp(c: Context) = sp(c).getInt("keyH2", listOf(48, 56, 64)[keySize(c)]).coerceIn(28, 100)
    fun setKeyHeightDp(c: Context, v: Int) = sp(c).edit().putInt("keyH2", v).apply()
    fun gapX(c: Context) = sp(c).getInt("gapX", 1).coerceIn(0, 12)
    fun setGapX(c: Context, v: Int) = sp(c).edit().putInt("gapX", v).apply()
    fun gapY(c: Context) = sp(c).getInt("gapY", 3).coerceIn(0, 12)
    fun setGapY(c: Context, v: Int) = sp(c).edit().putInt("gapY", v).apply()
    fun radius(c: Context) = sp(c).getInt("radius", 8).coerceIn(0, 30)
    fun setRadius(c: Context, v: Int) = sp(c).edit().putInt("radius", v).apply()
    fun fontScale(c: Context) = sp(c).getInt("fontScale", 100).coerceIn(50, 220)
    fun setFontScale(c: Context, v: Int) = sp(c).edit().putInt("fontScale", v).apply()
    fun keyAlpha(c: Context) = sp(c).getInt("keyAlpha", 100).coerceIn(10, 100)
    fun setKeyAlpha(c: Context, v: Int) = sp(c).edit().putInt("keyAlpha", v).apply()
    fun sidePad(c: Context) = sp(c).getInt("sidePad", 1).coerceIn(0, 40)
    fun setSidePad(c: Context, v: Int) = sp(c).edit().putInt("sidePad", v).apply()
    fun topPad(c: Context) = sp(c).getInt("topPad", 3).coerceIn(0, 40)
    fun setTopPad(c: Context, v: Int) = sp(c).edit().putInt("topPad", v).apply()
    fun bottomPad(c: Context) = sp(c).getInt("bottomPad", 6).coerceIn(0, 60)
    fun setBottomPad(c: Context, v: Int) = sp(c).edit().putInt("bottomPad", v).apply()
    fun tbH(c: Context) = sp(c).getInt("tbH", 40).coerceIn(24, 80)
    fun setTbH(c: Context, v: Int) = sp(c).edit().putInt("tbH", v).apply()
    fun tbW(c: Context) = sp(c).getInt("tbW", 58).coerceIn(32, 120)
    fun setTbW(c: Context, v: Int) = sp(c).edit().putInt("tbW", v).apply()
    // lebar tombol khusus, dalam % (100 = selebar tombol huruf)
    fun wShift(c: Context) = sp(c).getInt("wShift", 150).coerceIn(80, 300)
    fun setWShift(c: Context, v: Int) = sp(c).edit().putInt("wShift", v).apply()
    fun wMode(c: Context) = sp(c).getInt("wMode", 150).coerceIn(80, 300)
    fun setWMode(c: Context, v: Int) = sp(c).edit().putInt("wMode", v).apply()
    fun wSpace(c: Context) = sp(c).getInt("wSpace", 400).coerceIn(150, 800)
    fun setWSpace(c: Context, v: Int) = sp(c).edit().putInt("wSpace", v).apply()
    fun wEnter(c: Context) = sp(c).getInt("wEnter", 150).coerceIn(80, 300)
    fun setWEnter(c: Context, v: Int) = sp(c).edit().putInt("wEnter", v).apply()
    fun wPunct(c: Context) = sp(c).getInt("wPunct", 100).coerceIn(60, 200)
    fun setWPunct(c: Context, v: Int) = sp(c).edit().putInt("wPunct", v).apply()
    fun emoSize(c: Context) = sp(c).getInt("emoSize", 20).coerceIn(12, 36)
    fun setEmoSize(c: Context, v: Int) = sp(c).edit().putInt("emoSize", v).apply()
    fun emoH(c: Context) = sp(c).getInt("emoH", 150).coerceIn(100, 260)
    fun setEmoH(c: Context, v: Int) = sp(c).edit().putInt("emoH", v).apply()
    fun bold(c: Context) = sp(c).getBoolean("bold", false)
    fun setBold(c: Context, v: Boolean) = sp(c).edit().putBoolean("bold", v).apply()

    val fontNames = listOf("Bawaan", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Thin", "Medium", "Black", "Serif Mono", "Small Caps", "Font sendiri")
    private val fontFamilies = listOf(null, "serif", "monospace", "cursive", "casual", "sans-serif-condensed", "sans-serif-light", "sans-serif-thin", "sans-serif-medium", "sans-serif-black", "serif-monospace", "sans-serif-smallcaps")
    fun fontIdx(c: Context) = sp(c).getInt("font", 0).coerceIn(0, fontNames.size - 1)
    fun setFontIdx(c: Context, v: Int) = sp(c).edit().putInt("font", v).apply()
    fun fontRev(c: Context) = sp(c).getInt("fontRev", 0)
    fun bumpFontRev(c: Context) = sp(c).edit().putInt("fontRev", fontRev(c) + 1).apply()
    fun customFontFile(c: Context) = File(c.filesDir, "customfont.ttf")
    fun typeface(c: Context): Typeface {
        val style = if (bold(c)) Typeface.BOLD else Typeface.NORMAL
        val i = fontIdx(c)
        val base: Typeface = if (i == fontNames.size - 1) {
            try { if (customFontFile(c).exists()) Typeface.createFromFile(customFontFile(c)) else Typeface.DEFAULT } catch (e: Exception) { Typeface.DEFAULT }
        } else {
            val fam = fontFamilies[i]
            if (fam == null) Typeface.DEFAULT else Typeface.create(fam, Typeface.NORMAL)
        }
        return Typeface.create(base, style)
    }
    private val appearanceKeys = listOf("theme", "keyH2", "keySize", "gapX", "gapY", "radius", "fontScale", "keyAlpha", "sidePad", "topPad", "bottomPad",
        "tbH", "tbW", "wShift", "wMode", "wSpace", "wEnter", "wPunct", "emoSize", "emoH", "tbOrder", "bold", "font", "fontRev", "hand", "animPress", "cBg", "cKey", "cFn", "cText", "cAccent", "layout")
    // ---- urutan tombol baris atas ----
    val toolbarIds = listOf("pin", "abc", "ai", "emoji", "style", "snip", "clip", "mic", "read", "swap", "gear")
    val toolbarNames = mapOf(
        "pin" to "Sematkan (mode permanen)", "abc" to "ABC (huruf)", "ai" to "AI (menu fitur AI)", "emoji" to "Emoji",
        "style" to "Aa (gaya huruf)", "snip" to "Teks cepat (petir)", "clip" to "Clipboard", "mic" to "Mikrofon",
        "read" to "Baca layar", "swap" to "Geser keyboard kiri/kanan", "gear" to "Pengaturan")
    fun toolbarOrder(c: Context): List<String> {
        val saved = (sp(c).getString("tbOrder", "") ?: "").split(",").filter { it in toolbarIds }.distinct()
        return saved + toolbarIds.filter { it !in saved }
    }
    fun setToolbarOrder(c: Context, l: List<String>) = sp(c).edit().putString("tbOrder", l.joinToString(",")).apply()
    fun appearanceSig(c: Context): String { val a = sp(c).all; return appearanceKeys.joinToString("|") { a[it].toString() } }

    // ---- gaya font saat mengetik (tombol Aa); kosong = normal ----
    fun activeStyleName(c: Context) = sp(c).getString("styleName", "") ?: ""
    fun setActiveStyleName(c: Context, v: String) = sp(c).edit().putString("styleName", v).apply()

    // ---- animasi ----
    fun animPress(c: Context) = sp(c).getInt("animPress", 10).coerceIn(0, KeyAnim.pressNames.size - 1)
    fun setAnimPress(c: Context, v: Int) = sp(c).edit().putInt("animPress", v).apply()
    fun animTrans(c: Context) = sp(c).getInt("animTrans", 0).coerceIn(0, KeyAnim.transNames.size - 1)
    fun setAnimTrans(c: Context, v: Int) = sp(c).edit().putInt("animTrans", v).apply()
    fun animAppear(c: Context) = sp(c).getInt("animAppear", 1).coerceIn(0, KeyAnim.appearNames.size - 1)
    fun setAnimAppear(c: Context, v: Int) = sp(c).edit().putInt("animAppear", v).apply()
    fun animSpeed(c: Context) = sp(c).getInt("animSpeed", 100).coerceIn(40, 300)
    fun setAnimSpeed(c: Context, v: Int) = sp(c).edit().putInt("animSpeed", v).apply()

    // ---- posisi ikon keyboard yang diperkecil (pecahan 0..1 dari area geser) ----
    fun miniFx(c: Context) = sp(c).getFloat("miniFx", 1f).coerceIn(0f, 1f)
    fun miniFy(c: Context) = sp(c).getFloat("miniFy", 1f).coerceIn(0f, 1f)
    fun setMiniPos(c: Context, fx: Float, fy: Float) = sp(c).edit().putFloat("miniFx", fx).putFloat("miniFy", fy).apply()

    // ---- keyboard permanen ----
    fun permanent(c: Context) = sp(c).getBoolean("permanent", false)
    fun setPermanent(c: Context, v: Boolean) = sp(c).edit().putBoolean("permanent", v).apply()
    private fun sp(c: Context) = c.getSharedPreferences("kb", Context.MODE_PRIVATE)
    fun clean(v: String): String {
        val x = v.filter { !it.isWhitespace() && it.code in 33..126 }
        // Keyboard sering mengubah huruf pertama jadi kapital ("Gsk_"), padahal key Groq selalu "gsk_".
        return if (x.length > 4 && x.substring(0, 4).equals("gsk_", true)) "gsk_" + x.substring(4) else x
    }
    // ---- banyak API key (tanpa batas), otomatis pindah kalau kena limit ----
    fun keyList(c: Context): List<String> {
        val raw = sp(c).getString("apiKeys", null)
        if (raw == null) {
            val old = clean(sp(c).getString("apiKey", "") ?: "")
            return if (old.isEmpty()) emptyList() else listOf(old)
        }
        return try {
            val a = org.json.JSONArray(raw)
            (0 until a.length()).map { clean(a.getString(it)) }.filter { it.isNotEmpty() }
        } catch (e: Exception) { emptyList() }
    }
    private fun saveKeys(c: Context, l: List<String>) =
        sp(c).edit().putString("apiKeys", org.json.JSONArray(l).toString()).apply()
    fun keyIdx(c: Context): Int = sp(c).getInt("keyIdx", 0).coerceIn(0, maxOf(0, keyList(c).size - 1))
    fun setKeyIdx(c: Context, i: Int) = sp(c).edit().putInt("keyIdx", i).apply()
    fun addKey(c: Context, k: String): Boolean {
        val l = keyList(c)
        val v = clean(k)
        if (v.isEmpty() || l.contains(v)) return false
        saveKeys(c, l + v)
        return true
    }
    fun removeKey(c: Context, i: Int) {
        val l = keyList(c).toMutableList()
        if (i !in l.indices) return
        val act = keyIdx(c)
        l.removeAt(i)
        saveKeys(c, l)
        setKeyIdx(c, if (i < act) act - 1 else act.coerceAtMost(maxOf(0, l.size - 1)))
    }
    fun usage(c: Context, key: String): String? = sp(c).getString("use_" + key.hashCode(), null)
    fun setUsage(c: Context, key: String, v: String) = sp(c).edit().putString("use_" + key.hashCode(), v).apply()
    fun apiKey(c: Context): String = keyList(c).getOrNull(keyIdx(c)) ?: ""
    fun ownKey(c: Context) = apiKey(c)
    fun setKey(c: Context, v: String) { addKey(c, v) }
    fun model(c: Context) = sp(c).getString("model", "llama-3.1-8b-instant") ?: "llama-3.1-8b-instant"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v).apply()
    fun theme(c: Context) = sp(c).getInt("theme", 5).coerceIn(0, themes.size - 1)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()
    fun lang(c: Context) = sp(c).getString("lang", "English") ?: "English"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptic", v).apply()
    fun numRow(c: Context) = sp(c).getBoolean("numRow2", true)
    fun setNumRow(c: Context, v: Boolean) = sp(c).edit().putBoolean("numRow2", v).apply()
    fun autoCap(c: Context) = sp(c).getBoolean("autoCap", true)
    fun setAutoCap(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoCap", v).apply()
    fun dblSpace(c: Context) = sp(c).getBoolean("dblSpace", true)
    fun setDblSpace(c: Context, v: Boolean) = sp(c).edit().putBoolean("dblSpace", v).apply()
    fun snippets(c: Context) = sp(c).getString("snippets", "Terima kasih banyak \uD83D\uDE4F\nSiap, ditunggu ya\nMaaf baru balas, tadi sibuk\nAssalamualaikum") ?: ""
    fun setSnippets(c: Context, v: String) = sp(c).edit().putString("snippets", v).apply()
    fun custom(c: Context) = sp(c).getString("custom", "") ?: ""
    fun setCustom(c: Context, v: String) = sp(c).edit().putString("custom", v).apply()
    fun sound(c: Context) = sp(c).getBoolean("sound", false)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()
    // lama tekan-tahan (ms) untuk angka/simbol kecil, koma=mikrofon, spasi=kursor. 0 = mati (ketikan murni, tanpa timer)
    fun holdMs(c: Context) = sp(c).getInt("holdMs", 400).coerceIn(0, 1000)
    fun setHoldMs(c: Context, v: Int) = sp(c).edit().putInt("holdMs", v).apply()
    fun preview(c: Context) = sp(c).getBoolean("preview", true)
    fun setPreview(c: Context, v: Boolean) = sp(c).edit().putBoolean("preview", v).apply()
    fun clipBar(c: Context) = sp(c).getBoolean("clipBar", true)
    fun setClipBar(c: Context, v: Boolean) = sp(c).edit().putBoolean("clipBar", v).apply()
    fun suggest(c: Context) = sp(c).getBoolean("suggest", true)
    fun setSuggest(c: Context, v: Boolean) = sp(c).edit().putBoolean("suggest", v).apply()
    fun keySize(c: Context) = sp(c).getInt("keySize", 1).coerceIn(0, 2)
    fun setKeySize(c: Context, v: Int) = sp(c).edit().putInt("keySize", v).apply()
    fun hand(c: Context) = sp(c).getInt("hand", 0).coerceIn(0, 2)
    fun setHand(c: Context, v: Int) = sp(c).edit().putInt("hand", v).apply()
    fun recent(c: Context) = sp(c).getString("recent", "") ?: ""
    fun setRecent(c: Context, v: String) = sp(c).edit().putString("recent", v).apply()
    fun words(c: Context) = sp(c).getString("words", "") ?: ""
    fun setWords(c: Context, v: String) = sp(c).edit().putString("words", v).apply()
    fun voiceLang(c: Context) = sp(c).getString("voiceLang", "id-ID") ?: "id-ID"
    fun setVoiceLang(c: Context, v: String) = sp(c).edit().putString("voiceLang", v).apply()
    // tata letak keyboard: 0 QWERTY, 1 Dvorak, 2 Colemak, 3 AZERTY, 4 QWERTZ, 5 T9/Numerik
    val layoutNames = listOf("QWERTY (standar)", "Dvorak", "Colemak", "AZERTY", "QWERTZ", "T9 / Numerik")
    fun layout(c: Context) = sp(c).getInt("layout", 0).coerceIn(0, 5)
    fun setLayout(c: Context, v: Int) = sp(c).edit().putInt("layout", v).apply()
}
