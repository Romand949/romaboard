package com.byhas.aikeyboard

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.HorizontalScrollView
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.content.ContextWrapper
import android.view.inputmethod.InputConnection
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class KeyboardController(base: Context, private val host: Host) : ContextWrapper(base) {
    interface Host {
        val overlay: Boolean
        fun ic(): InputConnection?
        fun editorAction(): Boolean
        fun rebuild()
        fun stopPermanent()
        fun collapse()
        fun hideIme()
        fun startPermanentMode() {}
        val minimized: Boolean get() = false
        fun restore() {}
        /** Sembunyikan keyboard sebentar saat membaca layar, lalu munculkan lagi. */
        fun hideForCapture() {}
        fun showAfterCapture() {}
    }

    private val currentInputConnection: InputConnection? get() = host.ic()
    private val main = Handler(Looper.getMainLooper())
    private lateinit var th: KbTheme
    private lateinit var audio: AudioManager
    private var buildSig = ""
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private lateinit var sugg: LinearLayout
    private var mode = "letters"
    private var shift = false
    private var caps = false
    private var lastShift = 0L
    private val clips = ArrayList<String>()
    private val pins = ArrayList<String>()
    private var trDone = false
    private var screenCtx = ""
    private var promptMode = false
    private val buf = StringBuilder()
    private var promptView: TextView? = null
    private var promptScroll: ScrollView? = null
    private var aiAnswer: String? = null
    private var aiSel: String = ""
    private var emojiTab = 1
    private val recent = ArrayList<String>()
    private val wordFreq = HashMap<String, Int>()
    private var rec: SpeechRecognizer? = null
    private var listening = false
    private var lastKey = ""
    private var rootView: View? = null
    private var lastSugg = ""
    private var pulse: ObjectAnimator? = null
    private var addClip = false
    private var confirmAct: (() -> Unit)? = null
    private var confirmBack = "clip"
    private var backTo = "letters"
    private lateinit var toolbar: LinearLayout
    private lateinit var dialogHost: LinearLayout
    private var tbBg = Color.BLACK
    private var saveBtn: TextView? = null
    private val inBuf: Boolean get() = promptMode || addClip
    private val subs = setOf("theme", "clip", "edit", "confirm", "ctrl")

    private val builtIn = ("yang dan di ke dari untuk dengan tidak ini itu saya aku kamu kita kami mereka adalah akan sudah belum bisa boleh mau ingin " +
        "tolong terima kasih maaf selamat pagi siang sore malam apa siapa kapan dimana kenapa bagaimana berapa besok kemarin sekarang nanti tadi " +
        "hari minggu bulan tahun jam menit rumah kerja sekolah makan minum tidur pergi pulang datang lihat dengar bicara telepon pesan kirim " +
        "baik buruk bagus senang sedih capek lapar haus sibuk santai teman keluarga orang anak bapak ibu kakak adik sama juga lagi masih sangat " +
        "sekali banget aja dong deh nih sih oke siap gimana kalau kalo tapi karena jadi supaya atau jika maka saat ketika sebelum sesudah setelah " +
        "dalam pada oleh bahwa hanya semua setiap beberapa banyak sedikit lebih kurang paling assalamualaikum waalaikumsalam " +
        "hello thanks please sorry good morning night today tomorrow yesterday because about would could should with from have this that what when where which").split(" ")

    private val kaomoji = listOf("¯\\_(ツ)_/¯", "(╯°□°)╯︵ ┻━┻", "ʕ•ᴥ•ʔ", "(づ｡◕‿‿◕｡)づ", "(≧▽≦)", "(｡•́︿•̀｡)", "( ͡° ͜ʖ ͡°)", "ᕕ( ᐛ )ᕗ", "(ง •̀_•́)ง", "(✿◠‿◠)", "(¬_¬)", "(ノ◕ヮ◕)ノ*:･ﾟ✧", "(•‿•)", "(⌐■_■)", "(⊙_⊙)", "(°o°)", "(◕‿◕)", "(ᵔᴥᵔ)", "(=^･ω･^=)", "(╥﹏╥)", "(T_T)", "(＾▽＾)", "(´∀`)", "(☞ﾟヮﾟ)☞", "☜(ﾟヮﾟ☜)", "(≖‿≖)", "(๑•̀ㅂ•́)و✧", "(ㆆ_ㆆ)", "(；´Д｀)", "(´･ω･`)", "(>_<)", "(^_−)☆", "(｡♥‿♥｡)", "(*´▽`*)", "ヽ(´▽`)/", "(҂◡_◡)")

    // Emoji & simbol lengkap: dari EmojiData, yang tidak didukung font perangkat otomatis disaring
    private val emojiGroups: List<Pair<String, List<String>>> by lazy {
        EmojiData.emoji.map { it.first to supported(it.second) } + ("(ツ)" to kaomoji)
    }
    private val symGroups: List<Pair<String, List<String>>> by lazy {
        EmojiData.symbols.map { it.first to supported(it.second) }
    }
    private var symTab = 0

    private fun supported(data: String): List<String> {
        val all = data.split(" ").filter { it.isNotEmpty() }
        val paint = android.graphics.Paint()
        val ok = all.filter { try { paint.hasGlyph(it) } catch (e: Exception) { true } }
        return if (ok.isEmpty()) all else ok
    }

    fun create() {
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        recent.addAll(Prefs.recent(this).split(" ").filter { it.isNotBlank() })
        loadWords()
        pins.addAll(Stash.pins(this))
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank() && !pins.contains(t)) { clips.remove(t); clips.add(0, t); if (clips.size > 30) clips.removeAt(30) }
        }
    }

    fun finishInput() { saveWords() }

    fun playAppear() {
        val r = rootView ?: return
        KeyAnim.appear(r, Prefs.animAppear(this), Prefs.animSpeed(this) / 100f, resources.displayMetrics.density)
    }

    fun startInput() {
        if (buildSig != sig()) host.rebuild()
        mode = "letters"; shift = false; caps = false
        promptMode = false; addClip = false; confirmAct = null; buf.setLength(0); aiAnswer = null; screenCtx = ""
        render()
        autoShift()
    }

    private fun sig() = Prefs.appearanceSig(this)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- words ----------
    private fun loadWords() {
        Prefs.words(this).split("\n").forEach { l ->
            val p = l.split("\t")
            if (p.size == 2) {
                val n = p[1].toIntOrNull()
                if (n != null) wordFreq[p[0]] = n
            }
        }
    }

    private fun saveWords() {
        val top = wordFreq.entries.sortedByDescending { it.value }.take(400)
        Prefs.setWords(this, top.joinToString("\n") { it.key + "\t" + it.value })
    }

    private fun curWord(): String {
        val b = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString() ?: return ""
        var i = b.length
        while (i > 0 && (b[i - 1].isLetter() || b[i - 1] == '\'')) i--
        return b.substring(i)
    }

    private val suggRun = Runnable { updateSuggestions() }
    private fun scheduleSuggest() { /* bar saran kata dihapus */ }

    private fun updateSuggestions() {
        if (!::sugg.isInitialized) return
        sugg.removeAllViews()
        sugg.visibility = View.GONE   // bar saran kata dihapus: tidak ditampilkan lagi
        if (true) return
        if (!Prefs.suggest(this) || inBuf || mode != "letters") { sugg.visibility = View.GONE; return }
        val w = curWord()
        val lw = w.lowercase()
        val list = if (lw.isEmpty()) emptyList() else
            (builtIn + wordFreq.keys).filter { it.startsWith(lw) && it != lw }.distinct()
                .sortedWith(compareByDescending<String> { wordFreq[it] ?: 0 }.thenBy { it.length }).take(3)
        val sk = list.joinToString("|")
        val changed = sk != lastSugg
        lastSugg = sk
        for ((si, s) in list.withIndex()) {
            val shown = if (w.isNotEmpty() && w[0].isUpperCase()) s.replaceFirstChar { it.uppercase() } else s
            if (si > 0) {
                val dv = View(this)
                dv.setBackgroundColor(Color.argb(70, Color.red(th.text), Color.green(th.text), Color.blue(th.text)))
                dv.layoutParams = LinearLayout.LayoutParams(1, dp(22)).also { it.gravity = Gravity.CENTER_VERTICAL }
                sugg.addView(dv)
            }
            val c = chip(shown) { applySuggestion(w, shown) }
            if (changed) { c.alpha = 0f; c.animate().alpha(1f).setDuration(120).start() }
            sugg.addView(c)
        }
        // kotak saran disembunyikan total kalau belum ada saran kata (hemat tempat)
        sugg.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun applySuggestion(w: String, s: String) {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText("$s ", 1)
        val l = s.lowercase()
        wordFreq[l] = (wordFreq[l] ?: 0) + 1
        autoShift()
        updateSuggestions()
    }

    // ---------- views ----------
    var miniIcon: View? = null

    /** Tampilan saat keyboard permanen diperkecil: hanya satu ikon bulat yang bisa digeser. Ketuk untuk membuka lagi. */
    private fun buildMini(): View {
        val dm = resources.displayMetrics
        val size = dp(50)
        val w = dm.widthPixels
        val hh = (dm.heightPixels * 0.85f).toInt().coerceAtLeast(size + dp(20))
        val frame = android.widget.FrameLayout(this)
        frame.layoutParams = android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, hh)
        val ic = View(this)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(th.accent)
        circle.setStroke(dp(2), th.bg)
        val ink = if (androidx.core.graphics.ColorUtils.calculateLuminance(th.accent) > 0.5) Color.BLACK else Color.WHITE
        ic.background = android.graphics.drawable.LayerDrawable(arrayOf(circle, IconDrawable("keyboard", ink, dp(26).toFloat())))
        ic.elevation = dp(8).toFloat()
        val lp = android.widget.FrameLayout.LayoutParams(size, size)
        lp.leftMargin = (Prefs.miniFx(this) * (w - size)).toInt()
        lp.topMargin = (Prefs.miniFy(this) * (hh - size)).toInt()
        ic.layoutParams = lp
        var dx0 = 0f; var dy0 = 0f; var l0 = 0; var t0 = 0; var moved = false
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        ic.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx0 = e.rawX; dy0 = e.rawY; l0 = lp.leftMargin; t0 = lp.topMargin; moved = false
                    v.animate().cancel(); v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(60).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - dx0; val dy = e.rawY - dy0
                    if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) {
                        moved = true
                        v.animate().cancel(); v.animate().scaleX(1.18f).scaleY(1.18f).alpha(0.85f).setDuration(100).start()
                    }
                    if (moved) {
                        lp.leftMargin = (l0 + dx).toInt().coerceIn(0, w - size)
                        lp.topMargin = (t0 + dy).toInt().coerceIn(0, hh - size)
                        v.layoutParams = lp
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.animate().cancel(); v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(140).setInterpolator(OvershootInterpolator(2f)).start()
                    if (moved) Prefs.setMiniPos(this, lp.leftMargin.toFloat() / (w - size), lp.topMargin.toFloat() / (hh - size))
                    else { feedback(v); host.restore() }
                }
                MotionEvent.ACTION_CANCEL -> { v.animate().cancel(); v.scaleX = 1f; v.scaleY = 1f; v.alpha = 1f }
            }
            true
        }
        frame.addView(ic)
        miniIcon = ic
        rootView = frame
        return frame
    }

    fun build(): View {
        th = Prefs.currentTheme(this)
        buildSig = sig()
        if (host.minimized && host.overlay) return buildMini()
        miniIcon = null
        val root = LinearLayout(this)
        rootView = root
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(th.bg)
        val lumBg = androidx.core.graphics.ColorUtils.calculateLuminance(th.bg)
        tbBg = androidx.core.graphics.ColorUtils.blendARGB(th.bg, Color.BLACK, if (lumBg > 0.5) 0.10f else 0.45f)

        // kotak "Tambahkan klip baru" muncul di atas toolbar
        dialogHost = LinearLayout(this)
        dialogHost.orientation = LinearLayout.VERTICAL
        dialogHost.visibility = View.GONE
        root.addView(dialogHost)

        toolbar = LinearLayout(this)
        toolbar.orientation = LinearLayout.HORIZONTAL
        toolbar.gravity = Gravity.CENTER_VERTICAL
        toolbar.setBackgroundColor(tbBg)
        toolbar.setPadding(dp(8), dp(3), dp(8), dp(3))
        root.addView(toolbar)

        val hand = Prefs.hand(this)
        val extra = (resources.displayMetrics.widthPixels * 0.2f).toInt()
        val sp0 = Prefs.sidePad(this)
        val area = LinearLayout(this)
        area.orientation = LinearLayout.VERTICAL
        area.setPadding(dp(sp0) + (if (hand == 2) extra else 0), dp(Prefs.topPad(this)), dp(sp0) + (if (hand == 1) extra else 0), dp(Prefs.bottomPad(this)))
        root.addView(area)

        status = TextView(this)
        status.setTextColor(th.accent)
        status.textSize = 12f
        status.setPadding(dp(8), 0, dp(8), 0)
        status.visibility = View.GONE
        area.addView(status)

        sugg = LinearLayout(this)
        sugg.orientation = LinearLayout.HORIZONTAL
        area.addView(sugg)

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        area.addView(body)

        // lapisan gelembung pratinjau: salinan tombol berwarna lain di atas tombol yang ditekan
        val frame = android.widget.FrameLayout(this)
        frame.addView(root, android.widget.FrameLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
        val pvv = TextView(this)
        pvv.gravity = Gravity.CENTER
        pvv.textSize = 26f
        pvv.setTextColor(if (lum(th.hi) > 0.5) Color.BLACK else Color.WHITE)
        val pg = GradientDrawable()
        pg.cornerRadius = dp(12).toFloat()
        pg.setColor(th.hi)
        pvv.background = pg
        pvv.elevation = dp(6).toFloat()
        pvv.alpha = 0f
        frame.addView(pvv, android.widget.FrameLayout.LayoutParams(dp(50), dp(70)))
        pvFrame = frame
        pvView = pvv
        rootView = frame
        render()
        return frame
    }

    private fun say(s: String?, busy: Boolean = false) {
        pulse?.cancel(); pulse = null
        status.animate().cancel()
        if (s == null) { status.visibility = View.GONE; status.alpha = 1f; return }
        val wasHidden = status.visibility != View.VISIBLE
        status.text = s
        status.visibility = View.VISIBLE
        status.alpha = 1f
        if (wasHidden) { status.alpha = 0f; status.animate().alpha(1f).setDuration(150).start() }
        if (busy) {
            val p = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.35f)
            p.duration = 700
            p.repeatMode = ValueAnimator.REVERSE
            p.repeatCount = ValueAnimator.INFINITE
            p.startDelay = 200
            p.start()
            pulse = p
        }
    }

    private fun pressAnim(v: View, down: Boolean, x: Float = v.width / 2f, y: Float = v.height / 2f) {
        KeyAnim.press(v, down, Prefs.animPress(this), Prefs.animSpeed(this) / 100f, x, y)
    }

    private fun release(bg: GradientDrawable, normal: Int) {
        val a = ValueAnimator.ofObject(ArgbEvaluator(), th.accent, normal)
        a.duration = (200 / (Prefs.animSpeed(this) / 100f)).toLong()
        a.addUpdateListener { bg.setColor(it.animatedValue as Int) }
        a.start()
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.isBaselineAligned = false   // tanpa ini tombol dengan ukuran huruf berbeda (mis. spasi) ikut tergeser ke bawah
        return r
    }

    private fun feedback(v: View) {
        if (Prefs.haptic(this)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        if (Prefs.sound(this)) audio.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
    }

    private fun chip(label: String, onTap: () -> Unit): TextView {
        val t = TextView(this)
        val rip = Prefs.animPress(this) == KeyAnim.RIPPLE
        var iconKind: String? = null
        var shown = label
        if (label.length > 1 && label[0] == '@' && label[1].isLetter()) {
            val sp = label.indexOf(' ')
            iconKind = if (sp < 0) label.substring(1) else label.substring(1, sp)
            shown = if (sp < 0) "" else label.substring(sp + 1)
        }
        t.text = shown
        t.gravity = Gravity.CENTER
        t.textSize = 15f * Prefs.fontScale(this) / 100f
        t.typeface = Prefs.typeface(this)
        t.maxLines = 1
        t.setTextColor(th.text)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(Prefs.radius(this)).toFloat()
        bg.setColor(Color.TRANSPARENT)
        t.background = bg
        val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        t.layoutParams = lp
        t.setOnClickListener { feedback(t); onTap() }
        return t
    }

    private fun btn(label: String, w: Float = 1f, special: Boolean = false, size: Float = 18f, fast: Boolean = false, tint: Int? = null, iconInk: Int? = null, hint: String? = null, hold: (() -> Unit)? = null, pv: String? = null, altsOf: (() -> List<String>)? = null, onClick: () -> Unit): TextView {
        val t = TextView(this)
        val rip = Prefs.animPress(this) == KeyAnim.RIPPLE
        var iconKind: String? = null
        var shown = label
        if (label.length > 1 && label[0] == '@' && label[1].isLetter()) {
            val sp = label.indexOf(' ')
            iconKind = if (sp < 0) label.substring(1) else label.substring(1, sp)
            shown = if (sp < 0) "" else label.substring(sp + 1)
        }
        t.text = shown
        t.gravity = Gravity.CENTER
        t.textSize = size * Prefs.fontScale(this) / 100f
        t.typeface = Prefs.typeface(this)
        t.maxLines = 1
        t.setTextColor(th.text)
        val normal = tint ?: (if (special) th.fn else th.key)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(Prefs.radius(this)).toFloat()
        bg.setColor(normal)
        bg.alpha = Prefs.keyAlpha(this) * 255 / 100
        // Jarak visual antar tombol dibuat lewat inset, bukan margin, supaya tidak ada celah mati
        // yang bikin ketukan meleset (penyebab typo).
        val inset = android.graphics.drawable.InsetDrawable(bg, dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)))
        val layers = ArrayList<android.graphics.drawable.Drawable>()
        layers.add(inset)
        if (hint != null) {
            val hc = Color.argb(150, Color.red(th.text), Color.green(th.text), Color.blue(th.text))
            layers.add(HintDrawable(hint, hc, dp(10).toFloat(), (dp(Prefs.gapX(this)) + dp(6)).toFloat(), (dp(Prefs.gapY(this)) + dp(3)).toFloat()))
        }
        if (iconKind != null) {
            val ink = iconInk ?: (if (tint != null && androidx.core.graphics.ColorUtils.calculateLuminance(tint) > 0.5) Color.BLACK
                      else if (tint != null) Color.WHITE else th.text)
            val withText = shown.isNotEmpty()
            val isz = if (withText) dp(18).toFloat() else 0f
            val gap = if (withText) dp(6).toFloat() else 0f
            if (withText) t.setPadding((isz + gap).toInt(), 0, 0, 0)
            t.setTextColor(ink)
            layers.add(IconDrawable(iconKind, ink, isz, if (withText) t else null, gap))
        }
        t.background = if (layers.size == 1) inset else android.graphics.drawable.LayerDrawable(layers.toTypedArray())
        if (rip) t.background = KeyAnim.ripple(t.background, dp(Prefs.radius(this)).toFloat(), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), th.accent)
        val lp = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), w)
        t.layoutParams = lp
        if (altsOf != null) {
            // ketuk = langsung mengetik; tahan = popup grid semua alternatif, geser lalu lepas untuk memilih
            var list: List<String> = emptyList()
            var shown = false
            var hx = 0f; var hy = 0f; var lx = 0f; var ly = 0f
            val fire = Runnable {
                if (t.isAttachedToWindow && list.size > 1) {
                    shown = true; hx = lx; hy = ly
                    hidePreview(); feedback(t); showAltGrid(t, list)
                }
            }
            t.setOnTouchListener { v, e ->
                lx = e.rawX; ly = e.rawY
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        shown = false
                        list = altsOf()
                        if (!rip) bg.setColor(th.accent)
                        pressAnim(v, true, e.x, e.y)
                        onClick()
                        feedback(v)
                        if (pv != null) showPreview(v, pv)
                        main.postDelayed(fire, Prefs.holdMs(this).toLong())
                    }
                    MotionEvent.ACTION_MOVE -> if (shown && Math.hypot((e.rawX - hx).toDouble(), (e.rawY - hy).toDouble()) > dp(10)) updateAltSel(e.rawX, e.rawY)
                    MotionEvent.ACTION_UP -> {
                        main.removeCallbacks(fire)
                        if (shown) {
                            val idx = altSel
                            hideAltGrid(); shown = false
                            if (idx > 0 && idx < list.size) { del(); type(list[idx]) }
                        }
                        hidePreview(); pressAnim(v, false); if (!rip) release(bg, normal)
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        main.removeCallbacks(fire)
                        hideAltGrid(); shown = false
                        hidePreview(); pressAnim(v, false); if (!rip) release(bg, normal)
                    }
                }
                true
            }
        } else if (hold != null) {
            // ketuk = langsung mengetik saat disentuh (tanpa delay); tahan agak lama = ganti dengan karakter petunjuk
            var fired = false
            val fire = Runnable { if (t.isAttachedToWindow) { fired = true; feedback(t); hold() } }
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        fired = false
                        if (!rip) bg.setColor(th.accent)
                        pressAnim(v, true, e.x, e.y)
                        onClick()
                        feedback(v)
                        if (pv != null) showPreview(v, pv)
                        main.postDelayed(fire, Prefs.holdMs(this).toLong())
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        hidePreview(); main.removeCallbacks(fire); pressAnim(v, false); if (!rip) release(bg, normal)
                    }
                }
                true
            }
        } else if (fast) {
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { if (!rip) bg.setColor(th.accent); pressAnim(v, true, e.x, e.y); onClick(); feedback(v); if (pv != null) showPreview(v, pv) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { hidePreview(); pressAnim(v, false); if (!rip) release(bg, normal) }
                }
                true
            }
        } else {
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { if (!rip) bg.setColor(th.accent); pressAnim(v, true, e.x, e.y) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressAnim(v, false); if (!rip) release(bg, normal) }
                }
                false
            }
            t.setOnClickListener { feedback(t); onClick() }
        }
        return t
    }

    private fun backspace(w: Float): TextView {
        val t = btn("@back", w, true) {}
        var count = 0
        val rep = object : Runnable {
            override fun run() {
                count++
                if (count > 14) delWord() else del()
                main.postDelayed(this, if (count > 14) 150L else if (count > 6) 40L else 75L)
            }
        }
        t.setOnClickListener(null)
        t.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { count = 0; pressAnim(v, true, e.x, e.y); feedback(v); del(); main.postDelayed(rep, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pressAnim(v, false); main.removeCallbacks(rep) }
            }
            true
        }
        return t
    }

    /** Hapus satu kata (dipakai saat tombol hapus ditahan lama, seperti keyboard iPhone). */
    private fun delWord() {
        trDone = false
        if (inBuf) {
            var n = buf.length
            while (n > 0 && buf[n - 1] == ' ') n--
            while (n > 0 && buf[n - 1] != ' ') n--
            buf.setLength(n); updatePrompt(); return
        }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) { ic.commitText("", 1); updateSuggestions(); return }
        val b = ic.getTextBeforeCursor(40, 0)?.toString() ?: return
        if (b.isEmpty()) return
        var n = b.length
        while (n > 0 && b[n - 1] == ' ') n--
        while (n > 0 && b[n - 1] != ' ' && b[n - 1] != '\n') n--
        ic.deleteSurroundingText((b.length - n).coerceAtLeast(1), 0)
        updateSuggestions()
    }

    // ---------- gelembung pratinjau huruf (seperti keyboard iPhone) ----------
    private var pvFrame: android.widget.FrameLayout? = null
    private var pvView: TextView? = null
    private val hideRun = Runnable { hidePreview() }

    /** Gelembung di atas tombol (digambar di dalam keyboard sendiri, jadi ringan dan tanpa jeda). */
    private fun showPreview(v: View, txt: String) {
        val pv = pvView ?: return
        val fr = pvFrame ?: return
        if (!Prefs.preview(this) || !v.isAttachedToWindow) return
        val label = (v as? TextView)?.text?.toString() ?: txt
        if (label.isBlank()) return
        val a = IntArray(2); val b = IntArray(2)
        v.getLocationInWindow(a); fr.getLocationInWindow(b)
        val kx = a[0] - b[0]; val ky = a[1] - b[1]
        val kw = v.width; val kh = v.height
        val bw = kw + dp(14)
        val bh = (kh * 1.55f).toInt()
        val lp = pv.layoutParams
        if (lp.width != bw || lp.height != bh) { lp.width = bw; lp.height = bh; pv.layoutParams = lp }
        pv.text = label
        pv.x = (kx + kw / 2f - bw / 2f).coerceIn(0f, (fr.width - bw).toFloat().coerceAtLeast(0f))
        pv.y = (ky + kh - bh).toFloat().coerceAtLeast(0f)
        pv.pivotX = bw / 2f
        pv.pivotY = bh.toFloat()
        pv.animate().cancel()
        pv.alpha = 1f
        pv.scaleX = 0.9f; pv.scaleY = 0.9f
        pv.animate().scaleX(1f).scaleY(1f).setDuration(50).start()
        main.removeCallbacks(hideRun)
        main.postDelayed(hideRun, 900)
    }

    private fun hidePreview() {
        main.removeCallbacks(hideRun)
        val pv = pvView ?: return
        pv.animate().cancel()
        pv.animate().alpha(0f).setDuration(70).start()
    }

    // ---------- popup grid tahan-lama pada tombol huruf ----------
    private var altGrid: LinearLayout? = null
    private val altCells = ArrayList<TextView>()
    private var altSel = 0
    private var altCols = 1
    private var altRows = 1
    private var altCw = 0
    private var altCh = 0
    private var altPad = 0
    private var altGx = 0f
    private var altGy = 0f

    private val accentMap = mapOf(
        'a' to "\u00E1\u00E0\u00E2\u00E4\u00E3\u00E5\u00E6\u0101",
        'c' to "\u00E7\u0107\u010D",
        'd' to "\u00F0",
        'e' to "\u00E9\u00E8\u00EA\u00EB\u0113",
        'i' to "\u00ED\u00EC\u00EE\u00EF",
        'l' to "\u0142",
        'n' to "\u00F1\u0144",
        'o' to "\u00F3\u00F2\u00F4\u00F6\u00F5\u00F8\u0153",
        's' to "\u015B\u0161\u00DF",
        'u' to "\u00FA\u00F9\u00FB\u00FC\u016B",
        'y' to "\u00FD\u00FF",
        'z' to "\u017E\u017A\u017C"
    )

    /** Daftar alternatif: huruf itu sendiri (indeks 0), simbol/angka kecil, lalu huruf beraksen. */
    private fun letterAlts(c: Char, hint: String): List<String> {
        val up = shift || caps
        fun cs(x: String) = if (up) x.uppercase() else x
        val out = ArrayList<String>()
        out.add(cs(c.toString()))
        out.add(hint)
        accentMap[c]?.forEach { out.add(cs(it.toString())) }
        return out
    }

    private fun showAltGrid(v: View, items: List<String>) {
        val fr = pvFrame ?: return
        hideAltGrid()
        val n = items.size
        val cols = if (n <= 6) n else (n + 1) / 2
        val rows = (n + cols - 1) / cols
        val cw = dp(44); val ch = dp(48); val pad = dp(5)
        val inkSel = if (lum(th.accent) > 0.5) Color.BLACK else Color.WHITE
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(pad, pad, pad, pad)
        val gbg = GradientDrawable()
        gbg.cornerRadius = dp(14).toFloat()
        gbg.setColor(th.hi)
        grid.background = gbg
        grid.elevation = dp(8).toFloat()
        altCells.clear()
        for (i in 0 until n) altCells.add(TextView(this))
        // baris paling bawah = baris indeks 0 (dekat tombol), jadi digambar dari atas ke bawah secara terbalik
        for (r in rows - 1 downTo 0) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until cols) {
                val i = r * cols + c
                if (i < n) {
                    val cell = altCells[i]
                    cell.text = items[i]
                    cell.gravity = Gravity.CENTER
                    cell.textSize = 22f
                    cell.setTextColor(if (lum(th.hi) > 0.5) Color.BLACK else Color.WHITE)
                    val cb = GradientDrawable()
                    cb.cornerRadius = dp(10).toFloat()
                    cb.setColor(Color.TRANSPARENT)
                    cell.background = cb
                    row.addView(cell, LinearLayout.LayoutParams(cw, ch))
                } else {
                    row.addView(View(this), LinearLayout.LayoutParams(cw, ch))
                }
            }
            grid.addView(row)
        }
        val gw = cols * cw + pad * 2
        val gh = rows * ch + pad * 2
        val a = IntArray(2); val b = IntArray(2)
        v.getLocationInWindow(a); fr.getLocationInWindow(b)
        val kx = a[0] - b[0]; val ky = a[1] - b[1]
        altGx = (kx + v.width / 2f - cw / 2f - pad).coerceIn(0f, (fr.width - gw).toFloat().coerceAtLeast(0f))
        altGy = (ky - gh - dp(2)).toFloat().coerceAtLeast(0f)
        altCols = cols; altRows = rows; altCw = cw; altCh = ch; altPad = pad
        fr.addView(grid, android.widget.FrameLayout.LayoutParams(gw, gh))
        grid.x = altGx; grid.y = altGy
        altGrid = grid
        altSel = -1
        setAltSel(0, inkSel)
    }

    private fun setAltSel(idx: Int, inkSel: Int = if (lum(th.accent) > 0.5) Color.BLACK else Color.WHITE) {
        if (idx == altSel || idx !in altCells.indices) return
        val normalInk = if (lum(th.hi) > 0.5) Color.BLACK else Color.WHITE
        if (altSel in altCells.indices) {
            (altCells[altSel].background as? GradientDrawable)?.setColor(Color.TRANSPARENT)
            altCells[altSel].setTextColor(normalInk)
        }
        (altCells[idx].background as? GradientDrawable)?.setColor(th.accent)
        altCells[idx].setTextColor(inkSel)
        if (altSel >= 0 && Prefs.haptic(this)) altCells[idx].performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        altSel = idx
    }

    /** Cari sel terdekat dari posisi jari (selalu memilih sel terdekat, tidak ada keadaan "kosong"). */
    private fun updateAltSel(rawX: Float, rawY: Float) {
        val fr = pvFrame ?: return
        if (altGrid == null || altCells.isEmpty()) return
        val loc = IntArray(2)
        fr.getLocationOnScreen(loc)
        val x = rawX - loc[0] - altGx - altPad
        val y = rawY - loc[1] - altGy - altPad
        val col = (x / altCw).toInt().coerceIn(0, altCols - 1)
        val rowTop = (y / altCh).toInt().coerceIn(0, altRows - 1)
        val r = altRows - 1 - rowTop
        setAltSel((r * altCols + col).coerceIn(0, altCells.size - 1))
    }

    private fun hideAltGrid() {
        val g = altGrid ?: return
        (g.parent as? android.view.ViewGroup)?.removeView(g)
        altGrid = null
        altCells.clear()
        altSel = 0
    }

    // ---------- geser di spasi = gerakkan kursor (seperti trackpad iPhone) ----------
    private fun attachTrackpad(t: View) {
        var x0 = 0f
        var last = 0
        var track = false
        var fired = false
        var moved = false
        val fire = Runnable {
            if (!t.isAttachedToWindow) return@Runnable
            fired = true; track = true
            del()   // batalkan spasi yang sudah terketik saat disentuh
            t.alpha = 0.55f
            if (Prefs.haptic(this)) t.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
        t.setOnTouchListener { v, e ->
            val hm = Prefs.holdMs(this)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.x; last = 0; fired = false; moved = false; track = false
                    pressAnim(v, true, e.x, e.y)
                    spaceTap()          // spasi langsung terketik saat disentuh, tanpa menunggu
                    feedback(v)
                    if (hm > 0) main.postDelayed(fire, hm.toLong())
                }
                MotionEvent.ACTION_MOVE -> if (track) {
                    val step = ((e.x - x0) / dp(14)).toInt()
                    if (step != last) {
                        val d = step - last
                        last = step
                        moved = true
                        if (!inBuf) repeat(Math.abs(d)) { key(if (d > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT) }
                        if (Prefs.haptic(this)) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(fire); pressAnim(v, false); v.alpha = 1f
                    if (fired && !moved) switchKeyboard()
                    track = false
                }
                MotionEvent.ACTION_CANCEL -> { main.removeCallbacks(fire); pressAnim(v, false); v.alpha = 1f; track = false }
            }
            true
        }
    }

    // ---------- input ----------
    private fun del() {
        trDone = false
        t9Key = -1
        if (inBuf) {
            if (buf.isNotEmpty()) buf.setLength(buf.offsetByCodePoints(buf.length, -1))
            updatePrompt(); return
        }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
        scheduleSuggest()
    }

    private fun type(s: String) {
        trDone = false
        t9Key = -1
        if (inBuf) { buf.append(s); updatePrompt(); return }
        currentInputConnection?.commitText(s, 1)
        scheduleSuggest()
    }

    /** Ketikan dari tombol huruf/angka: ikut gaya font aktif dari tombol Aa. */
    private fun typeStyled(s: String) {
        val name = Prefs.activeStyleName(this)
        val fn = if (name.isEmpty() || inBuf) null else styleList.firstOrNull { it.first == name }?.second
        if (fn != null) type(fn(s)) else type(s)
    }

    private fun typeEmoji(e: String) {
        type(e)
        recent.remove(e); recent.add(0, e)
        while (recent.size > 40) recent.removeAt(recent.size - 1)
        Prefs.setRecent(this, recent.joinToString(" "))
    }

    private fun enter() {
        if (addClip) { buf.append("\n"); updatePrompt(); return }
        if (promptMode) { sendPrompt(); return }
        val ic = currentInputConnection ?: return
        if (Stash.autoTr(this)) {
            if (trDone) trDone = false
            else if (translateBeforeSend()) return
        }
        if (!host.editorAction()) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        main.postDelayed({ autoShift(); updateSuggestions() }, 60)
    }

    private fun spaceTap() {
        if (inBuf) { buf.append(" "); updatePrompt(); return }
        val ic = currentInputConnection ?: return
        val w = curWord().lowercase()
        if (w.length >= 2) {
            val hit = snipList().firstOrNull { it.first.isNotEmpty() && it.first.equals(w, true) }
            if (hit != null) {
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(hit.second + " ", 1)
                autoShift(); updateSuggestions()
                return
            }
            wordFreq[w] = (wordFreq[w] ?: 0) + 1
        }
        val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (Prefs.dblSpace(this) && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
        } else ic.commitText(" ", 1)
        autoShift()
        updateSuggestions()
    }

    private fun autoShift() {
        if (inBuf) return
        if (!Prefs.autoCap(this) || mode != "letters" || caps) return
        val b = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        val want = b.isEmpty() || b.endsWith(". ") || b.endsWith("! ") || b.endsWith("? ") || b.endsWith("\n")
        if (want != shift) { shift = want; refreshCase() }
    }

    private fun key(code: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun switchKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun lum(c: Int) = androidx.core.graphics.ColorUtils.calculateLuminance(c)
    private fun blend(a: Int, b: Int, r: Float) = androidx.core.graphics.ColorUtils.blendARGB(a, b, r)

    private fun go(m: String) {
        if (m in subs && mode !in subs) backTo = mode
        mode = m
        render()
    }

    private fun toolIcon(kind: String, circle: Boolean, onClick: () -> Unit): View {
        val sz = dp(Prefs.tbH(this) + 6)
        val v = View(this)
        val layers = ArrayList<android.graphics.drawable.Drawable>()
        if (circle) {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(blend(tbBg, th.text, 0.18f))
            layers.add(g)
        }
        layers.add(IconDrawable(kind, th.text, dp(22).toFloat()))
        v.background = android.graphics.drawable.LayerDrawable(layers.toTypedArray())
        val lp = LinearLayout.LayoutParams(sz, sz)
        lp.setMargins(dp(5), 0, dp(5), 0)
        v.layoutParams = lp
        v.setOnClickListener { feedback(v); onClick() }
        return v
    }

    private fun fillToolbar() {
        toolbar.removeAllViews()
        val inMain = mode == "letters" && !addClip
        toolbar.visibility = if (mode in subs) View.GONE else View.VISIBLE
        if (inMain) toolbar.addView(toolIcon("grid", true) { go("menu") })
        else toolbar.addView(toolIcon("arrowback", true) { addClip = false; promptMode = false; buf.setLength(0); aiAnswer = null; mode = "letters"; render() })
        toolbar.addView(toolIcon("palette", false) { go("theme") })
        toolbar.addView(toolIcon("mic", false) { startVoice() })
        if (Prefs.clipBar(this)) toolbar.addView(toolIcon("clip", false) { go("clip") })
        val sp = View(this)
        sp.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        toolbar.addView(sp)
        if (host.overlay) {
            val st = tb("@stop STOP", Color.parseColor("#D32F2F")) { host.stopPermanent() }
            st.setTextColor(Color.WHITE)
            st.layoutParams = LinearLayout.LayoutParams(dp(Prefs.tbW(this) + 16), dp(Prefs.tbH(this))).also { it.setMargins(dp(2), dp(2), dp(2), dp(2)) }
            toolbar.addView(st)
            toolbar.addView(toolIcon("down", false) { host.collapse() })
        }
    }

    private fun render() {
        hidePreview()
        body.removeAllViews()
        say(null)
        fillToolbar()
        dialogHost.removeAllViews()
        saveBtn = null
        if (addClip && mode == "letters") {
            dialogHost.visibility = View.VISIBLE
            addClipDialog()
        } else dialogHost.visibility = View.GONE
        when (mode) {
            "letters" -> letters()
            "symbols" -> symbols()
            "emoji" -> emoji()
            "clip" -> clipboard()
            "snip" -> snippets()
            "style" -> styles()
            "ai" -> ai()
            "hist" -> aiHistory()
            "menu" -> menu()
            "theme" -> themeScreen()
            "edit" -> editScreen()
            "ctrl" -> ctrlScreen()
            "confirm" -> confirmScreen()
        }
        updateSuggestions()
        val k = mode + promptMode
        if (k != lastKey) {
            lastKey = k
            KeyAnim.transition(body, Prefs.animTrans(this), Prefs.animSpeed(this) / 100f, resources.displayMetrics.density)
        }
    }

    private fun langName(): String {
        val v = Prefs.voiceLang(this)
        return when (v.substringBefore('-').lowercase()) {
            "id" -> "Bahasa Indonesia"
            "en" -> "English"
            "ms" -> "Bahasa Melayu"
            else -> v
        }
    }

    // ---------- menu (grid fitur) ----------
    private fun panelH(): Int = dp((Prefs.keyHeightDp(this) + 2 * Prefs.gapY(this)) * (if (Prefs.numRow(this)) 5 else 4))
    private fun fullH(): Int = panelH() + dp(Prefs.tbH(this) + 12)

    private fun tile(kind: String, label: String, onClick: () -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        val box = View(this)
        val g = GradientDrawable()
        g.cornerRadius = dp(10).toFloat()
        g.setColor(th.key)
        box.background = android.graphics.drawable.LayerDrawable(arrayOf(g, IconDrawable(kind, th.text, dp(26).toFloat())))
        box.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).also { it.setMargins(dp(5), dp(3), dp(5), dp(3)) }
        val tv = TextView(this)
        tv.text = label
        tv.setTextColor(th.text)
        tv.textSize = 11.5f
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        col.addView(box)
        col.addView(tv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        col.setOnClickListener { feedback(col); onClick() }
        col.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }
            false
        }
        return col
    }

    private fun tileGrid(tiles: List<Triple<String, String, () -> Unit>>, height: Int): View {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(2), dp(4), dp(2), dp(4))
        tiles.chunked(4).forEach { chunk ->
            val r = row()
            chunk.forEach { (k, l, a) ->
                val t = tile(k, l, a)
                t.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                r.addView(t)
            }
            repeat(4 - chunk.size) {
                val sp = View(this)
                sp.layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                r.addView(sp)
            }
            col.addView(r)
        }
        sv.addView(col)
        return sv
    }

    private fun menu() {
        val tiles = ArrayList<Triple<String, String, () -> Unit>>()
        tiles.add(Triple("palette", "Tema", { go("theme") }))
        tiles.add(Triple("fonttile", "Font", { mode = "style"; render() }))
        tiles.add(Triple("clip", "Klipboard", { go("clip") }))
        tiles.add(Triple("cursor", "Pengeditan teks", { go("edit") }))
        tiles.add(Triple("speaker", "Kecerahan & volume", { go("ctrl") }))
        tiles.add(Triple("translate", "Menerjemahkan", {
            mode = "letters"; render()
            runAi("Translate to ${Prefs.lang(this)}. Output only the translation.", true)
        }))
        tiles.add(Triple("globe", "Bahasa", { switchKeyboard() }))
        tiles.add(Triple("numrow", "Baris Angka", {
            Prefs.setNumRow(this, !Prefs.numRow(this)); render()
            say(if (Prefs.numRow(this)) "Baris angka dinyalakan." else "Baris angka dimatikan.")
        }))
        tiles.add(Triple("speaker", "Suara dan Getaran", {
            val h = Prefs.haptic(this); val so = Prefs.sound(this)
            val msg = if (h && !so) { Prefs.setSound(this, true); "Getaran + suara ketik." }
                else if (h && so) { Prefs.setHaptic(this, false); Prefs.setSound(this, false); "Getaran dan suara mati." }
                else { Prefs.setHaptic(this, true); Prefs.setSound(this, false); "Getaran saja." }
            render(); say(msg)
        }))
        tiles.add(Triple("sparkle", "AI", { mode = "ai"; render() }))
        tiles.add(Triple("smile", "Emoji", { mode = "emoji"; render() }))
        tiles.add(Triple("bolt", "Teks cepat", { mode = "snip"; render() }))
        tiles.add(Triple("read", "Baca layar", { mode = "letters"; render(); readScreen() }))
        tiles.add(Triple("at", "Pratinjau huruf", {
            Prefs.setPreview(this, !Prefs.preview(this)); render()
            say(if (Prefs.preview(this)) "Pratinjau huruf dinyalakan." else "Pratinjau huruf dimatikan.")
        }))
        tiles.add(Triple("t:Tahan", "Tahan huruf", {
            val cur = Prefs.holdMs(this)
            val next = if (cur == 0) 400 else 0
            Prefs.setHoldMs(this, next)
            render()
            say(if (next == 0) "Tahan huruf mati: ketikan murni, tanpa jeda." else "Tahan huruf nyala (${next} ms): tahan = popup angka, simbol, dan huruf beraksen.")
        }))
        tiles.add(Triple("textsize", "Ukuran tombol", {
            val hs = listOf(48, 56, 64)
            val cur = Prefs.keyHeightDp(this)
            val next = hs.firstOrNull { it > cur } ?: hs[0]
            Prefs.setKeyHeightDp(this, next)
            host.rebuild()
        }))
        tiles.add(Triple("at", "Simbol", { mode = "symbols"; render() }))
        tiles.add(Triple("swap", "Satu tangan", {
            Prefs.setHand(this, (Prefs.hand(this) + 1) % 3)
            host.rebuild()
        }))
        if (host.overlay) tiles.add(Triple("stop", "Hentikan sematan", { host.stopPermanent() }))
        else tiles.add(Triple("pin", "Sematkan", { startPermanent() }))
        tiles.add(Triple("gear", "Pengaturan", {
            val i = Intent(this, SettingsActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }))
        body.addView(tileGrid(tiles, panelH()))
    }

    // ---------- layar penuh (Tema, Klipboard, Pengeditan teks) ----------
    private fun iconBtn(kind: String, onClick: () -> Unit): View {
        val v = View(this)
        v.background = IconDrawable(kind, th.text, dp(22).toFloat())
        v.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        v.setOnClickListener { feedback(v); onClick() }
        return v
    }

    private fun subHeader(title: String): View {
        val r = row()
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(4), dp(2), dp(4), dp(2))
        r.addView(iconBtn("arrowback") { mode = backTo; render() })
        val t = TextView(this)
        t.text = title
        t.setTextColor(th.text)
        t.textSize = 17f
        t.setPadding(dp(10), 0, 0, 0)
        r.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(iconBtn("keyboard") { mode = "letters"; render() })
        return r
    }

    private fun roundedBg(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(r).toFloat()
        g.setColor(color)
        return g
    }

    private fun screenShell(title: String, build: (LinearLayout) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, fullH())
        box.addView(subHeader(title))
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        sv.setPadding(dp(4), 0, dp(4), dp(4))
        sv.clipToPadding = false
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = roundedBg(blend(th.bg, th.text, 0.10f), 8)
        card.setPadding(dp(12), dp(8), dp(12), dp(10))
        build(card)
        sv.addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        box.addView(sv)
        body.addView(box)
    }

    private fun sectionLabel(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(blend(th.bg, th.text, 0.65f))
        v.textSize = 14f
        v.setPadding(dp(2), dp(8), 0, dp(6))
        return v
    }

    private fun divider(): View {
        val d = View(this)
        d.setBackgroundColor(blend(th.bg, th.text, 0.18f))
        d.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).also { it.setMargins(0, dp(4), 0, dp(4)) }
        return d
    }

    private fun themeDot(t: KbTheme, idx: Int, selected: Boolean): View {
        val v = View(this)
        v.background = ThemeDotDrawable(t, selected)
        v.layoutParams = LinearLayout.LayoutParams(dp(58), dp(58)).also { it.setMargins(dp(6), dp(4), dp(6), dp(4)) }
        v.setOnClickListener { feedback(v); Prefs.setTheme(this, idx); host.rebuild() }
        return v
    }

    private fun themeScreen() {
        screenShell("Tema") { card ->
            val sel = Prefs.theme(this)
            card.addView(sectionLabel("Tema Khusus"))
            val r0 = row()
            r0.addView(themeDot(Prefs.customTheme(this), 4, sel == 4))
            card.addView(r0)
            val hint = TextView(this)
            hint.text = "Warna tema khusus diubah di aplikasi Romaboard (Pengaturan)."
            hint.setTextColor(blend(th.bg, th.text, 0.55f)); hint.textSize = 11f
            hint.setPadding(dp(2), 0, 0, dp(4))
            card.addView(hint)
            card.addView(sectionLabel("Tema Keyboard"))
            val ids = Prefs.themes.indices.filter { it != 4 }
            ids.chunked(4).forEach { chunk ->
                val r = row()
                chunk.forEach { i -> r.addView(themeDot(Prefs.themes[i], i, sel == i)) }
                card.addView(r)
            }
            val names = TextView(this)
            names.text = ids.joinToString(" · ") { Prefs.themes[it].name }
            names.setTextColor(blend(th.bg, th.text, 0.55f)); names.textSize = 11f
            names.setPadding(dp(2), dp(2), 0, 0)
            card.addView(names)
        }
    }

    // ---------- kontrol perangkat: kecerahan, volume, mode dering, rotasi ----------
    private fun ctrlSlider(card: LinearLayout, title: String, max: Int, cur: Int, fmt: (Int) -> String, set: (Int) -> Unit) {
        val lbl = TextView(this)
        lbl.setTextColor(th.text); lbl.textSize = 14f
        lbl.text = title + ": " + fmt(cur)
        lbl.setPadding(dp(2), dp(8), 0, 0)
        val sb = android.widget.SeekBar(this)
        sb.max = max
        sb.progress = cur.coerceIn(0, max)
        val tintList = android.content.res.ColorStateList.valueOf(th.accent)
        sb.progressTintList = tintList
        sb.thumbTintList = tintList
        sb.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                lbl.text = title + ": " + fmt(p)
                try { set(p) } catch (e: Exception) { say("Tidak bisa mengubah ini (butuh izin).") }
            }
            override fun onStartTrackingTouch(s: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(s: android.widget.SeekBar?) {}
        })
        card.addView(lbl)
        card.addView(sb)
    }

    private fun ctrlPill(label: String, selected: Boolean, onClick: () -> Unit): TextView {
        val ink = if (selected) (if (lum(th.accent) > 0.5) Color.BLACK else Color.WHITE) else th.text
        val b = pillBtn(label, if (selected) th.accent else th.hi, ink, null) { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).also { it.setMargins(dp(3), dp(4), dp(3), dp(4)) }
        return b
    }

    private fun openSettingsScreen(action: String, withPkg: Boolean) {
        try {
            val i = Intent(action)
            if (withPkg) i.data = android.net.Uri.parse("package:" + packageName)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) { say("Tidak bisa membuka pengaturan.") }
    }

    private fun ctrlScreen() {
        screenShell("Kecerahan & volume") { card ->
            val cr = contentResolver
            val canWrite = android.provider.Settings.System.canWrite(this)
            card.addView(sectionLabel("Layar"))
            if (!canWrite) {
                val r = row()
                val grant = pillBtn("Beri izin ubah pengaturan sistem", th.accent, if (lum(th.accent) > 0.5) Color.BLACK else Color.WHITE, null) {
                    openSettingsScreen(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, true)
                }
                grant.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).also { it.setMargins(dp(3), dp(4), dp(3), dp(4)) }
                r.addView(grant)
                card.addView(r)
            }
            val br = try { android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Exception) { 128 }
            ctrlSlider(card, "Kecerahan", 255, br, { (it * 100 / 255).toString() + "%" }) { p ->
                if (!android.provider.Settings.System.canWrite(this)) { say("Beri izin dulu (tombol di atas)."); return@ctrlSlider }
                android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(1))
            }
            val autoOn = try { android.provider.Settings.System.getInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE, 0) == 1 } catch (e: Exception) { false }
            val rotOn = try { android.provider.Settings.System.getInt(cr, android.provider.Settings.System.ACCELEROMETER_ROTATION, 0) == 1 } catch (e: Exception) { false }
            val r1 = row()
            r1.addView(ctrlPill("Kecerahan otomatis: " + (if (autoOn) "ON" else "OFF"), autoOn) {
                if (!android.provider.Settings.System.canWrite(this)) { say("Beri izin dulu (tombol di atas).") }
                else {
                    android.provider.Settings.System.putInt(cr, android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE,
                        if (autoOn) android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL else android.provider.Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC)
                    render()
                }
            })
            r1.addView(ctrlPill("Rotasi otomatis: " + (if (rotOn) "ON" else "OFF"), rotOn) {
                if (!android.provider.Settings.System.canWrite(this)) { say("Beri izin dulu (tombol di atas).") }
                else {
                    android.provider.Settings.System.putInt(cr, android.provider.Settings.System.ACCELEROMETER_ROTATION, if (rotOn) 0 else 1)
                    render()
                }
            })
            card.addView(r1)
            card.addView(divider())

            card.addView(sectionLabel("Volume"))
            val streams = listOf(
                Pair("Media", AudioManager.STREAM_MUSIC),
                Pair("Dering", AudioManager.STREAM_RING),
                Pair("Alarm", AudioManager.STREAM_ALARM),
                Pair("Notifikasi", AudioManager.STREAM_NOTIFICATION)
            )
            for ((name, st) in streams) {
                val mx = audio.getStreamMaxVolume(st).coerceAtLeast(1)
                ctrlSlider(card, name, mx, audio.getStreamVolume(st), { (it * 100 / mx).toString() + "%" }) { p ->
                    audio.setStreamVolume(st, p, 0)
                }
            }
            card.addView(divider())

            card.addView(sectionLabel("Mode dering"))
            val cur = audio.ringerMode
            val r2 = row()
            val modes = listOf(Pair("Suara", AudioManager.RINGER_MODE_NORMAL), Pair("Getar", AudioManager.RINGER_MODE_VIBRATE), Pair("Senyap", AudioManager.RINGER_MODE_SILENT))
            for ((label, m) in modes) {
                r2.addView(ctrlPill(label, cur == m) {
                    try { audio.ringerMode = m; render() }
                    catch (e: SecurityException) {
                        say("Mode dering butuh izin Jangan Ganggu untuk Romaboard.")
                        openSettingsScreen(android.provider.Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, false)
                    }
                })
            }
            card.addView(r2)
        }
    }

    private fun editScreen() {
        screenShell("Pengeditan teks") { card ->
            val tiles = listOf<Triple<String, String, () -> Unit>>(
                Triple("left", "Kiri", { key(KeyEvent.KEYCODE_DPAD_LEFT) }),
                Triple("up", "Atas", { key(KeyEvent.KEYCODE_DPAD_UP) }),
                Triple("down", "Bawah", { key(KeyEvent.KEYCODE_DPAD_DOWN) }),
                Triple("right", "Kanan", { key(KeyEvent.KEYCODE_DPAD_RIGHT) }),
                Triple("t:Home", "Awal baris", { key(KeyEvent.KEYCODE_MOVE_HOME) }),
                Triple("t:End", "Akhir baris", { key(KeyEvent.KEYCODE_MOVE_END) }),
                Triple("t:All", "Pilih semua", { currentInputConnection?.performContextMenuAction(android.R.id.selectAll); Unit }),
                Triple("back", "Hapus", { del() }),
                Triple("copy", "Salin", { currentInputConnection?.performContextMenuAction(android.R.id.copy); Unit }),
                Triple("t:Cut", "Potong", { currentInputConnection?.performContextMenuAction(android.R.id.cut); Unit }),
                Triple("insert", "Tempel", { currentInputConnection?.performContextMenuAction(android.R.id.paste); Unit }),
                Triple("undo", "Batal AI", { undoAi() })
            )
            tiles.chunked(4).forEach { chunk ->
                val r = row()
                chunk.forEach { (k, l, a) ->
                    val t = tile(k, l, a)
                    t.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    r.addView(t)
                }
                card.addView(r)
            }
        }
    }

    private fun ask(act: () -> Unit) {
        confirmAct = act
        confirmBack = mode
        mode = "confirm"
        render()
    }

    private fun pillBtn(label: String, fill: Int?, ink: Int, stroke: Int?, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextColor(ink)
        t.textSize = 15f
        t.typeface = android.graphics.Typeface.DEFAULT_BOLD
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        if (fill != null) g.setColor(fill)
        if (stroke != null) g.setStroke(dp(2), stroke)
        t.background = g
        t.setOnClickListener { feedback(t); onClick() }
        return t
    }

    private fun confirmScreen() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, fullH())
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = roundedBg(blend(th.bg, th.text, 0.16f), 26)
        card.setPadding(dp(22), dp(22), dp(22), dp(18))
        val t = TextView(this)
        t.text = "Apakah Anda yakin akan menghapus isinya?"
        t.setTextColor(th.text)
        t.textSize = 18f
        t.typeface = android.graphics.Typeface.DEFAULT_BOLD
        card.addView(t)
        val r = row()
        r.setPadding(0, dp(20), 0, 0)
        val cancel = pillBtn("Batalkan", null, th.hi, th.hi) { confirmAct = null; mode = confirmBack; render() }
        val ok = pillBtn("Menghapus", th.hi, if (lum(th.hi) > 0.5) Color.BLACK else Color.WHITE, null) {
            confirmAct?.invoke(); confirmAct = null; mode = confirmBack; render()
        }
        cancel.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).also { it.setMargins(0, 0, dp(6), 0) }
        ok.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).also { it.setMargins(dp(6), 0, 0, 0) }
        r.addView(cancel); r.addView(ok)
        card.addView(r)
        box.addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also { it.setMargins(dp(20), 0, dp(20), 0) })
        body.addView(box)
    }

    // ---------- tambah klip baru ----------
    private fun styleSave() {
        val b = saveBtn ?: return
        val on = buf.isNotBlank()
        val g = GradientDrawable()
        g.cornerRadius = dp(24).toFloat()
        g.setColor(if (on) th.hi else blend(th.bg, th.text, 0.22f))
        b.background = g
        b.setTextColor(if (on) (if (lum(th.hi) > 0.5) Color.BLACK else Color.WHITE) else blend(th.bg, th.text, 0.5f))
    }

    private fun addClipDialog() {
        dialogHost.setBackgroundColor(blend(th.bg, th.text, 0.05f))
        dialogHost.setPadding(dp(14), dp(12), dp(14), dp(12))
        val title = TextView(this)
        title.text = "Tambahkan klip baru"
        title.setTextColor(th.text)
        title.textSize = 17f
        title.gravity = Gravity.CENTER
        dialogHost.addView(title)
        val tv = TextView(this)
        tv.setTextColor(th.text)
        tv.textSize = 15f
        tv.setPadding(dp(14), dp(12), dp(14), dp(12))
        val sv = ScrollView(this)
        sv.addView(tv)
        sv.background = roundedBg(blend(th.bg, Color.BLACK, 0.25f), 14)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(96)).also { it.setMargins(0, dp(10), 0, dp(10)) }
        promptView = tv
        promptScroll = sv
        dialogHost.addView(sv)
        val r = row()
        val cancel = pillBtn("Batalkan", null, th.hi, th.hi) { addClip = false; buf.setLength(0); mode = "clip"; render() }
        val save = pillBtn("Menyimpan", null, th.text, null) {
            val t = buf.toString().trim()
            if (t.isNotEmpty()) {
                pins.remove(t); pins.add(0, t); Stash.setPins(this, pins)
                addClip = false; buf.setLength(0); mode = "clip"; render()
            }
        }
        saveBtn = save
        cancel.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).also { it.setMargins(0, 0, dp(6), 0) }
        save.layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).also { it.setMargins(dp(6), 0, 0, 0) }
        r.addView(cancel); r.addView(save)
        dialogHost.addView(r)
        updatePrompt()
    }

    private fun bottomRow(label: String, target: String): LinearLayout {
        val bottom = row()
        val wp = Prefs.wPunct(this) / 100f
        val hl = Prefs.holdMs(this) > 0
        bottom.addView(btn(label, Prefs.wMode(this) / 100f, true, 15f, true) { mode = target; render() })
        bottom.addView(btn("@smile", wp, true, 16f, true) { mode = "emoji"; render() })
        bottom.addView(btn(",", wp, false, 18f, true, hint = "@mic", hold = if (hl) ({ del(); startVoice() }) else null) { type(",") })
        bottom.addView(btn("\u25C2  " + langName() + "  \u25B8", Prefs.wSpace(this) / 100f, false, 14f, true, hint = "@globe") { spaceTap() }.also { attachTrackpad(it) })
        bottom.addView(btn(".", wp, false, 18f, true, hint = "!?", hold = if (hl) ({ del(); type("!") }) else null) { type(".") })
        bottom.addView(btn(if (promptMode) "@send" else "@enter", Prefs.wEnter(this) / 100f, true, 18f, true, iconInk = th.hi) { enter() })
        return bottom
    }

    private fun spacer(w: Float): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(0, 1, w)
        return v
    }

    private fun letters() {
        if (promptMode) {
            val ans = aiAnswer
            if (ans != null) {
                val sv = ScrollView(this)
                val av = TextView(this)
                av.setTextColor(th.text); av.textSize = 14f
                av.setPadding(dp(10), dp(6), dp(10), dp(6))
                av.text = ans
                sv.addView(av)
                val bga = GradientDrawable(); bga.cornerRadius = dp(8).toFloat(); bga.setColor(th.fn)
                sv.background = bga
                val lpa = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(110)); lpa.setMargins(dp(2), dp(3), dp(2), dp(3))
                sv.layoutParams = lpa
                body.addView(sv)
                val ar = row()
                ar.addView(btn("@insert Taruh semua", 2.2f, true, 14f, false, th.accent) { insertAnswer() })
                ar.addView(btn("@copy Salin", 1.6f, true, 14f) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("AI", ans)); say("Disalin.")
                })
                ar.addView(btn("@close", 0.8f, true) { aiAnswer = null; render() })
                body.addView(ar)
            }
            val h = row()
            val tv = TextView(this)
            tv.setTextColor(th.text); tv.textSize = 14f
            tv.setPadding(dp(10), dp(6), dp(10), dp(6))
            val sv = ScrollView(this)
            sv.addView(tv)
            val bgp = GradientDrawable(); bgp.cornerRadius = dp(8).toFloat(); bgp.setColor(th.fn)
            sv.background = bgp
            val lp = LinearLayout.LayoutParams(0, dp(56), 4f); lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            sv.layoutParams = lp
            promptView = tv
            promptScroll = sv
            h.addView(sv)
            h.addView(btn("@close", 0.8f, true) { promptMode = false; buf.setLength(0); aiAnswer = null; screenCtx = ""; render() })
            h.addView(btn("Kirim", 1.3f, true, 14f) { sendPrompt() })
            body.addView(h)
            updatePrompt()
        }
        if (Prefs.layout(this) == 5) { t9(); return }
        if (Prefs.numRow(this)) {
            val nr = row()
            nr.weightSum = 10f
            for (c in "1234567890") nr.addView(btn(c.toString(), 1f, false, 20f, true, pv = "\u2022") { typeStyled(c.toString()) })
            body.addView(nr)
        }
        val rows = layoutRows()
        val pools = listOf(if (Prefs.numRow(this)) "%\\|=[]<>{}" else "1234567890", "@#\$_&-+()/", "*\"':;!?/,.")
        letterKeys.clear()
        shiftKey = null
        for ((i, r) in rows.withIndex()) {
            val row = row()
            row.weightSum = 10f   // semua tombol huruf di satu baris sama lebar
            val n = r.length
            val edge = if (i == 2 && n > 7) 0.95f else (10f - n) / 2f
            val kw = if (i == 2 && n > 7) (10f - 2 * edge) / n else 1f
            val sw = (Prefs.wShift(this) / 100f).coerceAtMost(edge)
            shiftW = sw
            if (i != 2 && edge > 0.001f) row.addView(spacer(edge))
            if (i == 2) {
                val sk = shiftBtn(sw)
                shiftKey = sk
                row.addView(sk)
                if (edge - sw > 0.001f) row.addView(spacer(edge - sw))
            }
            for ((j, c) in r.withIndex()) {
                val hn = pools[i].getOrElse(j) { ' ' }.toString()
                val canHold = Prefs.holdMs(this) > 0
                val k = btn(cased(c), kw, false, 22f, true, hint = hn, pv = "\u2022", altsOf = if (canHold) ({ letterAlts(c, hn) }) else null) {
                    typeStyled(cased(c))
                    if (shift) { shift = false; refreshCase() }
                }
                letterKeys.add(Pair(k, c))
                row.addView(k)
            }
            if (i != 2 && edge > 0.001f) row.addView(spacer(edge))
            if (i == 2) {
                if (edge - sw > 0.001f) row.addView(spacer(edge - sw))
                row.addView(backspace(sw))
            }
            body.addView(row)
        }
        body.addView(bottomRow("?123", "symbols"))
    }

    private var shiftW = 1f

    private fun layoutRows(): List<String> = when (Prefs.layout(this)) {
        1 -> listOf("',.pyfgcrl", "aoeuidhtns", "qjkxbmwvz")      // Dvorak
        2 -> listOf("qwfpgjluy;", "arstdhneio", "zxcvbkm")        // Colemak
        3 -> listOf("azertyuiop", "qsdfghjklm", "wxcvbn")         // AZERTY
        4 -> listOf("qwertzuiop", "asdfghjkl", "yxcvbnm")         // QWERTZ
        else -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    }

    // ---------- T9 / Numerik: ketuk berulang untuk huruf berikutnya, tahan = angka ----------
    private val t9Letters = listOf(".,?!'", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz")
    private var t9Key = -1
    private var t9Idx = 0
    private var t9Time = 0L
    private var t9Up = false

    private fun t9Tap(d: Int) {
        val set = t9Letters[d - 1]
        val now = System.currentTimeMillis()
        if (d == t9Key && now - t9Time < 900) {
            t9Idx = (t9Idx + 1) % set.length
            del()
        } else {
            t9Idx = 0
            t9Up = (shift || caps) && d != 1
        }
        val ch = set[t9Idx]
        type(if (t9Up) ch.uppercaseChar().toString() else ch.toString())
        t9Key = d; t9Time = now
        if (shift) { shift = false; refreshCase() }
    }

    private fun t9() {
        val canHold = Prefs.holdMs(this) > 0
        fun kk(d: Int, label: String): TextView {
            val k = btn(label, 1f, false, 17f, true, hold = if (canHold) ({ del(); type(d.toString()) }) else null) {
                if (d == 0) spaceTap() else t9Tap(d)
            }
            k.maxLines = 2
            return k
        }
        letterKeys.clear()
        val r1 = row()
        r1.addView(kk(1, "1\n.,?!")); r1.addView(kk(2, "2\nABC")); r1.addView(kk(3, "3\nDEF")); r1.addView(backspace(1f))
        body.addView(r1)
        val r2 = row()
        r2.addView(kk(4, "4\nGHI")); r2.addView(kk(5, "5\nJKL")); r2.addView(kk(6, "6\nMNO"))
        shiftW = 1f
        val sk = shiftBtn(1f)
        shiftKey = sk
        r2.addView(sk)
        body.addView(r2)
        val r3 = row()
        r3.addView(kk(7, "7\nPQRS")); r3.addView(kk(8, "8\nTUV")); r3.addView(kk(9, "9\nWXYZ"))
        r3.addView(btn(if (promptMode) "@send" else "@enter", 1f, true, 18f, true, iconInk = th.hi) { enter() })
        body.addView(r3)
        val r4 = row()
        r4.addView(btn("?123", 1f, true, 15f, true) { mode = "symbols"; render() })
        r4.addView(kk(0, "0\nspasi"))
        r4.addView(btn("@smile", 1f, true, 16f, true) { mode = "emoji"; render() })
        r4.addView(btn(".", 1f, false, 20f, true) { type(".") })
        body.addView(r4)
    }

    private val letterKeys = ArrayList<Pair<TextView, Char>>()
    private var shiftKey: TextView? = null

    private fun cased(c: Char): String = if (shift || caps) c.uppercaseChar().toString() else c.toString()

    private fun shiftBtn(w: Float): TextView =
        btn(if (caps) "@caps" else if (shift) "@shift_on" else "@shift", w, true, 18f, true) {
            val now = System.currentTimeMillis()
            if (caps) { caps = false; shift = false }
            else if (shift && now - lastShift < 400) { caps = true; shift = false }
            else if (shift) { shift = false }
            else { shift = true }
            lastShift = now
            refreshCase()
        }

    /** Ganti huruf besar/kecil di tempat (tanpa membangun ulang seluruh keyboard supaya tidak ada jeda). */
    private fun refreshCase() {
        val old = shiftKey
        val parent = old?.parent as? LinearLayout
        if (mode != "letters" || old == null || parent == null || (letterKeys.isEmpty() && Prefs.layout(this) != 5)) { render(); return }
        for ((k, c) in letterKeys) k.text = cased(c)
        val idx = parent.indexOfChild(old)
        val nk = shiftBtn(shiftW)
        parent.removeViewAt(idx)
        parent.addView(nk, idx)
        shiftKey = nk
    }

    private fun tabStrip(labels: List<String>, selected: Int, onSel: (Int) -> Unit): View {
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val r = row()
        labels.forEachIndexed { i, l ->
            val b = btn(l, 1f, selected != i, 16f) { onSel(i) }
            b.layoutParams = LinearLayout.LayoutParams(dp(52), dp(Prefs.keyHeightDp(this)))
            r.addView(b)
        }
        hs.addView(r)
        return hs
    }

    /** Grid 8 kolom yang bisa di-scroll; baris diisi bertahap supaya tab besar tidak lag. */
    private fun gridPanel(list: List<String>, empty: String, size: Float, fast: Boolean, click: (String) -> Unit) {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(Prefs.emoH(this)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (list.isEmpty()) {
            val t = TextView(this)
            t.text = empty
            t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
            col.addView(t)
        }
        val rows = list.chunked(8)
        fun addRows(from: Int, to: Int) {
            for (i in from until minOf(to, rows.size)) {
                val chunk = rows[i]
                val r = row()
                chunk.forEach { e -> r.addView(btn(e, 1f, false, size, fast) { click(e) }) }
                repeat(8 - chunk.size) {
                    val sp = View(this)
                    sp.layoutParams = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), 1f)
                    r.addView(sp)
                }
                col.addView(r)
            }
        }
        addRows(0, 8)
        var next = 8
        fun more() {
            if (next >= rows.size) return
            val from = next; next += 8
            col.post { addRows(from, next); more() }
        }
        more()
        sv.addView(col)
        body.addView(sv)
    }

    private fun symbols() {
        body.addView(tabStrip(listOf("123") + symGroups.map { it.first }, symTab) { symTab = it; render() })
        if (symTab == 0) {
            val rows = listOf("1234567890", "@#$%&-+()/", "*\"':;!?_=")
            for ((i, r) in rows.withIndex()) {
                val row = row()
                for (c in r) row.addView(btn(c.toString(), 1f, false, 18f, true) { type(c.toString()) })
                if (i == 2) row.addView(backspace(Prefs.wShift(this) / 100f))
                body.addView(row)
            }
            body.addView(bottomRow("ABC", "letters"))
            return
        }
        gridPanel(symGroups[symTab - 1].second, "", Prefs.emoSize(this).toFloat(), true) { type(it) }
        val kb = row()
        kb.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        kb.addView(btn("space", 5f, false, 16f) { spaceTap() })
        kb.addView(backspace(1.5f))
        body.addView(kb)
    }

    private fun emoji() {
        val labels = listOf("@clock") + emojiGroups.map { it.first }
        body.addView(tabStrip(labels, emojiTab) { emojiTab = it; render() })
        if (emojiTab > 0 && emojiGroups[emojiTab - 1].first == "(ツ)") {
            listPanel(emojiGroups[emojiTab - 1].second, "")
            val kb = row()
            kb.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
            kb.addView(btn("space", 5f, false, 16f) { spaceTap() })
            kb.addView(backspace(1.5f))
            body.addView(kb)
            return
        }
        val list = if (emojiTab == 0) recent.toList() else emojiGroups[emojiTab - 1].second
        gridPanel(list, "Belum ada emoji terakhir.", Prefs.emoSize(this).toFloat(), false) { typeEmoji(it) }
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("space", 5f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    private fun listPanel(items: List<String>, empty: String) {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(Prefs.emoH(this)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = empty
            t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
            col.addView(t)
        }
        items.forEach { c ->
            val t = btn(if (c.length > 60) c.take(60) + "…" else c, 1f, false, 14f) { type(c) }
            t.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).also {
                it.setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            t.setPadding(dp(10), 0, dp(10), 0)
            t.gravity = Gravity.CENTER_VERTICAL
            col.addView(t)
        }
        sv.addView(col)
        body.addView(sv)
    }

    private fun scrollPanel(build: (LinearLayout) -> Unit) {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        build(col)
        sv.addView(col)
        body.addView(sv)
    }

    private fun emptyNote(col: LinearLayout, s: String) {
        val t = TextView(this)
        t.text = s
        t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
        col.addView(t)
    }

    private fun itemRow(label: String, onTap: () -> Unit, acts: List<Pair<String, () -> Unit>>): LinearLayout {
        val r = row()
        val one = label.replace("\n", " ")
        val m = btn(if (one.length > 60) one.take(60) + "…" else one, 1f, false, 14f) { onTap() }
        m.layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).also { it.setMargins(dp(2), dp(3), dp(2), dp(3)) }
        m.setPadding(dp(10), 0, dp(10), 0)
        m.gravity = Gravity.CENTER_VERTICAL
        r.addView(m)
        for (a in acts) {
            val b = btn(a.first, 1f, true, 12f) { a.second() }
            b.layoutParams = LinearLayout.LayoutParams(dp(52), dp(42)).also { it.setMargins(dp(2), dp(3), dp(2), dp(3)) }
            r.addView(b)
        }
        return r
    }

    private fun clipRow(text: String, pinned: Boolean, onPin: () -> Unit, onDel: () -> Unit): View {
        val r = row()
        r.gravity = Gravity.CENTER_VERTICAL
        val pin = View(this)
        pin.background = IconDrawable("pin", if (pinned) th.text else blend(th.bg, th.text, 0.45f), dp(22).toFloat())
        pin.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        pin.setOnClickListener { feedback(pin); onPin() }
        val tv = TextView(this)
        val one = text.replace("\n", " ")
        tv.text = one
        tv.setTextColor(th.text)
        tv.textSize = 14f
        tv.maxLines = 3
        tv.ellipsize = android.text.TextUtils.TruncateAt.END
        tv.setPadding(dp(4), dp(8), dp(4), dp(8))
        tv.setOnClickListener { feedback(tv); type(text); mode = "letters"; render() }
        val del = View(this)
        del.background = IconDrawable("trash", blend(th.bg, th.text, 0.6f), dp(22).toFloat())
        del.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        del.setOnClickListener { feedback(del); onDel() }
        r.addView(pin)
        r.addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(del)
        return r
    }

    private fun clipboard() {
        screenShell("Klipboard") { card ->
            val tr = row()
            tr.gravity = Gravity.CENTER_VERTICAL
            val tt = TextView(this)
            tt.text = "Tampilkan clipboard di toolbar Anda"
            tt.setTextColor(blend(th.bg, th.text, 0.75f))
            tt.textSize = 14f
            val sw = android.widget.Switch(this)
            sw.isChecked = Prefs.clipBar(this)
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            sw.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(Color.WHITE, Color.LTGRAY))
            sw.trackTintList = android.content.res.ColorStateList(states, intArrayOf(th.hi, Color.GRAY))
            sw.setOnCheckedChangeListener { _, on -> Prefs.setClipBar(this, on) }
            tr.addView(tt, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            tr.addView(sw)
            card.addView(tr)
            card.addView(divider())
            val add = row()
            add.gravity = Gravity.CENTER_VERTICAL
            add.setPadding(0, dp(6), 0, dp(6))
            val ai = View(this)
            ai.background = IconDrawable("pencil", th.hi, dp(22).toFloat())
            ai.layoutParams = LinearLayout.LayoutParams(dp(40), dp(32))
            val at = TextView(this)
            at.text = "Tambahkan klip baru"
            at.setTextColor(th.hi)
            at.textSize = 15f
            at.setPadding(dp(4), 0, 0, 0)
            add.addView(ai); add.addView(at)
            add.setOnClickListener { feedback(add); addClip = true; buf.setLength(0); mode = "letters"; render() }
            card.addView(add)
            card.addView(divider())
            if (pins.isEmpty() && clips.isEmpty()) {
                val n = TextView(this)
                n.text = "Belum ada riwayat salinan. Salin teks, nanti muncul di sini. Ketuk ikon pin supaya teks tersimpan terus."
                n.setTextColor(blend(th.bg, th.text, 0.6f)); n.textSize = 13f
                n.setPadding(dp(2), dp(10), dp(2), dp(10))
                card.addView(n)
            }
            for (p in ArrayList(pins)) {
                card.addView(clipRow(p, true, {
                    pins.remove(p); Stash.setPins(this, pins)
                    if (!clips.contains(p)) clips.add(0, p)
                    render()
                }, { ask { pins.remove(p); Stash.setPins(this, pins) } }))
                card.addView(divider())
            }
            for (c in ArrayList(clips)) {
                card.addView(clipRow(c, false, {
                    clips.remove(c); pins.add(0, c); Stash.setPins(this, pins); render()
                }, { ask { clips.remove(c) } }))
                card.addView(divider())
            }
            if (clips.isNotEmpty()) {
                val all = TextView(this)
                all.text = "Hapus riwayat salinan"
                all.setTextColor(th.hi)
                all.textSize = 14f
                all.setPadding(dp(4), dp(8), 0, dp(4))
                all.setOnClickListener { feedback(all); ask { clips.clear() } }
                card.addView(all)
            }
        }
    }

    /** Satu baris teks cepat. Format "singkatan=teks panjang" (singkatan huruf saja, maks 12) akan
     *  otomatis berubah saat ditulis lalu tekan spasi. Baris tanpa "=" hanya jadi tombol teks. */
    private fun snipList(): List<Pair<String, String>> {
        return Prefs.snippets(this).split("\n").map { it.trim() }.filter { it.isNotEmpty() }.map { l ->
            val i = l.indexOf('=')
            val a = if (i in 1..12) l.substring(0, i).trim() else ""
            val v = if (i > 0) l.substring(i + 1).trim() else ""
            if (a.isNotEmpty() && v.isNotEmpty() && a.all { it.isLetter() }) Pair(a, v) else Pair("", l)
        }
    }

    private fun snippets() {
        val list = snipList()
        scrollPanel { col ->
            if (list.isEmpty()) emptyNote(col, "Belum ada teks cepat. Isi di aplikasi Romaboard, atau tekan Simpan untuk menyimpan teks yang terakhir disalin.")
            for (e in list) {
                val label = if (e.first.isNotEmpty()) e.first + " → " + e.second else e.second
                col.addView(itemRow(label, { type(e.second) }, emptyList()))
            }
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("Simpan", 1.6f, true, 14f) {
            val t = clips.firstOrNull()
            if (t == null) say("Belum ada teks yang disalin.")
            else {
                Prefs.setSnippets(this, (Prefs.snippets(this).trimEnd() + "\n" + t.replace("\n", " ")).trim())
                render()
                say("Tersimpan sebagai teks cepat.")
            }
        })
        bottom.addView(btn("space", 3f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    private fun aiHistory() {
        val list = Stash.aiHist(this)
        scrollPanel { col ->
            if (list.isEmpty()) emptyNote(col, "Belum ada riwayat hasil AI. Setiap hasil AI akan tersimpan di sini.")
            for (h in list) {
                col.addView(itemRow(h, { type(h) }, listOf(Pair("×", {
                    val l = Stash.aiHist(this); l.remove(h); Stash.setAiHist(this, l); render()
                }))))
            }
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("Menu AI", 1.6f, true, 14f) { mode = "ai"; render() })
        bottom.addView(btn("Hapus semua", 2f, true, 14f) { Stash.setAiHist(this, emptyList()); render() })
        body.addView(bottom)
    }

    /** Baca teks di layar (lewat aksesibilitas). Keyboard disembunyikan sebentar supaya tidak ikut terbaca
     *  dan isi aplikasi yang tadinya tertutup keyboard ikut terlihat, lalu dimunculkan lagi. */
    private fun readScreen() {
        val svc = PermanentService.instance
        if (svc == null) {
            say("Nyalakan layanan aksesibilitas Romaboard dulu (buka app Romaboard → Buka pengaturan aksesibilitas).")
            return
        }
        val ic = currentInputConnection
        val sel = ic?.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic?.getTextBeforeCursor(300, 0)?.toString() ?: "") else ""
        val ins = (if (sel.isNotEmpty()) sel else before).trim()
        host.hideForCapture()
        main.postDelayed({
            Thread {
                val txt = try { svc.readScreenText().take(6000) } catch (e: Exception) { "" }
                main.post {
                    host.showAfterCapture()
                    if (txt.isBlank()) {
                        say("Tidak ada teks yang terbaca di layar (gambar atau game tidak bisa dibaca).")
                    } else {
                        askScreen(txt, ins)
                    }
                }
            }.start()
        }, 500)
    }

    private fun askScreen(txt: String, ins: String) {
        val task = if (ins.isNotEmpty()) "Instruksi pengguna: $ins"
            else "Find the main question or problem in the screen text and answer it. If it is multiple choice, give the correct option and a one-line reason."
        val sys = "You are a helpful assistant inside a phone keyboard. You receive raw text captured from the user's screen, which may contain interface noise (menus, buttons, timestamps); ignore the noise. Answer in the same language as the screen text unless asked otherwise. Be concise. Output plain text, no markdown."
        say("Bertanya ke AI…", true)
        AiClient.askAuto(this, Prefs.model(this), sys, "Teks di layar:\n$txt\n\n$task", { out ->
            screenCtx = txt
            aiAnswer = out; aiSel = ""
            Stash.addAi(this, out)
            promptMode = true; buf.setLength(0); mode = "letters"; shift = false
            render()
        }, { err -> say(err) })
    }

    private fun translateBeforeSend(): Boolean {
        val ic = currentInputConnection ?: return false
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic.getTextBeforeCursor(1500, 0)?.toString() ?: "") else ""
        val src = if (sel.isNotEmpty()) sel else before
        if (src.isBlank()) return false
        val lang = Prefs.lang(this)
        say("Menerjemahkan ke $lang…", true)
        AiClient.askAuto(this, Prefs.model(this), "Translate to $lang. Output only the translation.", src, { out ->
            val c = currentInputConnection
            if (c != null) {
                if (sel.isEmpty()) c.deleteSurroundingText(before.length, 0)
                c.commitText(out, 1)
                undoOrig = src; undoOut = out
                trDone = true
                Stash.addAi(this, out)
                say("Sudah dalam $lang. Tekan kirim lagi untuk mengirim, atau Batal di menu AI.")
            }
        }, { err -> say(err) })
        return true
    }

    fun destroy() {
        hidePreview()
        saveWords()
        rec?.destroy()
    }

    private fun startPermanent() {
        // Mode permanen memakai keyboard asli (bukan overlay), jadi cukup menyalakan flag.
        host.startPermanentMode()
    }

    private fun tb(label: String, tint: Int? = null, onClick: () -> Unit): TextView {
        val t = btn(label, 1f, true, 15f, false, tint, onClick = onClick)
        val lp = LinearLayout.LayoutParams(dp(Prefs.tbW(this)), dp(Prefs.tbH(this)))
        lp.setMargins(dp(2), dp(2), dp(2), dp(2))
        t.layoutParams = lp
        return t
    }

    // ---------- suara ke teks ----------
    private fun startVoice() {
        if (listening) { rec?.stopListening(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val i = Intent(this, PermissionActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            say("Izinkan mikrofon, lalu tekan tombol mikrofon lagi.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("Pengenalan suara tidak tersedia di HP ini (butuh aplikasi Google).")
            return
        }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; say("Bicara sekarang… (tekan tombol mikrofon lagi untuk selesai)", true) }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { say("Memproses suara…", true) }
            override fun onError(error: Int) {
                listening = false
                say(when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Tidak terdengar, coba lagi."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Izin mikrofon belum diberikan."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Butuh internet untuk pengenalan suara."
                    else -> "Suara gagal (kode $error)."
                })
            }
            override fun onResults(results: Bundle?) {
                listening = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) { say("Tidak terdengar, coba lagi."); return }
                say(null)
                val before = if (inBuf) buf.toString() else (currentInputConnection?.getTextBeforeCursor(1, 0)?.toString() ?: "")
                val lead = if (before.isNotEmpty() && !before.endsWith(" ") && !before.endsWith("\n")) " " else ""
                type(lead + t.trim() + " ")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) say("Hasil suara: $t")
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.voiceLang(this))
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        r.startListening(i)
    }

    // ---------- gaya teks ----------
    private val smallCaps = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ"
    private val upside = "ɐqɔpǝɟƃɥᴉɾʞlɯuodbɹsʇnʌʍxʎz"

    private fun mapRange(s: String, up: Int, low: Int, dig: Int = -1): String {
        val sb = StringBuilder()
        for (ch in s) {
            when {
                ch in 'A'..'Z' -> sb.appendCodePoint(up + (ch - 'A'))
                ch in 'a'..'z' -> sb.appendCodePoint(low + (ch - 'a'))
                ch in '0'..'9' && dig >= 0 -> sb.appendCodePoint(dig + (ch - '0'))
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    // setelah tiap karakter (code point utuh, aman untuk huruf matematika non-BMP) tambahkan tanda
    private fun after(mark: String): (String) -> String = { s ->
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            i += Character.charCount(cp)
            sb.appendCodePoint(cp)
            if (cp != 32) sb.append(mark)
        }
        sb.toString()
    }
    private fun comb(mark: String): (String) -> String = after(mark)
    private fun between(sep: String): (String) -> String = after(sep)

    private fun wrap(l: String, r: String): (String) -> String = { s ->
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            i += Character.charCount(cp)
            if (cp == 32) sb.append(' ') else { sb.append(l); sb.appendCodePoint(cp); sb.append(r) }
        }
        sb.toString()
    }

    private val morse: Map<Char, String> = mapOf(
        'a' to ".-", 'b' to "-...", 'c' to "-.-.", 'd' to "-..", 'e' to ".", 'f' to "..-.", 'g' to "--.", 'h' to "....",
        'i' to "..", 'j' to ".---", 'k' to "-.-", 'l' to ".-..", 'm' to "--", 'n' to "-.", 'o' to "---", 'p' to ".--.",
        'q' to "--.-", 'r' to ".-.", 's' to "...", 't' to "-", 'u' to "..-", 'v' to "...-", 'w' to ".--", 'x' to "-..-",
        'y' to "-.--", 'z' to "--..", '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----."
    )

    private val styleList: List<Pair<String, (String) -> String>> by lazy {
        val paint = android.graphics.Paint()
        val tables = FontData.tables.map { it.first to FontData.mapper(it.second) }.filter { (_, f) ->
            try { paint.hasGlyph(f("A")) && paint.hasGlyph(f("a")) } catch (e: Exception) { true }
        }
        tables + listOf(
            Pair("Kecil", { s: String -> s.map { c -> val l = c.lowercaseChar(); if (l in 'a'..'z') smallCaps[l - 'a'] else c }.joinToString("") }),
            Pair("Terbalik", { s: String -> s.lowercase().map { c -> if (c in 'a'..'z') upside[c - 'a'] else c }.reversed().joinToString("") }),
            Pair("Coret", comb("\u0336")),
            Pair("Coret Miring", comb("\u0338")),
            Pair("Garis Bawah", comb("\u0332")),
            Pair("Garis Bawah Ganda", comb("\u0333")),
            Pair("Garis Atas", comb("\u0305")),
            Pair("Titik Bawah", comb("\u0323")),
            Pair("Gelombang", comb("\u0330")),
            Pair("Kotak Sekeliling", comb("\u20DE")),
            Pair("Lingkar Sekeliling", comb("\u20DD")),
            Pair("Spasi", between(" ")),
            Pair("Titik", between("·")),
            Pair("Garis", between("-")),
            Pair("Hati", between("♥")),
            Pair("Bintang", between("★")),
            Pair("Kilau", between("✨")),
            Pair("Titik Atas", comb("\u0307")),
            Pair("Dua Titik Atas", comb("\u0308")),
            Pair("Tilde Atas", comb("\u0303")),
            Pair("Topi", comb("\u0302")),
            Pair("Cincin Atas", comb("\u030A")),
            Pair("Panah Atas", comb("\u20D7")),
            Pair("Coret Pendek", comb("\u0335")),
            Pair("Silang Bawah", comb("\u0353")),
            Pair("Zalgo Mini", comb("\u0315\u033D\u0324")),
            Pair("Bunga", between("✿")),
            Pair("Musik", between("♪")),
            Pair("Berlian", between("◆")),
            Pair("Hati Putih", between("♡")),
            Pair("Bulan", between("☾")),
            Pair("Kilau Putih", between("✧")),
            Pair("Panah", between("➤")),
            Pair("Api", between("🔥")),
            Pair("Kurung Siku", { s: String -> s.map { c -> if (c == ' ') " " else "【$c】" }.joinToString("") }),
            Pair("Kurung Kotak", { s: String -> s.map { c -> if (c == ' ') " " else "[$c]" }.joinToString("") }),
            Pair("Kurung Sudut", { s: String -> s.map { c -> if (c == ' ') " " else "「$c」" }.joinToString("") }),
            Pair("Sudut Ganda", wrap("«", "»")),
            Pair("Sudut Tunggal", wrap("‹", "›")),
            Pair("Kurung Ganda", wrap("⟦", "⟧")),
            Pair("Panah Kurung", wrap("❮", "❯")),
            Pair("Kurung Tebal", wrap("〖", "〗")),
            Pair("Kurung Bulat", wrap("(", ")")),
            Pair("Awalan Hati", wrap("♥", "")),
            Pair("Awalan Bintang", wrap("★", "")),
            Pair("Awalan Panah", wrap("➤", "")),
            Pair("Morse", { s: String -> s.map { c -> morse[c.lowercaseChar()]?.plus(" ") ?: c.toString() }.joinToString("") }),
            Pair("Biner", { s: String -> s.map { c -> Integer.toBinaryString(c.code).padStart(8, '0') + " " }.joinToString("") }),
            Pair("Heksa", { s: String -> s.map { c -> String.format("%02X ", c.code) }.joinToString("") })
        ) + composites(tables)
    }

    /** Gabungan dua gaya, misalnya Tebal + Garis Bawah. */
    private fun composites(tables: List<Pair<String, (String) -> String>>): List<Pair<String, (String) -> String>> {
        val m = tables.toMap()
        val combos = listOf(
            Triple("Tebal Garis Bawah", "Tebal", "\u0332"), Triple("Tebal Coret", "Tebal", "\u0336"),
            Triple("Miring Garis Bawah", "Miring", "\u0332"), Triple("Skrip Garis Bawah", "Skrip Tebal", "\u0332"),
            Triple("Gotik Garis Bawah", "Gotik Tebal", "\u0332"), Triple("Mono Coret", "Mono", "\u0336"),
            Triple("Double Garis Bawah", "Double", "\u0332"), Triple("Sans Tebal Coret", "Sans Tebal", "\u0336"),
            Triple("Miring Coret", "Miring", "\u0336"), Triple("Skrip Coret", "Skrip Tebal", "\u0336"),
            Triple("Gotik Coret", "Gotik Tebal", "\u0336"), Triple("Tebal Miring Garis Bawah", "Tebal Miring", "\u0332"),
            Triple("Sans Garis Bawah", "Sans", "\u0332"), Triple("Mono Garis Bawah", "Mono", "\u0332"),
            Triple("Tebal Bintang", "Tebal", "★"), Triple("Tebal Hati", "Tebal", "♥"), Triple("Skrip Hati", "Skrip Tebal", "♥"),
            Triple("Gotik Kilau", "Gotik Tebal", "✨"), Triple("Double Bintang", "Double", "★"),
            Triple("Miring Musik", "Miring", "♪"), Triple("Mono Titik", "Mono", "·"), Triple("Sans Tebal Bunga", "Sans Tebal", "✿"),
            Triple("Tebal Titik Bawah", "Tebal", "\u0323"), Triple("Skrip Gelombang", "Skrip Tebal", "\u0330")
        )
        return combos.mapNotNull { (name, base, mark) ->
            val f = m[base] ?: return@mapNotNull null
            val c = comb(mark)
            Pair(name, { s: String -> c(f(s)) })
        }
    }

    private fun applyStyle(fn: (String) -> String) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        if (sel.isNotEmpty()) {
            ic.commitText(fn(sel), 1)
        } else {
            val before = ic.getTextBeforeCursor(1500, 0)?.toString() ?: ""
            if (before.isEmpty()) { say("Ketik atau pilih teks dulu."); return }
            ic.deleteSurroundingText(before.length, 0)
            ic.commitText(fn(before), 1)
        }
    }

    private fun styles() {
        val hint = TextView(this)
        hint.text = "Pilih gaya lalu langsung ketik, tulisanmu otomatis memakai gaya itu. Pilih \"Normal\" untuk mematikan."
        hint.setTextColor(th.text); hint.textSize = 11f
        hint.setPadding(dp(8), dp(2), dp(8), dp(2))
        body.addView(hint)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(165))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val cur = Prefs.activeStyleName(this)
        val all = listOf(Pair("Normal", { s: String -> s })) + styleList
        all.chunked(3).forEach { tri ->
            val r = row()
            tri.forEach { (name, fn) ->
                val key = if (name == "Normal") "" else name
                val on = key == cur
                r.addView(btn(fn("Abc 12"), 1f, false, 14f, false, if (on) th.accent else null) {
                    Prefs.setActiveStyleName(this, if (on) "" else key)
                    if (key.isNotEmpty()) {
                        val sel = currentInputConnection?.getSelectedText(0)?.toString() ?: ""
                        if (sel.isNotEmpty()) currentInputConnection?.commitText(fn(sel), 1)
                    }
                    render()
                })
            }
            repeat(3 - tri.size) {
                val sp = View(this)
                sp.layoutParams = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), 1f)
                r.addView(sp)
            }
            col.addView(r)
        }
        sv.addView(col)
        body.addView(sv)
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("Ubah teks", 2f, true, 13f) {
            val fn = styleList.firstOrNull { it.first == Prefs.activeStyleName(this) }?.second
            if (fn != null) applyStyle(fn) else say("Pilih gaya dulu.")
        })
        bottom.addView(btn("space", 3f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    // ---------- AI ----------
    private fun updatePrompt() {
        promptView?.text = if (buf.isEmpty()) (if (addClip) "Menulis sesuatu" else "Ketik pertanyaan / perintah ke AI…") else buf.toString()
        promptScroll?.post { promptScroll?.fullScroll(View.FOCUS_DOWN) }
        styleSave()
    }

    private fun insertAnswer() {
        val out = aiAnswer ?: return
        val c = currentInputConnection ?: return
        val ins = if (aiSel.isNotEmpty()) aiSel + "\n" + out else out
        c.commitText(ins, 1)
        undoOrig = aiSel; undoOut = ins
        aiAnswer = null; promptMode = false; buf.setLength(0); screenCtx = ""
        render()
    }

    private fun startPrompt() {
        promptMode = true; buf.setLength(0); mode = "letters"; shift = false; render()
    }

    private fun sendPrompt() {
        val q = buf.toString().trim()
        if (q.isEmpty()) { say("Ketik pertanyaannya dulu."); return }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val user = if (screenCtx.isNotEmpty()) "Teks di layar:\n$screenCtx\n\nPermintaan: $q"
            else if (sel.isNotEmpty()) "Teks terpilih:\n$sel\n\nPermintaan: $q" else q
        val sys = "You are a helpful assistant inside a phone keyboard. Answer concisely in the same language as the user's request. Output only the answer as plain text, no markdown."
        say("AI sedang menjawab…", true)
        AiClient.askAuto(this, Prefs.model(this), sys, user, { out ->
            aiAnswer = out; aiSel = sel
            Stash.addAi(this, out)
            render()
        }, { err -> say(err) })
    }

    private var undoOrig: String? = null
    private var undoOut: String? = null

    private fun undoAi() {
        val ic = currentInputConnection ?: return
        val o = undoOut; val orig = undoOrig
        if (o == null || orig == null) { say("Belum ada hasil AI untuk dibatalkan."); return }
        val before = ic.getTextBeforeCursor(o.length, 0)?.toString() ?: ""
        if (before != o) { say("Teks sudah berubah, tidak bisa dibatalkan."); return }
        ic.deleteSurroundingText(o.length, 0)
        ic.commitText(orig, 1)
        undoOut = null; undoOrig = null
        say("Dibatalkan.")
    }

    private fun ai() {
        val lang = Prefs.lang(this)
        val items = listOf(
            Triple("Perbaiki", "Fix grammar, spelling and punctuation. Keep the same language and meaning. Output only the corrected text.", true),
            Triple("Formal", "Rewrite in a formal, polite tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Santai", "Rewrite in a casual, friendly, natural chat tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Sopan", "Rewrite politely and respectfully, suitable to send to a boss or an elder. Keep the same language. Output only the rewritten text.", true),
            Triple("Lucu", "Rewrite in a funny, witty tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Ringkas", "Make it shorter and clearer. Keep the same language. Output only the result.", true),
            Triple("Singkat", "Make it extremely short, keeping only the key meaning. Same language. Output only the result.", true),
            Triple("Baku", "Rewrite in standard formal Indonesian with correct spelling (PUEBI). Output only the text.", true),
            Triple("Emoji-in", "Add fitting emojis to this text without changing the words. Output only the text.", true),
            Triple("Terjemah $lang", "Translate to $lang. Output only the translation.", true),
            Triple("Caption", "Turn this into a catchy social media caption. Keep the same language. Output only the caption.", true),
            Triple("Judul", "Write a short catchy title for this text in the same language. Output only the title.", false),
            Triple("Hashtag", "Suggest 8 relevant hashtags for this text. Output only the hashtags separated by spaces.", false),
            Triple("Jelaskan", "Explain this simply and briefly in the same language. Output only the explanation.", false),
            Triple("Balas", "The text is a message I received. Write a short, natural reply in the same language. Output only the reply.", false),
            Triple("Lanjutkan", "Continue writing this text naturally in the same language and style. Output only the continuation.", false),
            Triple("Poin-poin", "Rewrite as concise bullet points. Keep the same language. Output only the bullet points.", true),
            Triple("Riwayat AI", "HIST", true),
            Triple(if (Stash.autoTr(this)) "Auto-TR ON" else "Auto-TR OFF", "AUTOTR", true),
            Triple("Kustom", "CUSTOM", true),
            Triple("@chat Tanya AI", "ASK", true)
        )
        val hint = TextView(this)
        hint.text = "Ketik/pilih teks lalu tekan fitur. Auto-TR: teks otomatis diterjemahkan saat tekan kirim. Geser ke bawah untuk fitur lain."
        hint.setTextColor(th.text); hint.textSize = 11f
        hint.setPadding(dp(8), dp(2), dp(8), dp(2))
        body.addView(hint)
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(165))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        items.chunked(3).forEach { tri ->
            val r = row()
            tri.forEach { (label, prompt, replace) ->
                val on = prompt == "AUTOTR" && Stash.autoTr(this)
                r.addView(btn(label, 1f, false, 14f, tint = if (on) th.accent else null) {
                    if (prompt == "HIST") { mode = "hist"; render() }
                    else if (prompt == "AUTOTR") {
                        Stash.setAutoTr(this, !Stash.autoTr(this))
                        render()
                        say(if (Stash.autoTr(this)) "Auto-TR aktif: saat tekan kirim, teks diterjemahkan ke ${Prefs.lang(this)} dulu." else "Auto-TR mati.")
                    } else if (prompt == "CUSTOM") {
                        val c = Prefs.custom(this)
                        if (c.isBlank()) say("Isi prompt kustom di aplikasi Romaboard.")
                        else runAi("$c Output only the result.", true)
                    } else if (prompt == "ASK") startPrompt() else runAi(prompt, replace)
                })
            }
            col.addView(r)
        }
        sv.addView(col)
        body.addView(sv)
        val bottom = row()
        bottom.addView(btn("ABC", 1.5f, true, 15f) { mode = "letters"; render() })
        bottom.addView(btn("@undo Batal", 1.6f, true, 14f) { undoAi() })
        bottom.addView(btn("space", 3f, false, 16f) { spaceTap() })
        bottom.addView(backspace(1.5f))
        body.addView(bottom)
    }

    private fun runAi(system: String, replace: Boolean) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic.getTextBeforeCursor(1500, 0)?.toString() ?: "") else ""
        val src = if (sel.isNotEmpty()) sel else before
        if (src.isBlank()) { say("Ketik atau pilih teks dulu."); return }
        say("AI sedang memproses…", true)
        AiClient.askAuto(this, Prefs.model(this), system, src, { out ->
            Stash.addAi(this, out)
            val c = currentInputConnection
            if (c != null) {
                if (replace) {
                    if (sel.isEmpty()) c.deleteSurroundingText(before.length, 0)
                    c.commitText(out, 1)
                    undoOrig = src; undoOut = out
                } else {
                    val ins = (if (sel.isEmpty() && !before.endsWith(" ")) " " else "") + out
                    c.commitText(ins, 1)
                    undoOrig = ""; undoOut = ins
                }
            }
            say(null)
        }, { err -> say(err) })
    }
}
