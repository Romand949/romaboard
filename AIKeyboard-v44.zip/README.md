# Romaboard

Keyboard Android buatan sendiri: QWERTY, simbol, emoji, riwayat clipboard, 4 tema, dan fitur AI (perbaiki, formal, santai, ringkas, terjemah, balas, lanjutkan, tanya AI) memakai Groq (gratis).

## Cara build (100% di GitHub)
1. Upload zip ini ke repo GitHub, lalu buat `.github/workflows/build.yml`.
2. Tab Actions > Build APK > Run workflow, download artifact `AIKeyboard-apk`.
3. Install APK. Tidak ada API key di dalam APK.

## Cara pakai
Buka app Romaboard, aktifkan dan pilih keyboard, lalu tempel API key Groq milikmu sendiri (gratis di console.groq.com/keys). Tiap pengguna memakai key sendiri.

## Ikon AI (Tanya AI)
Selain ikon Romaboard, ada ikon kedua bernama "AI" di layar utama. Ketuk, halaman Tanya AI terbuka dan keyboard langsung muncul. Ketik perintah, AI menjawab di halaman itu, lalu ketuk Salin atau Bagikan untuk menempel ke WhatsApp atau app lain. Memakai API key dan model yang sama dengan pengaturan.

## Fitur
- Keyboard: baris angka, shift/caps, huruf besar otomatis, spasi 2x = titik, simbol, emoji, 4 tema
- Clipboard: riwayat salinan + alat Semua/Salin/Potong/Tempel/geser kursor
- Teks cepat (⚡): kalimat favorit, diatur di app
- AI: Perbaiki, Formal, Santai, Lucu, Ringkas, Baku, Emoji-in, Terjemah, Tanya AI, Balas, Lanjutkan, Kustom (prompt buatan sendiri), dan tombol Batal untuk mengembalikan teks asli

## Update otomatis
Setiap build membuat Release baru di GitHub (repo harus Public). Saat app Romaboard dibuka (atau saat tombol "Cek update" ditekan), ia mengecek Release terbaru; jika ada versi baru muncul tombol "Update sekarang". Android tetap meminta kamu menekan Install. Kunci tanda tangan (app/aikeyboard.jks) harus selalu ikut di zip supaya update bisa menimpa versi lama.

## Kenyamanan mengetik
Tombol bereaksi saat disentuh (lebih cepat), warna berubah saat ditekan, tinggi tombol bisa kecil/sedang/besar, mode satu tangan (↔), tombol 🌐 ganti keyboard, shift dua kali = CAPS LOCK, saran kata yang belajar dari ketikanmu, emoji per kategori + terakhir dipakai, suara ketik opsional.

## Suara ke teks & gaya teks
Tombol 🎤 (di bawah dan di atas) mengetik dari suara; izin mikrofon diminta saat pertama kali. Panel "Aa" mengubah teks jadi gaya tebal, miring, skrip, gotik, bulat, kotak, terbalik, coret, dan lain-lain. Tab (ツ) di emoji berisi kaomoji.

## Animasi
Tombol mengecil lalu memantul saat disentuh dan warnanya memudar halus, panel berpindah dengan geser + fade, saran kata dan pesan status muncul memudar, pesan "memproses"/mendengarkan berdenyut, halaman pengaturan muncul memudar.

## v13: tampilan bebas diatur + keyboard permanen
- Di app: slider tinggi tombol, ukuran font, jarak antar tombol, sudut, transparansi, margin, ukuran baris atas; jenis font (bawaan atau file .ttf/.otf sendiri), huruf tebal, warna tema Kustom (hex). Ada preview langsung.
- Keyboard permanen 📌: nyalakan layanan aksesibilitas "Romaboard Permanen", lalu tekan Mulai (di app) atau tombol 📌 (di keyboard). Keyboard tampil terus sebagai overlay sampai tombol ⏹ STOP ditekan. ▾ = kecilkan sementara.
- Batasan: kolom sandi tidak didukung; beberapa app dengan kolom ketik khusus (game, sebagian browser) bisa menolak teks dari aksesibilitas.

## v15: keyboard permanen = keyboard asli
Mode permanen 📌 kini memakai jendela keyboard biasa (InputMethodService), bukan overlay aksesibilitas, jadi tidak lagi ditutup otomatis oleh sistem. Layanan aksesibilitas tidak diperlukan lagi, dan kolom sandi ikut didukung. Syarat: pilih "Romaboard" sebagai keyboard aktif. Tekan ⏹ STOP untuk mematikan, ▾ untuk menyembunyikan sementara.

## v16: Tanya AI tampil di dalam keyboard
Jawaban 💬 Tanya AI sekarang muncul dulu di kotak jawaban di dalam keyboard (bisa di-scroll), tidak langsung masuk ke kotak ketik. Tombol ⤵ Taruh semua memasukkan jawaban ke kotak ketik, 📋 Salin menyalin, ✕ menutup. Kotak pertanyaan juga bisa di-scroll dan otomatis menggulir ke baris terakhir.

## v17: banyak API key + info model
- Bisa menambah API key tanpa batas (➕ Tambah API key). Tiap key punya tombol Pakai, Tes, Hapus, dan menampilkan sisa limit setelah dites atau dipakai.
- Kalau key aktif kena limit (429) atau salah (401), keyboard otomatis mencoba key berikutnya dan mengingat key yang berhasil.
- Daftar model dengan ukuran (kecil/besar) dan perkiraan limit (permintaan/menit, /hari, token/menit, /hari). Ketuk untuk memilih.
- Catatan: limit Groq dihitung per akun/organisasi, jadi pakai key dari akun berbeda.

## v18: ikon buatan sendiri + tata letak lebih rapi
- Semua ikon tombol keyboard kini digambar sendiri (Icons.kt, vektor via Canvas), tidak lagi memakai emoji: toolbar, mic, globe, enter/kirim, backspace, shift/caps, tutup, salin, taruh semua, batal, riwayat, dan panah kursor. Emoji hanya tersisa di dalam papan pemilih emoji.
- Toolbar: tab yang sedang aktif disorot warna aksen.
- Baris bawah disejajarkan dengan baris huruf (123 | globe | , | spasi | . | enter); mic cukup di toolbar. Lebar tombol ABC dan backspace di layar lain disamakan.
- Pesan status tanpa emoji.

## v19: pilihan animasi keyboard
Pengaturan → "Animasi keyboard":
- Animasi tekan tombol (10 pilihan): Membal (bawaan), Halus, Jelly, Pop-up besar, Miring 3D, Tekan dalam, Goyang miring, Getar, Riak cahaya, Tanpa animasi.
- Animasi pindah layar (7 pilihan): Naik & pudar (bawaan), Geser dari kanan, Zoom masuk, Lipat 3D, Jatuh membal, Pudar saja, Tanpa animasi.
- Animasi keyboard muncul (6 pilihan): Tanpa animasi (bawaan), Naik dari bawah, Pudar, Zoom dari bawah, Membal naik, Membuka dari bawah.
- Slider kecepatan animasi 40–300%, plus pratinjau yang bisa diketuk langsung di halaman pengaturan.
Kode: KeyAnim.kt.

## v20: keyboard permanen bisa diperkecil jadi ikon
Tombol ▾ pada keyboard permanen kini memperkecil keyboard menjadi satu ikon bulat (tidak menghilang). Ikon bisa digeser bebas (posisinya diingat) dan diketuk untuk membuka keyboard lagi. Saat jadi ikon, aplikasi di bawahnya tidak menyempit dan sentuhan di luar ikon diteruskan ke aplikasi. Tetap berjalan sebagai keyboard asli (InputMethodService), tanpa izin tambahan.

## v21: ikon mini lebih enak digeser
Area geser ikon diperluas (hingga ±85% tinggi layar, hampir ke atas), memakai batas geser bawaan Android, dan ikon membesar sedikit serta agak transparan saat digeser, lalu memantul kecil saat dilepas. Posisi tetap diingat.

## v39: tampilan keyboard bergaya baru
- Toolbar atas gelap: tombol menu (grid), Tema, Mikrofon, Klipboard. Tombol menu membuka grid fitur (Tema, Font, Klipboard, Pengeditan teks, Menerjemahkan, Bahasa, Baris Angka, Suara dan Getaran, AI, Emoji, Teks cepat, Baca layar, Ukuran tombol, Simbol, Satu tangan, Sematkan, Pengaturan).
- Tema bawaan baru "Klasik" (abu-abu gelap). Layar Tema berisi bulatan pratinjau; Tema Khusus memakai warna dari app.
- Papan huruf tanpa baris angka: angka/simbol kecil di pojok tombol, tekan-tahan untuk mengetiknya. Koma tahan = mikrofon, titik tahan = "!", spasi tahan = ganti keyboard, spasi menampilkan nama bahasa.
- Layar Klipboard baru: saklar tampil di toolbar, Tambahkan klip baru (kotak ketik + Batalkan/Menyimpan), pin, hapus dengan konfirmasi.
- Layar Pengeditan teks: panah, awal/akhir baris, pilih semua, salin, potong, tempel, batal AI.
- Pengaturan "Urutan tombol baris atas" tidak dipakai lagi oleh toolbar baru (semua tombol ada di menu grid).

## v41: nuansa keyboard iPhone
- Gelembung pratinjau huruf muncul di atas tombol saat ditekan (bisa dimatikan lewat menu "Pratinjau huruf").
- Tahan spasi lalu geser kiri/kanan untuk menggerakkan kursor; tahan spasi tanpa geser = ganti keyboard.
- Tombol hapus makin cepat kalau ditahan, lalu menghapus per kata.
- Bar saran kata bergaya iOS (tiga kata dipisah garis tipis).
- Animasi tekan baru "iPhone (halus)" (bawaan baru), keyboard muncul naik dari bawah.
- Tema baru: iOS Terang dan iOS Gelap. Baris tema di app bisa digeser.

## v42: ketikan tanpa delay + tombol huruf sama lebar
- Tombol huruf sekarang mengetik saat disentuh (bukan saat dilepas). Tekan-tahan 0,45 detik mengganti huruf dengan angka/simbol kecilnya.
- Ganti huruf besar/kecil (Shift, huruf kapital otomatis) tidak lagi membangun ulang keyboard, jadi tidak ada jeda.
- Saran kata dihitung setelah jeda singkat, supaya ketikan cepat tidak tertahan.
- Semua tombol huruf di ketiga baris selalu sama lebar. Lebar Shift & Hapus dibatasi maksimal 150%.
- Pratinjau huruf kini mati secara bawaan (nyalakan di menu grid) karena bisa menambah jeda di HP tertentu.

## v43: tahan huruf bisa dimatikan (bawaan: mati)
Menu grid → "Tahan huruf" memutar: Mati → 300 ms → 450 ms. Saat mati, tidak ada timer sama sekali (angka/simbol kecil di pojok tombol disembunyikan, spasi tidak punya mode kursor), semua tombol murni mengetik saat disentuh. Spasi kini juga mengetik saat disentuh. Saran kata diperbarui 100 ms setelah ketikan berhenti.

## v44: ikon lebih bersih + gelembung tekan
- Garis ikon dibuat lebih tipis dan seragam; ikon pengaturan dan petir dirapikan.
- Saat huruf ditekan, muncul salinan tombol berwarna lain (warna sorot tema) di atasnya, dengan animasi singkat. Digambar di dalam keyboard sendiri (bukan jendela terpisah), jadi ringan. Bisa dimatikan lewat menu grid "Pratinjau huruf".
