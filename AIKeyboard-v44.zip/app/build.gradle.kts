plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.byhas.aikeyboard"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.byhas.aikeyboard"
        minSdk = 24
        targetSdk = 34
        val run = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionCode = run
        versionName = "1.0.$run"
        buildConfigField("String", "REPO", "\"${System.getenv("GITHUB_REPOSITORY") ?: ""}\"")
    }
    signingConfigs {
        create("main") {
            storeFile = file("aikeyboard.jks")
            storePassword = "aikeyboard"
            keyAlias = "aikeyboard"
            keyPassword = "aikeyboard"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("main") }
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core:1.13.1")
}
