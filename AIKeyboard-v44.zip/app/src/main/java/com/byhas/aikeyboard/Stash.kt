package com.byhas.aikeyboard

import android.content.Context
import org.json.JSONArray

/** Penyimpanan kecil untuk: teks yang di-pin, riwayat hasil AI, dan saklar Auto-TR. */
object Stash {
    private fun sp(c: Context) = c.getSharedPreferences("kb_stash", Context.MODE_PRIVATE)

    private fun load(c: Context, k: String): ArrayList<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp(c).getString(k, "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(c: Context, k: String, l: List<String>) {
        val a = JSONArray()
        l.forEach { a.put(it) }
        sp(c).edit().putString(k, a.toString()).apply()
    }

    fun pins(c: Context): ArrayList<String> = load(c, "pins")
    fun setPins(c: Context, l: List<String>) = save(c, "pins", l)

    fun aiHist(c: Context): ArrayList<String> = load(c, "aihist")
    fun setAiHist(c: Context, l: List<String>) = save(c, "aihist", l)
    fun addAi(c: Context, out: String) {
        if (out.isBlank()) return
        val l = aiHist(c)
        l.remove(out)
        l.add(0, out)
        while (l.size > 30) l.removeAt(l.size - 1)
        setAiHist(c, l)
    }

    fun autoTr(c: Context) = sp(c).getBoolean("autoTr", false)
    fun setAutoTr(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoTr", v).apply()
}
