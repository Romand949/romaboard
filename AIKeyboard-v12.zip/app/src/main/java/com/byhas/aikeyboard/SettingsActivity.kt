package com.byhas.aikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = if (bold) 18f else 14f
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(14), 0, dp(4))
        return v
    }

    private fun checkUpdate(info: TextView, btn: Button) {
        if (BuildConfig.REPO.isBlank()) { runOnUiThread { info.text = "Cek update nonaktif (repo tidak terdeteksi)"; info.visibility = android.view.View.VISIBLE }; return }
        Thread {
            try {
                val con = URL("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").openConnection() as HttpURLConnection
                con.connectTimeout = 10000
                con.readTimeout = 10000
                con.setRequestProperty("Accept", "application/vnd.github+json")
                con.setRequestProperty("User-Agent", "AIKeyboard/1.0 (Android)")
                if (con.responseCode != 200) {
                    val rc = con.responseCode
                    runOnUiThread { info.text = "Cek update gagal (kode $rc). Repo harus publik."; info.visibility = android.view.View.VISIBLE }
                } else {
                    val j = JSONObject(con.inputStream.bufferedReader().readText())
                    val n = j.getString("tag_name").filter { it.isDigit() }.toIntOrNull() ?: 0
                    val assets = j.getJSONArray("assets")
                    var url = ""
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
                    }
                    if (url.isEmpty() || n <= BuildConfig.VERSION_CODE) {
                        runOnUiThread { info.text = "Sudah versi terbaru (build ${BuildConfig.VERSION_CODE})"; info.visibility = android.view.View.VISIBLE }
                    }
                    if (url.isNotEmpty() && n > BuildConfig.VERSION_CODE) {
                        runOnUiThread {
                            info.text = "Versi baru tersedia (build $n). Versi kamu: build ${BuildConfig.VERSION_CODE}."
                            info.visibility = android.view.View.VISIBLE
                            btn.visibility = android.view.View.VISIBLE
                            btn.setOnClickListener { download(url, btn) }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { info.text = "Cek update gagal: " + (e.message ?: e.javaClass.simpleName).take(60); info.visibility = android.view.View.VISIBLE }
            }
        }.start()
    }

    private fun download(url: String, btn: Button) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Izinkan install dari aplikasi ini, lalu tekan Update lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        btn.isEnabled = false
        btn.text = "Mengunduh…"
        Thread {
            try {
                val f = File(cacheDir, "update.apk")
                val con = URL(url).openConnection() as HttpURLConnection
                con.connectTimeout = 15000
                con.readTimeout = 60000
                con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread {
                    btn.isEnabled = true
                    btn.text = "Update sekarang"
                    installApk(f)
                }
            } catch (e: Exception) {
                runOnUiThread { btn.isEnabled = true; btn.text = "Gagal, coba lagi" }
            }
        }.start()
    }

    private fun installApk(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun model0() = Prefs.model(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(24), dp(18), dp(24))

        col.addView(label("AI Keyboard", true))
        col.addView(label("Versi: ${BuildConfig.VERSION_NAME}"))
        val upInfo = TextView(this)
        upInfo.visibility = android.view.View.GONE
        val upBtn = Button(this); upBtn.text = "Update sekarang"
        upBtn.visibility = android.view.View.GONE
        val upCheck = Button(this); upCheck.text = "Cek update"
        upCheck.setOnClickListener {
            upInfo.text = "Memeriksa versi terbaru…"
            upInfo.visibility = android.view.View.VISIBLE
            upBtn.visibility = android.view.View.GONE
            upBtn.text = "Update sekarang"
            upBtn.isEnabled = true
            checkUpdate(upInfo, upBtn)
        }
        col.addView(upCheck)
        col.addView(upInfo)
        col.addView(upBtn)
        checkUpdate(upInfo, upBtn)
        col.addView(label("1) Aktifkan keyboard, 2) pilih sebagai keyboard utama."))
        val b1 = Button(this); b1.text = "Aktifkan keyboard"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        col.addView(b1)
        val b2 = Button(this); b2.text = "Pilih keyboard"
        b2.setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        col.addView(b2)

        col.addView(label("3) Isi API key Groq milikmu sendiri (gratis, tiap orang pakai key sendiri)"))
        val getKey = Button(this); getKey.text = "Buka situs Groq untuk buat key"
        getKey.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://console.groq.com/keys"))) }
        col.addView(getKey)
        val key = EditText(this)
        key.setText(Prefs.ownKey(this)); key.setSingleLine(true)
        key.hint = "gsk_..."
        key.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(key)
        // Simpan otomatis setiap kali key diubah/ditempel, tanpa harus menekan tombol Simpan.
        key.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { Prefs.setKey(this@SettingsActivity, s?.toString() ?: "") }
        })

        val test = Button(this); test.text = "Tes key"
        test.setOnClickListener {
            test.text = "Menguji…"
            AiClient.ask(Prefs.clean(key.text.toString()), model0(), "Reply with OK.", "ping",
                { test.text = "Key berfungsi ✓" }, { e -> test.text = "Gagal: $e" })
        }
        col.addView(test)

        col.addView(label("Model AI"))
        val model = EditText(this)
        model.setText(Prefs.model(this)); model.setSingleLine(true)
        col.addView(model)
        val modelList = listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile", "openai/gpt-oss-20b", "openai/gpt-oss-120b")
        val swap = Button(this); swap.text = "Ganti model (ketuk untuk pilih)"
        swap.setOnClickListener {
            val i = modelList.indexOf(model.text.toString().trim())
            model.setText(modelList[(i + 1) % modelList.size])
        }
        col.addView(swap)
        col.addView(label("Cepat & limit besar: llama-3.1-8b-instant. Lebih pintar: llama-3.3-70b-versatile"))

        col.addView(label("Bahasa terjemahan"))
        val lang = EditText(this)
        lang.setText(Prefs.lang(this)); lang.setSingleLine(true)
        col.addView(lang)

        val hap = CheckBox(this); hap.text = "Getar saat mengetik"; hap.isChecked = Prefs.haptic(this)
        col.addView(hap)
        val sound = CheckBox(this); sound.text = "Suara ketik"; sound.isChecked = Prefs.sound(this)
        col.addView(sound)
        val sug = CheckBox(this); sug.text = "Saran kata (belajar dari yang kamu ketik)"; sug.isChecked = Prefs.suggest(this)
        col.addView(sug)
        val ks = Button(this)
        val ksNames = listOf("Kecil", "Sedang", "Besar")
        ks.text = "Tinggi tombol: " + ksNames[Prefs.keySize(this)]
        ks.setOnClickListener {
            Prefs.setKeySize(this, (Prefs.keySize(this) + 1) % 3)
            ks.text = "Tinggi tombol: " + ksNames[Prefs.keySize(this)]
        }
        col.addView(ks)
        val hd = Button(this)
        val hdNames = listOf("Mati", "Kiri", "Kanan")
        hd.text = "Mode satu tangan: " + hdNames[Prefs.hand(this)]
        hd.setOnClickListener {
            Prefs.setHand(this, (Prefs.hand(this) + 1) % 3)
            hd.text = "Mode satu tangan: " + hdNames[Prefs.hand(this)]
        }
        col.addView(hd)
        val vlCodes = listOf("id-ID", "en-US", "ms-MY")
        val vlNames = listOf("Indonesia", "English", "Melayu")
        val vl = Button(this)
        fun vlIdx() = vlCodes.indexOf(Prefs.voiceLang(this)).let { if (it < 0) 0 else it }
        vl.text = "Bahasa suara ke teks: " + vlNames[vlIdx()]
        vl.setOnClickListener {
            Prefs.setVoiceLang(this, vlCodes[(vlIdx() + 1) % vlCodes.size])
            vl.text = "Bahasa suara ke teks: " + vlNames[vlIdx()]
        }
        col.addView(vl)

        val numRow = CheckBox(this); numRow.text = "Baris angka di atas"; numRow.isChecked = Prefs.numRow(this)
        col.addView(numRow)
        val autoCap = CheckBox(this); autoCap.text = "Huruf besar otomatis di awal kalimat"; autoCap.isChecked = Prefs.autoCap(this)
        col.addView(autoCap)
        val dbl = CheckBox(this); dbl.text = "Spasi dua kali = titik"; dbl.isChecked = Prefs.dblSpace(this)
        col.addView(dbl)

        col.addView(label("Teks cepat ⚡ (satu baris = satu teks)"))
        val snip = EditText(this)
        snip.setText(Prefs.snippets(this)); snip.minLines = 3
        col.addView(snip)

        col.addView(label("Prompt kustom untuk tombol Kustom (contoh: Ubah jadi caption Instagram singkat)"))
        val custom = EditText(this)
        custom.setText(Prefs.custom(this)); custom.minLines = 2
        col.addView(custom)

        col.addView(label("Tema"))
        Prefs.themes.forEachIndexed { i, t ->
            val b = Button(this); b.text = t.name
            b.setOnClickListener { Prefs.setTheme(this, i); b.text = t.name + " ✓" }
            col.addView(b)
        }

        val save = Button(this); save.text = "Simpan"
        save.setOnClickListener {
            Prefs.setKey(this, key.text.toString())
            Prefs.setModel(this, model.text.toString().trim().ifBlank { "llama-3.1-8b-instant" })
            Prefs.setLang(this, lang.text.toString().trim().ifBlank { "English" })
            Prefs.setHaptic(this, hap.isChecked)
            Prefs.setSound(this, sound.isChecked)
            Prefs.setSuggest(this, sug.isChecked)
            Prefs.setNumRow(this, numRow.isChecked)
            Prefs.setAutoCap(this, autoCap.isChecked)
            Prefs.setDblSpace(this, dbl.isChecked)
            Prefs.setSnippets(this, snip.text.toString())
            Prefs.setCustom(this, custom.text.toString().trim())
            save.text = "Tersimpan ✓"
        }
        col.addView(save)

        col.addView(label("Coba ketik di sini:"))
        col.addView(EditText(this))

        val sv = ScrollView(this)
        sv.addView(col)
        sv.alpha = 0f
        setContentView(sv)
        sv.animate().alpha(1f).setDuration(250).start()
    }
}
