package com.byhas.aikeyboard

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

class AiKeyboardService : InputMethodService() {
    companion object { @Volatile var instance: AiKeyboardService? = null }

    private lateinit var kb: KeyboardController
    private val h = Handler(Looper.getMainLooper())
    private var collapsed = false

    private val permanent get() = Prefs.permanent(this)

    private val host = object : KeyboardController.Host {
        override val overlay get() = permanent
        override fun ic(): InputConnection? = currentInputConnection
        override fun editorAction() = sendDefaultEditorAction(true)
        override fun rebuild() { setInputView(kb.build()) }
        override fun stopPermanent() { stopPermanentMode() }
        override fun collapse() { collapsed = true; requestHideSelf(0) }
        override fun hideIme() { requestHideSelf(0) }
        override fun startPermanentMode() { this@AiKeyboardService.startPermanentMode() }
    }

    // Saat mode permanen, jendela keyboard dianggap selalu perlu tampil (seperti keyboard biasa).
    override fun onEvaluateInputViewShown(): Boolean = permanent || super.onEvaluateInputViewShown()

    override fun onEvaluateFullscreenMode(): Boolean = false

    private val reshow = Runnable {
        if (permanent && !collapsed && !isInputViewShown) {
            try { requestShowSelf(0) } catch (_: Exception) {}
        }
    }

    private fun scheduleReshow() {
        h.removeCallbacks(reshow)
        if (permanent && !collapsed) h.postDelayed(reshow, 250)
    }

    fun startPermanentMode() {
        Prefs.setPermanent(this, true)
        collapsed = false
        setInputView(kb.build())
        try { requestShowSelf(0) } catch (_: Exception) {}
    }

    fun stopPermanentMode() {
        Prefs.setPermanent(this, false)
        collapsed = false
        h.removeCallbacks(reshow)
        setInputView(kb.build())
        requestHideSelf(0)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        kb = KeyboardController(this, host)
        kb.create()
    }

    override fun onCreateInputView(): View = kb.build()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        collapsed = false
        kb.startInput()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        scheduleReshow()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        scheduleReshow()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        kb.finishInput()
    }

    override fun onDestroy() {
        h.removeCallbacks(reshow)
        if (instance === this) instance = null
        kb.destroy()
        super.onDestroy()
    }
}
