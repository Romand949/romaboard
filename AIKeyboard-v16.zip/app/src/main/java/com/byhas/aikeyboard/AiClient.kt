package com.byhas.aikeyboard

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    private val main = Handler(Looper.getMainLooper())
    private val fallbacks = listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile", "openai/gpt-oss-20b")

    fun ask(key: String, model: String, system: String, user: String,
            onOk: (String) -> Unit, onErr: (String) -> Unit) {
        if (key.isBlank()) { onErr("API key kosong. Buka app AI Keyboard lalu isi API key."); return }
        Thread {
            val models = (listOf(model.trim()) + fallbacks).filter { it.isNotEmpty() }.distinct()
            var lastErr = "Gagal"
            try {
                for (m in models) {
                    val body = JSONObject().apply {
                        put("model", m)
                        put("temperature", 0.5)
                        put("max_tokens", 600)
                        put("messages", JSONArray().apply {
                            put(JSONObject().put("role", "system").put("content", system))
                            put(JSONObject().put("role", "user").put("content", user))
                        })
                    }
                    val con = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
                    con.requestMethod = "POST"
                    con.connectTimeout = 15000
                    con.readTimeout = 30000
                    con.doOutput = true
                    con.setRequestProperty("Content-Type", "application/json")
                    con.setRequestProperty("Accept", "application/json")
                    con.setRequestProperty("User-Agent", "AIKeyboard/1.0 (Android)")
                    con.setRequestProperty("Authorization", "Bearer " + key.trim())
                    con.outputStream.use { it.write(body.toString().toByteArray()) }
                    val code = con.responseCode
                    val stream = if (code in 200..299) con.inputStream else con.errorStream
                    val text = stream?.bufferedReader()?.readText() ?: ""
                    if (code in 200..299) {
                        val out = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                            .getJSONObject("message").getString("content").trim()
                        main.post { onOk(out) }
                        return@Thread
                    }
                    val detail = try {
                        JSONObject(text).optJSONObject("error")?.optString("message") ?: ""
                    } catch (e: Exception) { "" }
                    lastErr = when (code) {
                        401 -> "API key salah"
                        429 -> "Limit habis, coba lagi sebentar"
                        else -> "Error $code " + detail.take(90)
                    }
                    if (code != 404) break
                }
            } catch (e: Exception) {
                lastErr = when (e) {
                    is java.net.UnknownHostException -> "Tidak bisa menjangkau api.groq.com (DNS/internet/VPN?)"
                    is java.net.SocketTimeoutException -> "Koneksi timeout, coba lagi"
                    is javax.net.ssl.SSLException -> "Gagal SSL/jam HP salah? " + (e.message ?: "").take(60)
                    is org.json.JSONException -> "Balasan AI tidak terbaca, coba model lain"
                    else -> "Gagal: " + e.javaClass.simpleName + " " + (e.message ?: "").take(70)
                }
            }
            main.post { onErr(lastErr) }
        }.start()
    }
}
