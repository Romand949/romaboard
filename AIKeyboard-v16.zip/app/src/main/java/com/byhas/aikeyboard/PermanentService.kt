package com.byhas.aikeyboard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.InputConnection
import android.widget.TextView

/**
 * Keyboard permanen: keyboard digambar sebagai jendela overlay (tidak mengambil fokus),
 * dan teks dimasukkan ke kolom ketik yang sedang fokus lewat layanan aksesibilitas.
 */
class PermanentService : AccessibilityService() {
    companion object { @Volatile var instance: PermanentService? = null }

    private lateinit var wm: WindowManager
    private var kb: KeyboardController? = null
    private var big: View? = null
    private var small: View? = null
    private var shown = false
    private var input: AccInput? = null
    private val h = Handler(Looper.getMainLooper())
    private var intentional = false

    // Pengawal: kalau sistem/app lain menutup jendela keyboard, pasang lagi otomatis.
    private val guard = object : Runnable {
        override fun run() {
            if (!shown) return
            val v = small ?: big
            if (v != null && !v.isAttachedToWindow) reattach(v)
            h.postDelayed(this, 800)
        }
    }

    private fun lp(v: View) = if (v === small) params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
        else params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)

    private fun reattach(v: View) {
        try {
            wm.addView(v, lp(v))
            if (v !== small) softKeyboardController.showMode = SHOW_MODE_HIDDEN
        } catch (_: Exception) {}
    }

    private val watcher = object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) {}
        override fun onViewDetachedFromWindow(v: View) {
            if (shown && !intentional) h.postDelayed({ if (shown && (v === big || v === small) && !v.isAttachedToWindow) reattach(v) }, 150)
        }
    }

    private fun addV(v: View, p: WindowManager.LayoutParams) {
        v.addOnAttachStateChangeListener(watcher)
        wm.addView(v, p)
    }

    private fun removeV(v: View?) {
        if (v == null) return
        intentional = true
        try { wm.removeView(v) } catch (_: Exception) {}
        intentional = false
    }

    private val host = object : KeyboardController.Host {
        override val overlay = true
        override fun ic(): InputConnection? = input
        override fun editorAction(): Boolean = input?.imeEnter() ?: false
        override fun rebuild() { if (shown && small == null) swapBig() }
        override fun stopPermanent() { stop() }
        override fun collapse() { collapseUi() }
        override fun hideIme() {}
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        // Mode permanen kini dijalankan oleh AiKeyboardService (keyboard asli); overlay lama tidak otomatis menyala.
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (shown && small == null && e?.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED) kb?.startInput()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hideViews(); instance = null
        return super.onUnbind(intent)
    }

    fun start() { Prefs.setPermanent(this, true); show() }
    fun stop() { Prefs.setPermanent(this, false); hideViews() }
    /** Dipanggil app pengaturan setelah tampilan diubah. */
    fun refresh() { if (shown && small == null) { kb?.startInput() } }

    private fun params(height: Int, grav: Int) = WindowManager.LayoutParams(
        if (height == WindowManager.LayoutParams.WRAP_CONTENT && grav == (Gravity.BOTTOM)) WindowManager.LayoutParams.MATCH_PARENT else WindowManager.LayoutParams.WRAP_CONTENT,
        height, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT).also { it.gravity = grav }

    private fun show() {
        if (shown) return
        val c = KeyboardController(this, host)
        kb = c
        c.create()
        shown = true
        val v = c.build()
        // build() sudah memanggil render(); input dibuat setelah view ada
        input = AccInput(this, v)
        big = v
        addV(v, params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        softKeyboardController.showMode = SHOW_MODE_HIDDEN
        c.startInput()
        h.removeCallbacks(guard); h.postDelayed(guard, 800)
    }

    private fun swapBig() {
        val c = kb ?: return
        removeV(big)
        val v = c.build()
        input = AccInput(this, v)
        big = v
        addV(v, params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
    }

    private fun collapseUi() {
        removeV(big)
        big = null
        kb?.finishInput()
        softKeyboardController.showMode = SHOW_MODE_AUTO
        val t = TextView(this)
        t.text = "⌨ ▲"
        t.textSize = 18f
        t.setTextColor(0xFFFFFFFF.toInt())
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(40, 24, 40, 24)
        t.setBackgroundColor(0xE6303040.toInt())
        t.setOnClickListener { expand() }
        small = t
        addV(t, params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END))
    }

    private fun expand() {
        removeV(small)
        small = null
        val c = kb ?: return
        val v = c.build()
        input = AccInput(this, v)
        big = v
        addV(v, params(WindowManager.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        softKeyboardController.showMode = SHOW_MODE_HIDDEN
        c.startInput()
    }

    private fun hideViews() {
        if (!shown) return
        removeV(big)
        removeV(small)
        big = null; small = null; shown = false; input = null
        h.removeCallbacks(guard)
        kb?.destroy(); kb = null
        try { softKeyboardController.showMode = SHOW_MODE_AUTO } catch (_: Exception) {}
    }

    // ---------- cari kolom ketik yang fokus ----------
    fun focusedInput(): AccessibilityNodeInfo? {
        fun find(r: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            val n = r?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return null
            return if (n.isEditable) n else null
        }
        find(rootInActiveWindow)?.let { return it }
        try { for (w in windows) find(w.root)?.let { return it } } catch (_: Exception) {}
        return null
    }
}

/** InputConnection palsu: meneruskan perintah keyboard ke kolom ketik lewat aksesibilitas. */
class AccInput(private val svc: PermanentService, v: View) : BaseInputConnection(v, false) {
    private var lastText = ""
    private var lastBase = ""
    private var lastCursor = 0
    private var lastTime = 0L

    private class St(val node: AccessibilityNodeInfo, val text: String, val s: Int, val e: Int)

    private fun state(): St? {
        val n = svc.focusedInput() ?: return null
        if (n.isPassword) return null // teks sandi tersamar, tidak aman diubah
        n.refresh()
        var t = if (android.os.Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) "" else (n.text?.toString() ?: "")
        var s = n.textSelectionStart
        var e = n.textSelectionEnd
        // baca ulang terlalu cepat setelah menulis bisa dapat data lama; pakai catatan sendiri
        if (System.currentTimeMillis() - lastTime < 350 && (t == lastBase || t == lastText) && t != lastText) {
            t = lastText; s = lastCursor; e = lastCursor
        }
        if (s < 0 || e < 0) { s = t.length; e = t.length }
        if (s > e) { val x = s; s = e; e = x }
        s = s.coerceIn(0, t.length); e = e.coerceIn(0, t.length)
        return St(n, t, s, e)
    }

    private fun write(st: St, text: String, cursor: Int): Boolean {
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        val ok = st.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        val sb = Bundle()
        sb.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor)
        sb.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor)
        st.node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sb)
        lastBase = st.text; lastText = text; lastCursor = cursor; lastTime = System.currentTimeMillis()
        return ok
    }

    override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
        val st = state() ?: return false
        val ins = text?.toString() ?: ""
        val nt = st.text.substring(0, st.s) + ins + st.text.substring(st.e)
        return write(st, nt, st.s + ins.length)
    }

    override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
        val st = state() ?: return false
        var b = beforeLength
        if (b == 1 && st.s >= 2 && Character.isLowSurrogate(st.text[st.s - 1]) && Character.isHighSurrogate(st.text[st.s - 2])) b = 2
        val from = (st.s - b).coerceAtLeast(0)
        val to = (st.e + afterLength).coerceAtMost(st.text.length)
        return write(st, st.text.substring(0, from) + st.text.substring(to), from)
    }

    override fun getTextBeforeCursor(n: Int, flags: Int): CharSequence? {
        val st = state() ?: return ""
        return st.text.substring((st.s - n).coerceAtLeast(0), st.s)
    }

    override fun getTextAfterCursor(n: Int, flags: Int): CharSequence? {
        val st = state() ?: return ""
        return st.text.substring(st.e, (st.e + n).coerceAtMost(st.text.length))
    }

    override fun getSelectedText(flags: Int): CharSequence? {
        val st = state() ?: return null
        return if (st.e > st.s) st.text.substring(st.s, st.e) else null
    }

    override fun setSelection(start: Int, end: Int): Boolean {
        val st = state() ?: return false
        val b = Bundle()
        b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, start)
        b.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, end)
        return st.node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b)
    }

    fun imeEnter(): Boolean {
        val n = svc.focusedInput() ?: return false
        if (android.os.Build.VERSION.SDK_INT >= 30 && !n.isMultiLine)
            return n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        return false
    }

    override fun sendKeyEvent(event: KeyEvent?): Boolean {
        if (event == null || event.action != KeyEvent.ACTION_DOWN) return true
        when (event.keyCode) {
            KeyEvent.KEYCODE_DEL -> deleteSurroundingText(1, 0)
            KeyEvent.KEYCODE_ENTER -> { if (svc.focusedInput()?.isMultiLine == true) commitText("\n", 1) }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                val st = state() ?: return false
                val p = (if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) st.s - 1 else st.e + 1).coerceIn(0, st.text.length)
                setSelection(p, p)
            }
        }
        return true
    }

    override fun performContextMenuAction(id: Int): Boolean {
        val st = state() ?: return false
        return when (id) {
            android.R.id.selectAll -> setSelection(0, st.text.length)
            android.R.id.copy -> st.node.performAction(AccessibilityNodeInfo.ACTION_COPY)
            android.R.id.cut -> st.node.performAction(AccessibilityNodeInfo.ACTION_CUT)
            android.R.id.paste -> st.node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            else -> false
        }
    }
}
