package com.byhas.aikeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import java.io.File

class KbTheme(val name: String, val bg: Int, val key: Int, val fn: Int, val text: Int, val accent: Int)

object Prefs {
    val themes = listOf(
        KbTheme("Gelap", Color.parseColor("#1E1E24"), Color.parseColor("#34343E"), Color.parseColor("#26262E"), Color.WHITE, Color.parseColor("#7C5CFF")),
        KbTheme("Terang", Color.parseColor("#E4E6EB"), Color.WHITE, Color.parseColor("#C9CCD3"), Color.parseColor("#111111"), Color.parseColor("#2E7DFF")),
        KbTheme("Samudra", Color.parseColor("#0B2239"), Color.parseColor("#17405F"), Color.parseColor("#10304A"), Color.WHITE, Color.parseColor("#27D3C3")),
        KbTheme("Sakura", Color.parseColor("#FBE4EC"), Color.WHITE, Color.parseColor("#F4C2D4"), Color.parseColor("#4A1F30"), Color.parseColor("#E94B83")),
        KbTheme("Kustom", Color.parseColor("#1E1E24"), Color.parseColor("#34343E"), Color.parseColor("#26262E"), Color.WHITE, Color.parseColor("#7C5CFF"))
    )
    val colorKeys = listOf("cBg" to "Latar keyboard", "cKey" to "Tombol huruf", "cFn" to "Tombol fungsi", "cText" to "Warna teks", "cAccent" to "Warna saat ditekan")
    fun parseHex(v: String?): Int? = try { Color.parseColor(if (v!!.startsWith("#")) v else "#$v") } catch (e: Exception) { null }
    fun colorHex(c: Context, key: String): String {
        val d = themes[4]
        val def = when (key) { "cBg" -> d.bg; "cKey" -> d.key; "cFn" -> d.fn; "cText" -> d.text; else -> d.accent }
        return sp(c).getString(key, null) ?: String.format("#%06X", def and 0xFFFFFF)
    }
    fun setColorHex(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()
    fun currentTheme(c: Context): KbTheme {
        val i = theme(c)
        if (i != 4) return themes[i]
        fun col(k: String) = parseHex(colorHex(c, k)) ?: Color.GRAY
        return KbTheme("Kustom", col("cBg"), col("cKey"), col("cFn"), col("cText"), col("cAccent"))
    }

    // ---- tampilan yang bisa diatur ----
    fun keyHeightDp(c: Context) = sp(c).getInt("keyH", listOf(44, 50, 58)[keySize(c)]).coerceIn(28, 100)
    fun setKeyHeightDp(c: Context, v: Int) = sp(c).edit().putInt("keyH", v).apply()
    fun gapX(c: Context) = sp(c).getInt("gapX", 2).coerceIn(0, 12)
    fun setGapX(c: Context, v: Int) = sp(c).edit().putInt("gapX", v).apply()
    fun gapY(c: Context) = sp(c).getInt("gapY", 3).coerceIn(0, 12)
    fun setGapY(c: Context, v: Int) = sp(c).edit().putInt("gapY", v).apply()
    fun radius(c: Context) = sp(c).getInt("radius", 8).coerceIn(0, 30)
    fun setRadius(c: Context, v: Int) = sp(c).edit().putInt("radius", v).apply()
    fun fontScale(c: Context) = sp(c).getInt("fontScale", 100).coerceIn(50, 220)
    fun setFontScale(c: Context, v: Int) = sp(c).edit().putInt("fontScale", v).apply()
    fun keyAlpha(c: Context) = sp(c).getInt("keyAlpha", 100).coerceIn(10, 100)
    fun setKeyAlpha(c: Context, v: Int) = sp(c).edit().putInt("keyAlpha", v).apply()
    fun sidePad(c: Context) = sp(c).getInt("sidePad", 3).coerceIn(0, 40)
    fun setSidePad(c: Context, v: Int) = sp(c).edit().putInt("sidePad", v).apply()
    fun topPad(c: Context) = sp(c).getInt("topPad", 3).coerceIn(0, 40)
    fun setTopPad(c: Context, v: Int) = sp(c).edit().putInt("topPad", v).apply()
    fun bottomPad(c: Context) = sp(c).getInt("bottomPad", 6).coerceIn(0, 60)
    fun setBottomPad(c: Context, v: Int) = sp(c).edit().putInt("bottomPad", v).apply()
    fun tbH(c: Context) = sp(c).getInt("tbH", 40).coerceIn(24, 80)
    fun setTbH(c: Context, v: Int) = sp(c).edit().putInt("tbH", v).apply()
    fun tbW(c: Context) = sp(c).getInt("tbW", 58).coerceIn(32, 120)
    fun setTbW(c: Context, v: Int) = sp(c).edit().putInt("tbW", v).apply()
    fun bold(c: Context) = sp(c).getBoolean("bold", false)
    fun setBold(c: Context, v: Boolean) = sp(c).edit().putBoolean("bold", v).apply()

    val fontNames = listOf("Bawaan", "Serif", "Mono", "Cursive", "Casual", "Condensed", "Light", "Thin", "Medium", "Black", "Serif Mono", "Small Caps", "Font sendiri")
    private val fontFamilies = listOf(null, "serif", "monospace", "cursive", "casual", "sans-serif-condensed", "sans-serif-light", "sans-serif-thin", "sans-serif-medium", "sans-serif-black", "serif-monospace", "sans-serif-smallcaps")
    fun fontIdx(c: Context) = sp(c).getInt("font", 0).coerceIn(0, fontNames.size - 1)
    fun setFontIdx(c: Context, v: Int) = sp(c).edit().putInt("font", v).apply()
    fun fontRev(c: Context) = sp(c).getInt("fontRev", 0)
    fun bumpFontRev(c: Context) = sp(c).edit().putInt("fontRev", fontRev(c) + 1).apply()
    fun customFontFile(c: Context) = File(c.filesDir, "customfont.ttf")
    fun typeface(c: Context): Typeface {
        val style = if (bold(c)) Typeface.BOLD else Typeface.NORMAL
        val i = fontIdx(c)
        val base: Typeface = if (i == fontNames.size - 1) {
            try { if (customFontFile(c).exists()) Typeface.createFromFile(customFontFile(c)) else Typeface.DEFAULT } catch (e: Exception) { Typeface.DEFAULT }
        } else {
            val fam = fontFamilies[i]
            if (fam == null) Typeface.DEFAULT else Typeface.create(fam, Typeface.NORMAL)
        }
        return Typeface.create(base, style)
    }
    private val appearanceKeys = listOf("theme", "keyH", "keySize", "gapX", "gapY", "radius", "fontScale", "keyAlpha", "sidePad", "topPad", "bottomPad",
        "tbH", "tbW", "bold", "font", "fontRev", "hand", "cBg", "cKey", "cFn", "cText", "cAccent")
    fun appearanceSig(c: Context): String { val a = sp(c).all; return appearanceKeys.joinToString("|") { a[it].toString() } }

    // ---- keyboard permanen ----
    fun permanent(c: Context) = sp(c).getBoolean("permanent", false)
    fun setPermanent(c: Context, v: Boolean) = sp(c).edit().putBoolean("permanent", v).apply()
    private fun sp(c: Context) = c.getSharedPreferences("kb", Context.MODE_PRIVATE)
    fun clean(v: String): String = v.filter { !it.isWhitespace() && it.code in 33..126 }
    fun apiKey(c: Context): String = clean(sp(c).getString("apiKey", "") ?: "")
    fun ownKey(c: Context) = sp(c).getString("apiKey", "") ?: ""
    fun setKey(c: Context, v: String) = sp(c).edit().putString("apiKey", clean(v)).apply()
    fun model(c: Context) = sp(c).getString("model", "llama-3.1-8b-instant") ?: "llama-3.1-8b-instant"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v).apply()
    fun theme(c: Context) = sp(c).getInt("theme", 0).coerceIn(0, themes.size - 1)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()
    fun lang(c: Context) = sp(c).getString("lang", "English") ?: "English"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptic", v).apply()
    fun numRow(c: Context) = sp(c).getBoolean("numRow", true)
    fun setNumRow(c: Context, v: Boolean) = sp(c).edit().putBoolean("numRow", v).apply()
    fun autoCap(c: Context) = sp(c).getBoolean("autoCap", true)
    fun setAutoCap(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoCap", v).apply()
    fun dblSpace(c: Context) = sp(c).getBoolean("dblSpace", true)
    fun setDblSpace(c: Context, v: Boolean) = sp(c).edit().putBoolean("dblSpace", v).apply()
    fun snippets(c: Context) = sp(c).getString("snippets", "Terima kasih banyak \uD83D\uDE4F\nSiap, ditunggu ya\nMaaf baru balas, tadi sibuk\nAssalamualaikum") ?: ""
    fun setSnippets(c: Context, v: String) = sp(c).edit().putString("snippets", v).apply()
    fun custom(c: Context) = sp(c).getString("custom", "") ?: ""
    fun setCustom(c: Context, v: String) = sp(c).edit().putString("custom", v).apply()
    fun sound(c: Context) = sp(c).getBoolean("sound", false)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()
    fun suggest(c: Context) = sp(c).getBoolean("suggest", true)
    fun setSuggest(c: Context, v: Boolean) = sp(c).edit().putBoolean("suggest", v).apply()
    fun keySize(c: Context) = sp(c).getInt("keySize", 1).coerceIn(0, 2)
    fun setKeySize(c: Context, v: Int) = sp(c).edit().putInt("keySize", v).apply()
    fun hand(c: Context) = sp(c).getInt("hand", 0).coerceIn(0, 2)
    fun setHand(c: Context, v: Int) = sp(c).edit().putInt("hand", v).apply()
    fun recent(c: Context) = sp(c).getString("recent", "") ?: ""
    fun setRecent(c: Context, v: String) = sp(c).edit().putString("recent", v).apply()
    fun words(c: Context) = sp(c).getString("words", "") ?: ""
    fun setWords(c: Context, v: String) = sp(c).edit().putString("words", v).apply()
    fun voiceLang(c: Context) = sp(c).getString("voiceLang", "id-ID") ?: "id-ID"
    fun setVoiceLang(c: Context, v: String) = sp(c).edit().putString("voiceLang", v).apply()
}
