# Romaboard

Keyboard Android buatan sendiri: QWERTY, simbol, emoji, riwayat clipboard, 4 tema, dan fitur AI (perbaiki, formal, santai, ringkas, terjemah, balas, lanjutkan, tanya AI) memakai Groq (gratis).

## Cara build (100% di GitHub)
1. Upload zip ini ke repo GitHub, lalu buat `.github/workflows/build.yml`.
2. Tab Actions > Build APK > Run workflow, download artifact `AIKeyboard-apk`.
3. Install APK. Tidak ada API key di dalam APK.

## Cara pakai
Buka app Romaboard, aktifkan dan pilih keyboard, lalu tempel API key Groq milikmu sendiri (gratis di console.groq.com/keys). Tiap pengguna memakai key sendiri.

## Ikon AI (Tanya AI)
Selain ikon Romaboard, ada ikon kedua bernama "AI" di layar utama. Ketuk, halaman Tanya AI terbuka dan keyboard langsung muncul. Ketik perintah, AI menjawab di halaman itu, lalu ketuk Salin atau Bagikan untuk menempel ke WhatsApp atau app lain. Memakai API key dan model yang sama dengan pengaturan.

## Fitur
- Keyboard: baris angka, shift/caps, huruf besar otomatis, spasi 2x = titik, simbol, emoji, 4 tema
- Clipboard: riwayat salinan + alat Semua/Salin/Potong/Tempel/geser kursor
- Teks cepat (⚡): kalimat favorit, diatur di app
- AI: Perbaiki, Formal, Santai, Lucu, Ringkas, Baku, Emoji-in, Terjemah, Tanya AI, Balas, Lanjutkan, Kustom (prompt buatan sendiri), dan tombol Batal untuk mengembalikan teks asli

## Update otomatis
Setiap build membuat Release baru di GitHub (repo harus Public). Saat app Romaboard dibuka (atau saat tombol "Cek update" ditekan), ia mengecek Release terbaru; jika ada versi baru muncul tombol "Update sekarang". Android tetap meminta kamu menekan Install. Kunci tanda tangan (app/aikeyboard.jks) harus selalu ikut di zip supaya update bisa menimpa versi lama.

## Kenyamanan mengetik
Tombol bereaksi saat disentuh (lebih cepat), warna berubah saat ditekan, tinggi tombol bisa kecil/sedang/besar, mode satu tangan (↔), tombol 🌐 ganti keyboard, shift dua kali = CAPS LOCK, saran kata yang belajar dari ketikanmu, emoji per kategori + terakhir dipakai, suara ketik opsional.

## Suara ke teks & gaya teks
Tombol 🎤 (di bawah dan di atas) mengetik dari suara; izin mikrofon diminta saat pertama kali. Panel "Aa" mengubah teks jadi gaya tebal, miring, skrip, gotik, bulat, kotak, terbalik, coret, dan lain-lain. Tab (ツ) di emoji berisi kaomoji.

## Animasi
Tombol mengecil lalu memantul saat disentuh dan warnanya memudar halus, panel berpindah dengan geser + fade, saran kata dan pesan status muncul memudar, pesan "memproses"/mendengarkan berdenyut, halaman pengaturan muncul memudar.

## v13: tampilan bebas diatur + keyboard permanen
- Di app: slider tinggi tombol, ukuran font, jarak antar tombol, sudut, transparansi, margin, ukuran baris atas; jenis font (bawaan atau file .ttf/.otf sendiri), huruf tebal, warna tema Kustom (hex). Ada preview langsung.
- Keyboard permanen 📌: nyalakan layanan aksesibilitas "Romaboard Permanen", lalu tekan Mulai (di app) atau tombol 📌 (di keyboard). Keyboard tampil terus sebagai overlay sampai tombol ⏹ STOP ditekan. ▾ = kecilkan sementara.
- Batasan: kolom sandi tidak didukung; beberapa app dengan kolom ketik khusus (game, sebagian browser) bisa menolak teks dari aksesibilitas.

## v15: keyboard permanen = keyboard asli
Mode permanen 📌 kini memakai jendela keyboard biasa (InputMethodService), bukan overlay aksesibilitas, jadi tidak lagi ditutup otomatis oleh sistem. Layanan aksesibilitas tidak diperlukan lagi, dan kolom sandi ikut didukung. Syarat: pilih "Romaboard" sebagai keyboard aktif. Tekan ⏹ STOP untuk mematikan, ▾ untuk menyembunyikan sementara.

## v16: Tanya AI tampil di dalam keyboard
Jawaban 💬 Tanya AI sekarang muncul dulu di kotak jawaban di dalam keyboard (bisa di-scroll), tidak langsung masuk ke kotak ketik. Tombol ⤵ Taruh semua memasukkan jawaban ke kotak ketik, 📋 Salin menyalin, ✕ menutup. Kotak pertanyaan juga bisa di-scroll dan otomatis menggulir ke baris terakhir.

## v17: banyak API key + info model
- Bisa menambah API key tanpa batas (➕ Tambah API key). Tiap key punya tombol Pakai, Tes, Hapus, dan menampilkan sisa limit setelah dites atau dipakai.
- Kalau key aktif kena limit (429) atau salah (401), keyboard otomatis mencoba key berikutnya dan mengingat key yang berhasil.
- Daftar model dengan ukuran (kecil/besar) dan perkiraan limit (permintaan/menit, /hari, token/menit, /hari). Ketuk untuk memilih.
- Catatan: limit Groq dihitung per akun/organisasi, jadi pakai key dari akun berbeda.

## v18: ikon buatan sendiri + tata letak lebih rapi
- Semua ikon tombol keyboard kini digambar sendiri (Icons.kt, vektor via Canvas), tidak lagi memakai emoji: toolbar, mic, globe, enter/kirim, backspace, shift/caps, tutup, salin, taruh semua, batal, riwayat, dan panah kursor. Emoji hanya tersisa di dalam papan pemilih emoji.
- Toolbar: tab yang sedang aktif disorot warna aksen.
- Baris bawah disejajarkan dengan baris huruf (123 | globe | , | spasi | . | enter); mic cukup di toolbar. Lebar tombol ABC dan backspace di layar lain disamakan.
- Pesan status tanpa emoji.

## v19: pilihan animasi keyboard
Pengaturan → "Animasi keyboard":
- Animasi tekan tombol (10 pilihan): Membal (bawaan), Halus, Jelly, Pop-up besar, Miring 3D, Tekan dalam, Goyang miring, Getar, Riak cahaya, Tanpa animasi.
- Animasi pindah layar (7 pilihan): Naik & pudar (bawaan), Geser dari kanan, Zoom masuk, Lipat 3D, Jatuh membal, Pudar saja, Tanpa animasi.
- Animasi keyboard muncul (6 pilihan): Tanpa animasi (bawaan), Naik dari bawah, Pudar, Zoom dari bawah, Membal naik, Membuka dari bawah.
- Slider kecepatan animasi 40–300%, plus pratinjau yang bisa diketuk langsung di halaman pengaturan.
Kode: KeyAnim.kt.

## v20: keyboard permanen bisa diperkecil jadi ikon
Tombol ▾ pada keyboard permanen kini memperkecil keyboard menjadi satu ikon bulat (tidak menghilang). Ikon bisa digeser bebas (posisinya diingat) dan diketuk untuk membuka keyboard lagi. Saat jadi ikon, aplikasi di bawahnya tidak menyempit dan sentuhan di luar ikon diteruskan ke aplikasi. Tetap berjalan sebagai keyboard asli (InputMethodService), tanpa izin tambahan.

## v21: ikon mini lebih enak digeser
Area geser ikon diperluas (hingga ±85% tinggi layar, hampir ke atas), memakai batas geser bawaan Android, dan ikon membesar sedikit serta agak transparan saat digeser, lalu memantul kecil saat dilepas. Posisi tetap diingat.

## v39: tampilan keyboard bergaya baru
- Toolbar atas gelap: tombol menu (grid), Tema, Mikrofon, Klipboard. Tombol menu membuka grid fitur (Tema, Font, Klipboard, Pengeditan teks, Menerjemahkan, Bahasa, Baris Angka, Suara dan Getaran, AI, Emoji, Teks cepat, Baca layar, Ukuran tombol, Simbol, Satu tangan, Sematkan, Pengaturan).
- Tema bawaan baru "Klasik" (abu-abu gelap). Layar Tema berisi bulatan pratinjau; Tema Khusus memakai warna dari app.
- Papan huruf tanpa baris angka: angka/simbol kecil di pojok tombol, tekan-tahan untuk mengetiknya. Koma tahan = mikrofon, titik tahan = "!", spasi tahan = ganti keyboard, spasi menampilkan nama bahasa.
- Layar Klipboard baru: saklar tampil di toolbar, Tambahkan klip baru (kotak ketik + Batalkan/Menyimpan), pin, hapus dengan konfirmasi.
- Layar Pengeditan teks: panah, awal/akhir baris, pilih semua, salin, potong, tempel, batal AI.
- Pengaturan "Urutan tombol baris atas" tidak dipakai lagi oleh toolbar baru (semua tombol ada di menu grid).

## v41: nuansa keyboard iPhone
- Gelembung pratinjau huruf muncul di atas tombol saat ditekan (bisa dimatikan lewat menu "Pratinjau huruf").
- Tahan spasi lalu geser kiri/kanan untuk menggerakkan kursor; tahan spasi tanpa geser = pindah ke bahasa aktif berikutnya.
- Tombol hapus makin cepat kalau ditahan, lalu menghapus per kata.
- Bar saran kata bergaya iOS (tiga kata dipisah garis tipis).
- Animasi tekan baru "iPhone (halus)" (bawaan baru), keyboard muncul naik dari bawah.
- Tema baru: iOS Terang dan iOS Gelap. Baris tema di app bisa digeser.

## v42: ketikan tanpa delay + tombol huruf sama lebar
- Tombol huruf sekarang mengetik saat disentuh (bukan saat dilepas). Tekan-tahan 0,45 detik mengganti huruf dengan angka/simbol kecilnya.
- Ganti huruf besar/kecil (Shift, huruf kapital otomatis) tidak lagi membangun ulang keyboard, jadi tidak ada jeda.
- Saran kata dihitung setelah jeda singkat, supaya ketikan cepat tidak tertahan.
- Semua tombol huruf di ketiga baris selalu sama lebar. Lebar Shift & Hapus dibatasi maksimal 150%.
- Pratinjau huruf kini mati secara bawaan (nyalakan di menu grid) karena bisa menambah jeda di HP tertentu.

## v43: tahan huruf bisa dimatikan (bawaan: mati)
Menu grid → "Tahan huruf" memutar: Mati → 300 ms → 450 ms. Saat mati, tidak ada timer sama sekali (angka/simbol kecil di pojok tombol disembunyikan, spasi tidak punya mode kursor), semua tombol murni mengetik saat disentuh. Spasi kini juga mengetik saat disentuh. Saran kata diperbarui 100 ms setelah ketikan berhenti.

## v44: ikon lebih bersih + gelembung tekan
- Garis ikon dibuat lebih tipis dan seragam; ikon pengaturan dan petir dirapikan.
- Saat huruf ditekan, muncul salinan tombol berwarna lain (warna sorot tema) di atasnya, dengan animasi singkat. Digambar di dalam keyboard sendiri (bukan jendela terpisah), jadi ringan. Bisa dimatikan lewat menu grid "Pratinjau huruf".

## v45: baris angka di atas + hint seperti keyboard referensi
Baris angka 1-0 kini selalu tampil di paling atas (bisa dimatikan di menu grid → Baris Angka). Semua tombol huruf menampilkan angka/simbol kecil di pojok kanan atas, koma/titik/spasi menampilkan ikon mikrofon, "!?" dan globe. Hint itu hanya tampilan; agar bisa diketik dengan tekan-tahan, nyalakan menu grid → Tahan huruf.

## v46: tombol huruf lebih besar
Tinggi tombol bawaan 44/50/58 → 48/56/64 dp, jarak antar tombol dan margin samping dikurangi (tombol lebih lebar), huruf diperbesar (18 → 22). Semua masih bisa diatur lewat slider di app atau menu grid → Ukuran tombol.

## v47: bar saran kata dihapus
Kotak saran kata di atas tombol tidak ditampilkan lagi (sekaligus menghilangkan pekerjaan tambahan saat mengetik).

## v48: perbaikan bug tata letak
- Tombol spasi tidak lagi turun ke bawah di baris bawah (penyejajaran garis dasar teks dimatikan).
- Tombol "@" di layar simbol tidak lagi kosong.

## v54: tombol sembunyi bisa diatur + Fitur+ (4 kotak)
- Baris atas keyboard permanen kini punya dua tombol: ▾ = perkecil jadi ikon kecil (bisa digeser), ikon mata dicoret = sembunyikan jadi area tak terlihat yang baru muncul setelah diketuk 1x/2x/3x. Keduanya juga ada di menu 4 kotak.
- Tampilan tombol saat diperkecil bisa diatur: bentuk (bulat, kotak bulat, kotak, pil), warna (12 pilihan cepat atau kode hex), opasitas, dan ukuran (terpisah untuk mode tersembunyi dan ikon kecil), plus pojok area ketuk dan jumlah ketukan. Bisa diatur dari app (Keyboard permanen) atau langsung dari keyboard (menu 4 kotak → "Atur tombol sembunyi"). Ada pratinjau langsung. Saat satu ketukan terhitung di mode tersembunyi, area berkedip sebentar.
- Ikon logo Windows (4 kotak berisi) di baris atas, dan tile "Fitur+" di menu, membuka 4 kotak fitur baru:
  - Kalkulator: + − × ÷ ( ), hasil langsung muncul, tombol Sisipkan memasukkan hasil ke kotak ketik.
  - Alat teks: HURUF BESAR, kecil, Awal Kata, Kalimat, balik teks, rapikan spasi, hapus baris kosong, jadi satu baris, urutkan baris, hapus duplikat, jadikan poin, hitung kata. Bisa dibatalkan lewat Pengeditan teks → Batal AI.
  - Tanggal & jam: tanggal, hari + tanggal, jam, besok, lusa, kemarin, 7/30 hari lagi, bulan ini, salam sesuai waktu.
  - Acak & sandi: sandi 8/12/16/24 karakter, PIN 4/6 angka, dadu, koin, angka 1-100, UUID, warna acak, lorem ipsum. Tidak ada yang disimpan.

## v55: animasi ala iOS di seluruh keyboard
- Gaya baru "iOS Spring (super smooth)" untuk tekan tombol: mengecil cepat lalu kembali dengan pegas lembut. Jadi bawaan, bersama "iOS (geser + pegas)" untuk pindah layar dan "iOS naik halus" untuk keyboard muncul (kurva iOS). Kalau sebelumnya kamu sudah memilih gaya animasi sendiri di app, pilihanmu tetap dipakai; ganti ke tiga gaya iOS itu di bagian Animasi.
- Semua tombol (baris atas, kotak menu, Fitur+, kalkulator, tombol pilihan) ikut efek tekan pegas, ikon kecil memantul lembut saat dilepas, dan kotak saran/pesan status bergeser halus saat muncul atau hilang.

## v56: perbaikan
- 4 fitur baru (Kalkulator, Alat teks, Tanggal & jam, Acak & sandi) kini ada di menu kotak (ikon paling kiri di baris atas), bukan di Fitur+ lagi; ikon logo Windows dihapus dari baris atas.
- Tombol perkecil (▾ / mata dicoret) kini mengikuti mode pilihanmu dan tidak lagi memaksa jadi ikon kecil. Tombol mata di sebelahnya hanya mengganti mode (ikon kecil <-> tersembunyi).
- Efek transisi tata letak (LayoutTransition) yang ditambahkan di v55 dihapus karena bisa mengganggu pengetikan.

## v57
- Tahan huruf (popup simbol/aksen) dinyalakan lagi sekali saat update, kalau sebelumnya termatikan lewat menu. Tile "Tahan huruf" di menu kini menampilkan status nyala/MATI.

## v62: Bahasa = pilihan beberapa bahasa
- Menu → Bahasa membuka 3 pertanyaan konfigurasi: (1) bahasa apa saja yang dipakai (21 pilihan, boleh lebih dari satu), (2) bahasa utama untuk mengetik dan suara ke teks, (3) bahasa tujuan terjemahan bawaan. Pertanyaan yang sama ada di Pengaturan → "Bahasa keyboard". Bisa diulang lewat "Atur ulang".
- Setelah dikonfigurasi, Menu → Bahasa menampilkan bahasa aktif; ketuk satu untuk memakainya. Menahan tombol spasi (tanpa geser) pindah ke bahasa aktif berikutnya, dan nama bahasa tampil di tombol spasi.
- Bahasa terpilih dipakai untuk suara ke teks, nama di tombol spasi, dan tujuan terjemahan. Tata letak huruf tetap QWERTY/tata letak yang dipilih.
- Pindah ke keyboard lain (sistem) dipindah ke tile terpisah "Ganti keyboard" di Menu.

## v61: fitur baru di Menu → Fitur+
- **Kalkulator ilmiah**: tombol "Ilmiah" membuka sin, cos, tan, ln, log, √, ^, !, π, e dan %, dengan pilihan DEG/RAD. Perkalian tersirat didukung (2π, 3(4+1)).
- **Rumus & simbol**: tab Matematika, Yunani, Kimia, Fisika, Himpunan. Pilih Pangkat atau Indeks lalu ketuk angka untuk mengetik x² atau H₂O.
- **Uang & terbilang**: ketik angka (tombol jt = juta, M = miliar), lalu sisipkan sebagai "Rp1.250.000", terbilang ("Satu juta dua ratus lima puluh ribu rupiah"), atau keduanya untuk kwitansi. Ada hitungan cepat tambah/kurangi persen (PPN, diskon, tip), harga sebelum PPN, dan bagi rata tagihan; ketuk hasil untuk memasukkannya.
- **Konverter satuan**: panjang, massa, suhu, waktu, kecepatan, luas, volume, tekanan, energi, data; hasil bisa disisipkan.
- **Sandi & enkode**: Morse, Base64, biner, hex, ROT13, Caesar (geseran bisa dipilih), huruf↔angka (A1Z26), angka↔Romawi, URL, dan balik teks, dua arah. Bekerja pada teks terpilih atau teks sebelum kursor dan bisa dibatalkan lewat Pengeditan teks → Batal AI.
- Warna sorotan popup tahan huruf bisa diatur di Pengaturan → Font & warna, dan ada saklar "Tahan huruf" di sana.

## v63: Bahasa mengganti seluruh tampilan + keyboard sesuai negara
- **Seluruh teks keyboard dan app berganti** ke bahasa utama yang dipilih (Menu → Bahasa, atau Pengaturan → Bahasa keyboard). Terjemahan dibuat sekali lewat Groq (API key milikmu), disimpan di HP per bahasa, lalu dipakai offline. Progres tampil di halaman Bahasa. Teks buatanmu (clipboard, ketikan) tidak pernah diterjemahkan atau dikirim. Daftar teks yang diterjemahkan: `assets/i18n_keys.txt`.
- **Tata letak huruf mengikuti negara** (Pengaturan → Tata letak keyboard → "Ikuti bahasa", jadi bawaan): Indonesia/Inggris/Melayu/Jawa/Sunda/Filipino/Vietnam/Italia/Belanda QWERTY; Prancis AZERTY; Jerman QWERTZ + ü ö ä; Spanyol QWERTY + ñ; Portugis QWERTY + ç; Turki Q (ı ğ ü ş i ö ç, huruf besar İ/I benar); Rusia JCUKEN; Arab standar 101 + shift harakat; Thai Kedmanee + shift; Hindi Inscript + shift; Korea dubeolsik dengan penyusunan suku kata Hangul (shift = ㅃㅉㄸㄲㅆㅒㅖ); Jepang kana 12 tombol (ketuk berulang, tombol ゛゜小); Mandarin QWERTY pinyin dengan tanda baca ，。.
- Tanda baca bawah (koma/titik) mengikuti bahasa; huruf besar otomatis mati untuk aksara tanpa huruf besar.
- Batasan: konversi pinyin → hanzi dan kana → kanji belum ada; Vietnam memakai tahan-huruf untuk aksen (belum Telex); tombol ligatur لا di Arab diketik ل lalu ا.

## v64: warna tekan bisa diganti di semua tema
Pengaturan → Font & warna → "Warna tombol saat ditekan": isi kode hex atau ketuk pilihan cepat. Mengganti warna biru saat tombol ditekan (dan gelembung huruf) di tema apa pun, tidak hanya tema Kustom. Kosongkan untuk kembali ke warna tema.

## v68: perbaikan label tombol
Label tombol yang panjang ("?123", "◂ Bahasa ▸") tidak lagi pecah ke baris kedua dan terpotong; hurufnya mengecil otomatis sampai muat.

## v69: Tanya AI & Baca layar lebih manusiawi
- Jawaban Tanya AI, Baca layar, dan halaman AI kini ditulis seperti orang chat biasa: bahasa sehari-hari, tanpa "Tentu!", "Semoga membantu", "sebagai AI", tanpa markdown. Aturannya ada di `AiStyle` (AiClient.kt), mudah diubah.
- Soal pilihan ganda dipahami lebih baik: Baca layar menggabungkan huruf pilihan dengan isinya ("A. ..."), menandai pilihan yang sudah dipilih (•), tidak lagi membuang label A/B/C yang berulang, dan AI menjawab "B. isi pilihan" + alasan singkat. Beberapa soal dijawab per nomor.
- Tanya AI ingat pertanyaan sebelumnya: pertanyaan lanjutan ("kenapa?", "yang tadi diringkas dong") nyambung selama jawaban belum ditutup (✕).
- Batas jawaban dinaikkan supaya soal banyak tidak terpotong.

## v70: fitur AI tanpa harus memilih teks
- Tanpa teks terpilih, fitur AI (Perbaiki, Formal, Santai, dll) kini memproses seluruh isi kolom ketik, sebelum dan sesudah kursor (dulu hanya sebelum kursor), dan hasilnya menggantikan isi kolom. Kursor boleh di mana saja.
- Kolom kosong: keyboard membuka kotak ketik (seperti Tanya AI). Ketik teksnya di keyboard, tekan Kirim, hasilnya langsung masuk ke kolom ketik.
- Balas dan Jelaskan dengan kolom kosong membaca layar otomatis (butuh layanan aksesibilitas Romaboard) dan langsung menulis hasilnya di kolom ketik.
- Lanjutkan, Judul, Hashtag dan sejenisnya tetap memakai teks sebelum kursor.

## v71: Balas 3 gaya + perbaikan posisi keyboard
- Menu AI → **Balas 3 gaya**: membaca pesan yang masuk di layar (butuh layanan aksesibilitas Romaboard; tanpa itu, isi kolom ketik dianggap pesan yang diterima) lalu memberi 3 pilihan balasan: Singkat, Sopan, Santai. Ketuk satu untuk memasukkannya ke kolom ketik (Batal AI mengembalikan isi semula), atau Ulangi untuk pilihan baru. Kalau kolom ketik sudah berisi draf maksudmu, ketiga balasan menyampaikan maksud itu.
- (Perbaikan posisi keyboard di v71 digantikan oleh v72.)

## v72: keyboard tidak lagi muncul di atas layar
Penyebab sebenarnya: TrailView (jejak warna saat menggeser) tidak punya aturan ukuran, sehingga diukur setinggi layar dan jendela keyboard ikut melebar setinggi layar; tombolnya menempel di bagian atas jendela itu. TrailView kini melaporkan ukuran 0 kecuali induk memberi ukuran pasti. Jendela keyboard kembali setinggi isinya dan menempel di bawah.
