package com.byhas.aikeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.ln

interface SwipeListener {
    /** Dipanggil saat jari menyentuh papan; true = sentuhan dimulai di tombol huruf (boleh jadi swipe). */
    fun onTouchDown(rawX: Float, rawY: Float): Boolean
    fun onSwipeBegin()
    fun onSwipeMove(rawX: Float, rawY: Float)
    fun onSwipeEnd(cancelled: Boolean)
    fun slopPx(): Float
}

/** Wadah papan ketik yang mengenali geseran jari lintas tombol (Ketik Geser / Glide Typing). */
class SwipeLayout(ctx: Context) : LinearLayout(ctx) {
    var listener: SwipeListener? = null
    private var armed = false
    private var swiping = false
    private var sx = 0f
    private var sy = 0f

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        val l = listener ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { swiping = false; sx = e.rawX; sy = e.rawY; armed = l.onTouchDown(e.rawX, e.rawY) }
            MotionEvent.ACTION_POINTER_DOWN -> armed = false
            MotionEvent.ACTION_MOVE -> if (armed && !swiping && hypot(e.rawX - sx, e.rawY - sy) > l.slopPx()) {
                swiping = true; armed = false
                l.onSwipeBegin()
                l.onSwipeMove(sx, sy)
                l.onSwipeMove(e.rawX, e.rawY)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> armed = false
        }
        return false
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val l = listener
        if (!swiping || l == null) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                val ox = e.rawX - e.x
                val oy = e.rawY - e.y
                for (i in 0 until e.historySize) l.onSwipeMove(e.getHistoricalX(i) + ox, e.getHistoricalY(i) + oy)
                l.onSwipeMove(e.rawX, e.rawY)
            }
            MotionEvent.ACTION_UP -> { swiping = false; l.onSwipeEnd(false) }
            MotionEvent.ACTION_CANCEL -> { swiping = false; l.onSwipeEnd(true) }
        }
        return true
    }
}

/** Jejak warna di atas papan ketik selama menggeser. */
class TrailView(ctx: Context) : View(ctx) {
    private val xs = ArrayList<Float>()
    private val ys = ArrayList<Float>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).also {
        it.style = Paint.Style.STROKE
        it.strokeCap = Paint.Cap.ROUND
        it.strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val loc = IntArray(2)
    var color: Int = Color.parseColor("#2E7DFF")

    init { isClickable = false; isFocusable = false; alpha = 0f }

    // Tanpa ini View memakai ukuran bawaan = seluruh tinggi layar saat induknya WRAP_CONTENT,
    // sehingga jendela keyboard melebar setinggi layar dan tombol terdorong ke paling atas.
    // Kita lapor ukuran 0 kecuali induk memberi ukuran pasti (FrameLayout memberi ukuran pasti di pengukuran kedua).
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(widthMeasureSpec) else 0
        val h = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.EXACTLY) MeasureSpec.getSize(heightMeasureSpec) else 0
        setMeasuredDimension(w, h)
    }

    fun start() {
        animate().cancel()
        xs.clear(); ys.clear()
        paint.color = color
        paint.strokeWidth = 6f * resources.displayMetrics.density
        alpha = 1f
        invalidate()
    }

    fun add(x: Float, y: Float) { xs.add(x); ys.add(y); invalidate() }

    fun end() {
        animate().cancel()
        animate().alpha(0f).setDuration(260).withEndAction { xs.clear(); ys.clear() }.start()
    }

    override fun onDraw(c: Canvas) {
        if (xs.size < 2) return
        getLocationOnScreen(loc)
        path.reset()
        path.moveTo(xs[0] - loc[0], ys[0] - loc[1])
        for (i in 1 until xs.size) path.lineTo(xs[i] - loc[0], ys[i] - loc[1])
        c.drawPath(path, paint)
    }
}

/** Kamus kata bawaan (assets/words_xx.txt, urut dari yang paling umum). */
object SwipeDict {
    private val cache = HashMap<String, List<String>>()

    fun words(ctx: Context, lang: String): List<String> {
        val code = when {
            lang.startsWith("id") || lang.startsWith("ms") || lang.startsWith("jv") || lang.startsWith("su") -> "id"
            lang.startsWith("en") -> "en"
            else -> lang.substringBefore('-')
        }
        return cache.getOrPut(code) {
            try {
                ctx.assets.open("words_$code.txt").bufferedReader().readLines()
                    .map { it.trim().lowercase() }.filter { it.length >= 2 }
            } catch (e: Exception) { emptyList() }
        }
    }
}

/** Pencocokan jalur geser dengan kata (bentuk jalur + posisi tombol + urutan kata umum). */
object SwipeDecoder {
    class Pt(val x: Float, val y: Float)

    private const val N = 32

    private fun dist(a: Pt, b: Pt) = hypot(a.x - b.x, a.y - b.y)

    private fun length(p: List<Pt>): Float {
        var t = 0f
        for (i in 1 until p.size) t += dist(p[i - 1], p[i])
        return t
    }

    private fun resample(p: List<Pt>, n: Int): List<Pt> {
        val total = length(p)
        if (p.size < 2 || total < 1e-3f) return List(n) { p[0] }
        val cum = FloatArray(p.size)
        for (i in 1 until p.size) cum[i] = cum[i - 1] + dist(p[i - 1], p[i])
        val out = ArrayList<Pt>(n)
        var j = 1
        for (k in 0 until n) {
            val t = total * k / (n - 1)
            while (j < p.size - 1 && cum[j] < t) j++
            val seg = cum[j] - cum[j - 1]
            val f = if (seg < 1e-6f) 0f else ((t - cum[j - 1]) / seg).coerceIn(0f, 1f)
            out.add(Pt(p[j - 1].x + (p[j].x - p[j - 1].x) * f, p[j - 1].y + (p[j].y - p[j - 1].y) * f))
        }
        return out
    }

    fun decode(path: List<Pt>, keys: Map<Char, Pt>, keyW: Float, words: List<String>, learned: Map<String, Int>, max: Int): List<String> {
        if (path.size < 2 || keys.isEmpty() || keyW <= 0f) return emptyList()
        val pathLen = length(path)
        if (pathLen < keyW * 1.2f) return emptyList()
        val rp = resample(path, N)
        val first = path.first()
        val last = path.last()
        val rad = keyW * 1.7f
        val scored = ArrayList<Pair<String, Float>>()
        for ((rank, w) in words.withIndex()) {
            if (w.length < 2) continue
            val k0 = keys[w[0]] ?: continue
            if (dist(k0, first) > rad) continue
            val kl = keys[w[w.length - 1]] ?: continue
            if (dist(kl, last) > rad) continue
            val wp = ArrayList<Pt>()
            var prev = '\u0000'
            var ok = true
            for (ch in w) {
                if (ch == prev) continue
                val kp = keys[ch]
                if (kp == null) { ok = false; break }
                wp.add(kp); prev = ch
            }
            if (!ok || wp.size < 2) continue
            val rw = resample(wp, N)
            var s = 0f
            for (i in 0 until N) s += dist(rp[i], rw[i])
            var cost = s / N / keyW
            cost += 0.5f * abs(ln((pathLen + 1f) / (length(wp) + 1f)))
            cost += 0.12f * ln(1f + rank / 80f)
            val lf = learned[w]
            if (lf != null) cost -= 0.1f * ln(1f + lf)
            scored.add(Pair(w, cost))
        }
        return scored.sortedBy { it.second }.filter { it.second < 3.2f }.take(max).map { it.first }
    }
}
