package com.byhas.aikeyboard

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Region
import android.graphics.drawable.Drawable
import android.widget.TextView

/**
 * Ikon buatan sendiri (digambar dengan Canvas/Path pada kotak 24x24), menggantikan emoji.
 * Kalau [tv] diberi teks, ikon digambar di kiri teks dan keduanya dipusatkan bersama.
 */
class IconDrawable(
    private val kind: String,
    private val tint: Int,
    private val fixedPx: Float = 0f,
    private val tv: TextView? = null,
    private val gapPx: Float = 0f
) : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 2.2f
        color = tint
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = tint }

    private fun path(closed: Boolean, vararg v: Float): Path {
        val q = Path()
        q.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { q.lineTo(v[i], v[i + 1]); i += 2 }
        if (closed) q.close()
        return q
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val size = if (fixedPx > 0f) fixedPx else minOf(b.width(), b.height()) * 0.5f
        val text = tv?.text
        val textW = if (tv != null && !text.isNullOrEmpty()) tv.paint.measureText(text.toString()) else 0f
        val total = size + (if (textW > 0f) gapPx + textW else 0f)
        val x0 = b.exactCenterX() - total / 2f
        val y0 = b.exactCenterY() - size / 2f
        c.save()
        c.translate(x0, y0)
        val s = size / 24f
        c.scale(s, s)
        p.strokeWidth = 2.2f
        when (kind) {
            "pin" -> {
                c.drawPath(path(true, 9f, 3f, 15f, 3f, 14f, 9f, 17f, 13f, 7f, 13f, 10f, 9f), p)
                c.drawLine(12f, 13f, 12f, 21f, p)
            }
            "down" -> c.drawPath(path(false, 6f, 9f, 12f, 15f, 18f, 9f), p)
            "left" -> c.drawPath(path(false, 15f, 5f, 8f, 12f, 15f, 19f), p)
            "right" -> c.drawPath(path(false, 9f, 5f, 16f, 12f, 9f, 19f), p)
            "stop" -> c.drawRoundRect(RectF(6f, 6f, 18f, 18f), 2.5f, 2.5f, f)
            "sparkle" -> {
                val a = Path()
                a.moveTo(11f, 3f); a.quadTo(12f, 10f, 19f, 12f); a.quadTo(12f, 14f, 11f, 21f)
                a.quadTo(10f, 14f, 3f, 12f); a.quadTo(10f, 10f, 11f, 3f); a.close()
                c.drawPath(a, f)
                val d = Path()
                d.moveTo(19f, 2f); d.quadTo(19.5f, 4.5f, 22f, 5f); d.quadTo(19.5f, 5.5f, 19f, 8f)
                d.quadTo(18.5f, 5.5f, 16f, 5f); d.quadTo(18.5f, 4.5f, 19f, 2f); d.close()
                c.drawPath(d, f)
            }
            "smile" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawCircle(9f, 10f, 1.2f, f)
                c.drawCircle(15f, 10f, 1.2f, f)
                c.drawArc(RectF(7f, 7f, 17f, 17f), 30f, 120f, false, p)
            }
            "bolt" -> c.drawPath(path(true, 13f, 2f, 4f, 14f, 11f, 14f, 10f, 22f, 20f, 9f, 13f, 9f), f)
            "clip" -> {
                c.drawRoundRect(RectF(5f, 4f, 19f, 21f), 2.5f, 2.5f, p)
                c.drawRoundRect(RectF(9f, 2f, 15f, 6.5f), 1.5f, 1.5f, p)
                c.drawLine(8.5f, 11f, 15.5f, 11f, p)
                c.drawLine(8.5f, 15f, 13.5f, 15f, p)
            }
            "mic" -> {
                c.drawRoundRect(RectF(9f, 2.5f, 15f, 14f), 3f, 3f, p)
                c.drawArc(RectF(5f, 6f, 19f, 18f), 0f, 180f, false, p)
                c.drawLine(12f, 18f, 12f, 22f, p)
                c.drawLine(8.5f, 22f, 15.5f, 22f, p)
            }
            "swap" -> {
                c.drawLine(4f, 9f, 20f, 9f, p)
                c.drawPath(path(false, 16f, 5f, 20f, 9f, 16f, 13f), p)
                c.drawLine(20f, 15f, 4f, 15f, p)
                c.drawPath(path(false, 8f, 11f, 4f, 15f, 8f, 19f), p)
            }
            "gear" -> {
                c.drawCircle(12f, 12f, 3f, p)
                c.drawCircle(12f, 12f, 6.6f, p)
                p.strokeWidth = 3.4f
                for (k in 0 until 8) {
                    c.save(); c.rotate(k * 45f, 12f, 12f)
                    c.drawLine(12f, 2.8f, 12f, 5.2f, p)
                    c.restore()
                }
            }
            "globe" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawOval(RectF(8f, 3f, 16f, 21f), p)
                c.drawLine(3f, 12f, 21f, 12f, p)
                c.drawLine(4.6f, 7.2f, 19.4f, 7.2f, p)
                c.drawLine(4.6f, 16.8f, 19.4f, 16.8f, p)
            }
            "enter" -> {
                c.drawPath(path(false, 20f, 5f, 20f, 13f, 5f, 13f), p)
                c.drawPath(path(false, 9f, 9f, 5f, 13f, 9f, 17f), p)
            }
            "send" -> {
                c.drawPath(path(true, 3f, 11f, 21f, 3f, 14f, 21f, 11f, 14f), p)
                c.drawLine(11f, 14f, 21f, 3f, p)
            }
            "back" -> {
                c.drawPath(path(true, 9f, 5f, 21f, 5f, 21f, 19f, 9f, 19f, 2.5f, 12f), p)
                c.drawLine(13f, 9.5f, 18f, 14.5f, p)
                c.drawLine(18f, 9.5f, 13f, 14.5f, p)
            }
            "shift", "shift_on", "caps" -> {
                val bottom = if (kind == "caps") 17f else 20f
                val a = path(true, 12f, 3f, 21f, 12f, 16f, 12f, 16f, bottom, 8f, bottom, 8f, 12f, 3f, 12f)
                if (kind != "shift") c.drawPath(a, f)
                c.drawPath(a, p)
                if (kind == "caps") c.drawLine(8f, 21.5f, 16f, 21.5f, p)
            }
            "clock" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawPath(path(false, 12f, 7f, 12f, 12f, 16f, 14f), p)
            }
            "close" -> {
                c.drawLine(6f, 6f, 18f, 18f, p)
                c.drawLine(18f, 6f, 6f, 18f, p)
            }
            "insert" -> {
                c.drawLine(12f, 3f, 12f, 15f, p)
                c.drawPath(path(false, 7f, 10f, 12f, 15f, 17f, 10f), p)
                c.drawLine(5f, 20f, 19f, 20f, p)
            }
            "copy" -> {
                val front = RectF(10f, 9f, 20f, 21f)
                c.save()
                c.clipRect(front, Region.Op.DIFFERENCE)
                c.drawRoundRect(RectF(4f, 3f, 15f, 15f), 2f, 2f, p)
                c.restore()
                c.drawRoundRect(front, 2f, 2f, p)
            }
            "undo" -> {
                val a = Path()
                a.moveTo(4f, 10f); a.lineTo(14f, 10f); a.quadTo(20f, 10f, 20f, 15f)
                a.quadTo(20f, 20f, 14f, 20f); a.lineTo(8f, 20f)
                c.drawPath(a, p)
                c.drawPath(path(false, 8f, 6f, 4f, 10f, 8f, 14f), p)
            }
            "keyboard" -> {
                c.drawRoundRect(RectF(2f, 5.5f, 22f, 18.5f), 3f, 3f, p)
                for (x in listOf(6f, 10f, 14f, 18f)) c.drawCircle(x, 9.6f, 0.9f, f)
                for (x in listOf(8f, 12f, 16f)) c.drawCircle(x, 12.8f, 0.9f, f)
                c.drawLine(8f, 15.8f, 16f, 15.8f, p)
            }
            "read" -> {
                // bingkai pemindai di sudut + baris teks di tengah
                c.drawPath(path(false, 3f, 8f, 3f, 3f, 8f, 3f), p)
                c.drawPath(path(false, 16f, 3f, 21f, 3f, 21f, 8f), p)
                c.drawPath(path(false, 3f, 16f, 3f, 21f, 8f, 21f), p)
                c.drawPath(path(false, 16f, 21f, 21f, 21f, 21f, 16f), p)
                c.drawLine(7.5f, 9f, 16.5f, 9f, p)
                c.drawLine(7.5f, 12.5f, 16.5f, 12.5f, p)
                c.drawLine(7.5f, 16f, 13f, 16f, p)
            }
            "chat" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 16f), 3.5f, 3.5f, p)
                c.drawPath(path(false, 8f, 16f, 7f, 21f, 12.5f, 16f), p)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) { p.alpha = alpha; f.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf; f.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
