package com.byhas.aikeyboard

import android.content.Context
import android.graphics.Color

class KbTheme(val name: String, val bg: Int, val key: Int, val fn: Int, val text: Int, val accent: Int)

object Prefs {
    val themes = listOf(
        KbTheme("Gelap", Color.parseColor("#1E1E24"), Color.parseColor("#34343E"), Color.parseColor("#26262E"), Color.WHITE, Color.parseColor("#7C5CFF")),
        KbTheme("Terang", Color.parseColor("#E4E6EB"), Color.WHITE, Color.parseColor("#C9CCD3"), Color.parseColor("#111111"), Color.parseColor("#2E7DFF")),
        KbTheme("Samudra", Color.parseColor("#0B2239"), Color.parseColor("#17405F"), Color.parseColor("#10304A"), Color.WHITE, Color.parseColor("#27D3C3")),
        KbTheme("Sakura", Color.parseColor("#FBE4EC"), Color.WHITE, Color.parseColor("#F4C2D4"), Color.parseColor("#4A1F30"), Color.parseColor("#E94B83"))
    )
    private fun sp(c: Context) = c.getSharedPreferences("kb", Context.MODE_PRIVATE)
    fun clean(v: String): String = v.filter { !it.isWhitespace() && it.code in 33..126 }
    fun apiKey(c: Context): String = clean(sp(c).getString("apiKey", "") ?: "")
    fun ownKey(c: Context) = sp(c).getString("apiKey", "") ?: ""
    fun setKey(c: Context, v: String) = sp(c).edit().putString("apiKey", clean(v)).apply()
    fun model(c: Context) = sp(c).getString("model", "llama-3.1-8b-instant") ?: "llama-3.1-8b-instant"
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model", v).apply()
    fun theme(c: Context) = sp(c).getInt("theme", 0).coerceIn(0, themes.size - 1)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()
    fun lang(c: Context) = sp(c).getString("lang", "English") ?: "English"
    fun setLang(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()
    fun haptic(c: Context) = sp(c).getBoolean("haptic", true)
    fun setHaptic(c: Context, v: Boolean) = sp(c).edit().putBoolean("haptic", v).apply()
    fun numRow(c: Context) = sp(c).getBoolean("numRow", true)
    fun setNumRow(c: Context, v: Boolean) = sp(c).edit().putBoolean("numRow", v).apply()
    fun autoCap(c: Context) = sp(c).getBoolean("autoCap", true)
    fun setAutoCap(c: Context, v: Boolean) = sp(c).edit().putBoolean("autoCap", v).apply()
    fun dblSpace(c: Context) = sp(c).getBoolean("dblSpace", true)
    fun setDblSpace(c: Context, v: Boolean) = sp(c).edit().putBoolean("dblSpace", v).apply()
    fun snippets(c: Context) = sp(c).getString("snippets", "Terima kasih banyak \uD83D\uDE4F\nSiap, ditunggu ya\nMaaf baru balas, tadi sibuk\nAssalamualaikum") ?: ""
    fun setSnippets(c: Context, v: String) = sp(c).edit().putString("snippets", v).apply()
    fun custom(c: Context) = sp(c).getString("custom", "") ?: ""
    fun setCustom(c: Context, v: String) = sp(c).edit().putString("custom", v).apply()
    fun sound(c: Context) = sp(c).getBoolean("sound", false)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()
    fun suggest(c: Context) = sp(c).getBoolean("suggest", true)
    fun setSuggest(c: Context, v: Boolean) = sp(c).edit().putBoolean("suggest", v).apply()
    fun keySize(c: Context) = sp(c).getInt("keySize", 1).coerceIn(0, 2)
    fun setKeySize(c: Context, v: Int) = sp(c).edit().putInt("keySize", v).apply()
    fun keyHeightDp(c: Context) = listOf(44, 50, 58)[keySize(c)]
    fun hand(c: Context) = sp(c).getInt("hand", 0).coerceIn(0, 2)
    fun setHand(c: Context, v: Int) = sp(c).edit().putInt("hand", v).apply()
    fun recent(c: Context) = sp(c).getString("recent", "") ?: ""
    fun setRecent(c: Context, v: String) = sp(c).edit().putString("recent", v).apply()
    fun words(c: Context) = sp(c).getString("words", "") ?: ""
    fun setWords(c: Context, v: String) = sp(c).edit().putString("words", v).apply()
    fun voiceLang(c: Context) = sp(c).getString("voiceLang", "id-ID") ?: "id-ID"
    fun setVoiceLang(c: Context, v: String) = sp(c).edit().putString("voiceLang", v).apply()
}
