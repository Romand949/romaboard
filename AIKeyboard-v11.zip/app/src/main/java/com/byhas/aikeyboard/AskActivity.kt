package com.byhas.aikeyboard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.graphics.ColorUtils

/**
 * Halaman "Tanya AI": dibuka dari ikon AI di layar utama, keyboard langsung muncul,
 * ketik pertanyaan/perintah, AI menjawab, lalu Salin atau Bagikan.
 */
class AskActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var input: EditText
    private lateinit var sendBtn: Button
    private lateinit var asked: TextView
    private lateinit var result: TextView
    private lateinit var actions: LinearLayout
    private lateinit var kb: KbTheme
    private var busy = false
    private var lastAnswer = ""

    private fun round(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun pill(text: String, bg: Int, fg: Int): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(fg)
        b.background = round(bg, 22)
        b.minHeight = 0
        b.minimumHeight = dp(42)
        b.setPadding(dp(16), 0, dp(16), 0)
        return b
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
        )
        kb = Prefs.themes[Prefs.theme(this)]
        val dim = ColorUtils.setAlphaComponent(kb.text, 140)
        window.statusBarColor = kb.bg
        window.navigationBarColor = kb.bg
        if (android.os.Build.VERSION.SDK_INT >= 23 && ColorUtils.calculateLuminance(kb.bg) > 0.5) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(kb.bg)
        root.setPadding(dp(16), dp(12), dp(16), dp(12))

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Tanya AI"
        title.textSize = 20f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(kb.text)
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 22f
        gear.setTextColor(dim)
        gear.setPadding(dp(10), dp(4), dp(4), dp(4))
        gear.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        header.addView(gear)
        root.addView(header)

        // Area jawaban
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(12), 0, dp(8))
        asked = TextView(this)
        asked.textSize = 14f
        asked.setTypeface(null, Typeface.ITALIC)
        asked.setTextColor(dim)
        asked.visibility = View.GONE
        col.addView(asked)
        result = TextView(this)
        result.textSize = 17f
        result.setTextColor(dim)
        result.text = "Ketik pertanyaan atau perintah di bawah, misalnya:\n“buatkan balasan sopan menolak ajakan”"
        result.setTextIsSelectable(true)
        result.setLineSpacing(0f, 1.15f)
        result.setPadding(0, dp(6), 0, 0)
        col.addView(result)
        val sv = ScrollView(this)
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // Tombol Salin / Bagikan / Hapus
        actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.visibility = View.GONE
        val copy = pill("Salin", kb.accent, android.graphics.Color.WHITE)
        copy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("AI", lastAnswer))
            Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
        }
        val share = pill("Bagikan", kb.key, kb.text)
        share.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, lastAnswer)
            startActivity(Intent.createChooser(i, "Bagikan lewat"))
        }
        val clear = pill("Hapus", kb.fn, kb.text)
        clear.setOnClickListener {
            lastAnswer = ""
            asked.visibility = View.GONE
            result.setTextColor(dim)
            result.text = "Ketik pertanyaan atau perintah di bawah."
            actions.visibility = View.GONE
            input.requestFocus()
        }
        val lp = { LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) } }
        actions.addView(copy, lp())
        actions.addView(share, lp())
        actions.addView(clear, lp())
        root.addView(actions, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        // Kotak ketik + tombol kirim
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.BOTTOM
        input = EditText(this)
        input.hint = "Tanya atau minta AI…"
        input.setHintTextColor(dim)
        input.setTextColor(kb.text)
        input.textSize = 16f
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        input.maxLines = 5
        input.background = round(kb.key, 22)
        input.setPadding(dp(16), dp(10), dp(16), dp(10))
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        sendBtn = pill("Kirim", kb.accent, android.graphics.Color.WHITE)
        sendBtn.setOnClickListener { send() }
        row.addView(sendBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(44)).apply { leftMargin = dp(8) })
        root.addView(row)

        setContentView(root)

        // Fokus otomatis + keyboard langsung muncul
        input.requestFocus()
        input.postDelayed({
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }

    private fun send() {
        val q = input.text.toString().trim()
        if (q.isEmpty() || busy) return
        busy = true
        sendBtn.text = "…"
        actions.visibility = View.GONE
        asked.text = q
        asked.visibility = View.VISIBLE
        result.setTextColor(ColorUtils.setAlphaComponent(kb.text, 140))
        result.text = "Berpikir…"
        input.setText("")
        val system = "Kamu asisten AI yang ringkas dan membantu. Jawab langsung ke intinya, " +
            "tanpa pembuka basa-basi. Gunakan bahasa yang sama dengan pesan pengguna. " +
            "Jika diminta membuat pesan/balasan, tulis hanya isi pesannya agar siap disalin."
        AiClient.ask(Prefs.apiKey(this), Prefs.model(this), system, q, { out ->
            busy = false
            sendBtn.text = "Kirim"
            lastAnswer = out
            result.setTextColor(kb.text)
            result.text = out
            actions.visibility = View.VISIBLE
        }, { err ->
            busy = false
            sendBtn.text = "Kirim"
            lastAnswer = ""
            result.setTextColor(ColorUtils.setAlphaComponent(kb.text, 200))
            result.text = err
        })
    }
}
