# AI Keyboard

Keyboard Android buatan sendiri: QWERTY, simbol, emoji, riwayat clipboard, 4 tema, dan fitur AI (perbaiki, formal, santai, ringkas, terjemah, balas, lanjutkan, tanya AI) memakai Groq (gratis).

## Cara build (100% di GitHub)
1. Upload zip ini ke repo GitHub, lalu buat `.github/workflows/build.yml`.
2. Tab Actions > Build APK > Run workflow, download artifact `AIKeyboard-apk`.
3. Install APK. Tidak ada API key di dalam APK.

## Cara pakai
Buka app AI Keyboard, aktifkan dan pilih keyboard, lalu tempel API key Groq milikmu sendiri (gratis di console.groq.com/keys). Tiap pengguna memakai key sendiri.

## Ikon AI (Tanya AI)
Selain ikon AI Keyboard, ada ikon kedua bernama "AI" di layar utama. Ketuk, halaman Tanya AI terbuka dan keyboard langsung muncul. Ketik perintah, AI menjawab di halaman itu, lalu ketuk Salin atau Bagikan untuk menempel ke WhatsApp atau app lain. Memakai API key dan model yang sama dengan pengaturan.

## Fitur
- Keyboard: baris angka, shift/caps, huruf besar otomatis, spasi 2x = titik, simbol, emoji, 4 tema
- Clipboard: riwayat salinan + alat Semua/Salin/Potong/Tempel/geser kursor
- Teks cepat (⚡): kalimat favorit, diatur di app
- AI: Perbaiki, Formal, Santai, Lucu, Ringkas, Baku, Emoji-in, Terjemah, Tanya AI, Balas, Lanjutkan, Kustom (prompt buatan sendiri), dan tombol Batal untuk mengembalikan teks asli

## Update otomatis
Setiap build membuat Release baru di GitHub (repo harus Public). Saat app AI Keyboard dibuka, ia mengecek Release terbaru; jika ada versi baru muncul tombol "Update sekarang". Android tetap meminta kamu menekan Install. Kunci tanda tangan (app/aikeyboard.jks) harus selalu ikut di zip supaya update bisa menimpa versi lama.

## Kenyamanan mengetik
Tombol bereaksi saat disentuh (lebih cepat), warna berubah saat ditekan, tinggi tombol bisa kecil/sedang/besar, mode satu tangan (↔), tombol 🌐 ganti keyboard, shift dua kali = CAPS LOCK, saran kata yang belajar dari ketikanmu, emoji per kategori + terakhir dipakai, suara ketik opsional.

## Suara ke teks & gaya teks
Tombol 🎤 (di bawah dan di atas) mengetik dari suara; izin mikrofon diminta saat pertama kali. Panel "Aa" mengubah teks jadi gaya tebal, miring, skrip, gotik, bulat, kotak, terbalik, coret, dan lain-lain. Tab (ツ) di emoji berisi kaomoji.

## Animasi
Tombol mengecil lalu memantul saat disentuh dan warnanya memudar halus, panel berpindah dengan geser + fade, saran kata dan pesan status muncul memudar, pesan "memproses"/mendengarkan berdenyut, halaman pengaturan muncul memudar.
