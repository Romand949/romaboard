package com.byhas.aikeyboard

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection

class AiKeyboardService : InputMethodService() {
    companion object { @Volatile var instance: AiKeyboardService? = null }

    private lateinit var kb: KeyboardController
    private val h = Handler(Looper.getMainLooper())
    private var minimized = false
    @Volatile private var capturing = false

    private val permanent get() = Prefs.permanent(this)

    /** Paksa jendela keyboard menempel di bawah layar dengan tinggi sesuai isi (mencegah keyboard nyangkut di atas layar dengan area kosong di bawahnya). */
    private fun fixWindow() {
        try {
            val w = window?.window ?: return
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setGravity(Gravity.BOTTOM)
            w.decorView.requestLayout()
        } catch (_: Exception) {}
    }

    private fun swapView() {
        setInputView(kb.build())
        fixWindow()
        h.post { fixWindow() }
    }

    private val host = object : KeyboardController.Host {
        override val overlay get() = permanent
        override fun ic(): InputConnection? = currentInputConnection
        override fun editorAction() = sendDefaultEditorAction(true)
        override fun rebuild() { swapView() }
        override fun stopPermanent() { stopPermanentMode() }
        override val minimized get() = this@AiKeyboardService.minimized
        override fun collapse() { this@AiKeyboardService.minimized = true; swapView() }
        override fun restore() { this@AiKeyboardService.minimized = false; swapView() }
        override fun hideIme() { requestHideSelf(0) }
        override fun hideForCapture() { capturing = true; h.removeCallbacks(reshow); try { requestHideSelf(0) } catch (_: Exception) {} }
        override fun showAfterCapture() { capturing = false; try { requestShowSelf(0) } catch (_: Exception) {} }
        override fun startPermanentMode() { this@AiKeyboardService.startPermanentMode() }
    }

    // Saat mode permanen, jendela keyboard dianggap selalu perlu tampil (seperti keyboard biasa).
    override fun onEvaluateInputViewShown(): Boolean = permanent || super.onEvaluateInputViewShown()

    override fun onEvaluateFullscreenMode(): Boolean = false

    // Saat diperkecil jadi ikon: aplikasi di bawah tidak ikut menyempit dan hanya area ikon yang menerima sentuhan.
    override fun onComputeInsets(outInsets: InputMethodService.Insets) {
        super.onComputeInsets(outInsets)
        val ic = if (minimized && permanent) kb.miniIcon else null
        if (ic != null && ic.isAttachedToWindow) {
            val decorH = window?.window?.decorView?.height ?: return
            val loc = IntArray(2)
            ic.getLocationInWindow(loc)
            outInsets.contentTopInsets = decorH
            outInsets.visibleTopInsets = decorH
            outInsets.touchableInsets = InputMethodService.Insets.TOUCHABLE_INSETS_REGION
            outInsets.touchableRegion.set(loc[0], loc[1], loc[0] + ic.width, loc[1] + ic.height)
        }
    }

    private val reshow = Runnable {
        if (permanent && !capturing && !isInputViewShown) {
            try { requestShowSelf(0) } catch (_: Exception) {}
        }
    }

    private fun scheduleReshow() {
        h.removeCallbacks(reshow)
        if (permanent && !capturing) h.postDelayed(reshow, 250)
    }

    fun startPermanentMode() {
        Prefs.setPermanent(this, true)
        minimized = false
        swapView()
        try { requestShowSelf(0) } catch (_: Exception) {}
    }

    fun stopPermanentMode() {
        Prefs.setPermanent(this, false)
        minimized = false
        h.removeCallbacks(reshow)
        swapView()
        requestHideSelf(0)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        kb = KeyboardController(this, host)
        kb.create()
    }

    override fun onCreateInputView(): View = kb.build()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        kb.startInput()
        fixWindow()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        scheduleReshow()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        fixWindow()
        kb.playAppear()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        scheduleReshow()
    }

    override fun onFinishInput() {
        super.onFinishInput()
        kb.finishInput()
    }

    override fun onDestroy() {
        h.removeCallbacks(reshow)
        if (instance === this) instance = null
        kb.destroy()
        super.onDestroy()
    }
}
