package com.byhas.aikeyboard

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Region
import android.graphics.drawable.Drawable
import android.widget.TextView

/**
 * Ikon buatan sendiri (digambar dengan Canvas/Path pada kotak 24x24), menggantikan emoji.
 * Kalau [tv] diberi teks, ikon digambar di kiri teks dan keduanya dipusatkan bersama.
 */
class IconDrawable(
    private val kind: String,
    private val tint: Int,
    private val fixedPx: Float = 0f,
    private val tv: TextView? = null,
    private val gapPx: Float = 0f
) : Drawable() {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
        color = tint
    }
    private val f = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = tint }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = tint; textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun path(closed: Boolean, vararg v: Float): Path {
        val q = Path()
        q.moveTo(v[0], v[1])
        var i = 2
        while (i < v.size) { q.lineTo(v[i], v[i + 1]); i += 2 }
        if (closed) q.close()
        return q
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val size = if (fixedPx > 0f) fixedPx else minOf(b.width(), b.height()) * 0.5f
        val text = tv?.text
        val textW = if (tv != null && !text.isNullOrEmpty()) tv.paint.measureText(text.toString()) else 0f
        val total = size + (if (textW > 0f) gapPx + textW else 0f)
        val x0 = b.exactCenterX() - total / 2f
        val y0 = b.exactCenterY() - size / 2f
        c.save()
        c.translate(x0, y0)
        val s = size / 24f
        c.scale(s, s)
        p.strokeWidth = 1.9f
        if (kind.startsWith("t:")) {
            tp.textSize = 8f
            c.drawText(kind.substring(2), 12f, 14.8f, tp)
        }
        when (kind) {
            "pin" -> {
                c.drawPath(path(true, 9f, 3f, 15f, 3f, 14f, 9f, 17f, 13f, 7f, 13f, 10f, 9f), p)
                c.drawLine(12f, 13f, 12f, 21f, p)
            }
            "down" -> c.drawPath(path(false, 6f, 9f, 12f, 15f, 18f, 9f), p)
            "left" -> c.drawPath(path(false, 15f, 5f, 8f, 12f, 15f, 19f), p)
            "right" -> c.drawPath(path(false, 9f, 5f, 16f, 12f, 9f, 19f), p)
            "stop" -> c.drawRoundRect(RectF(6f, 6f, 18f, 18f), 2.5f, 2.5f, f)
            "sparkle" -> {
                val a = Path()
                a.moveTo(11f, 3f); a.quadTo(12f, 10f, 19f, 12f); a.quadTo(12f, 14f, 11f, 21f)
                a.quadTo(10f, 14f, 3f, 12f); a.quadTo(10f, 10f, 11f, 3f); a.close()
                c.drawPath(a, f)
                val d = Path()
                d.moveTo(19f, 2f); d.quadTo(19.5f, 4.5f, 22f, 5f); d.quadTo(19.5f, 5.5f, 19f, 8f)
                d.quadTo(18.5f, 5.5f, 16f, 5f); d.quadTo(18.5f, 4.5f, 19f, 2f); d.close()
                c.drawPath(d, f)
            }
            "smile" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawCircle(9f, 10f, 1.2f, f)
                c.drawCircle(15f, 10f, 1.2f, f)
                c.drawArc(RectF(7f, 7f, 17f, 17f), 30f, 120f, false, p)
            }
            "bolt" -> c.drawPath(path(true, 13f, 2f, 4f, 14f, 11f, 14f, 10f, 22f, 20f, 9f, 13f, 9f),p)
            "clip" -> {
                c.drawRoundRect(RectF(5f, 4f, 19f, 21f), 2.5f, 2.5f, p)
                c.drawRoundRect(RectF(9f, 2f, 15f, 6.5f), 1.5f, 1.5f, p)
                c.drawLine(8.5f, 11f, 15.5f, 11f, p)
                c.drawLine(8.5f, 15f, 13.5f, 15f, p)
            }
            "mic" -> {
                c.drawRoundRect(RectF(9f, 2.5f, 15f, 14f), 3f, 3f, p)
                c.drawArc(RectF(5f, 6f, 19f, 18f), 0f, 180f, false, p)
                c.drawLine(12f, 18f, 12f, 22f, p)
                c.drawLine(8.5f, 22f, 15.5f, 22f, p)
            }
            "swap" -> {
                c.drawLine(4f, 9f, 20f, 9f, p)
                c.drawPath(path(false, 16f, 5f, 20f, 9f, 16f, 13f), p)
                c.drawLine(20f, 15f, 4f, 15f, p)
                c.drawPath(path(false, 8f, 11f, 4f, 15f, 8f, 19f), p)
            }
            "gear" -> {
                val g = Path()
                for (k in 0 until 8) {
                    val a0 = k * 45.0
                    val pts = listOf(Pair(a0 - 15.0, 6.6), Pair(a0 - 9.0, 9.2), Pair(a0 + 9.0, 9.2), Pair(a0 + 15.0, 6.6))
                    for ((i, pt) in pts.withIndex()) {
                        val x = (12.0 + pt.second * Math.cos(Math.toRadians(pt.first))).toFloat()
                        val y = (12.0 + pt.second * Math.sin(Math.toRadians(pt.first))).toFloat()
                        if (k == 0 && i == 0) g.moveTo(x, y) else g.lineTo(x, y)
                    }
                }
                g.close()
                c.drawPath(g, p)
                c.drawCircle(12f, 12f, 3f, p)
            }
            "globe" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawOval(RectF(8f, 3f, 16f, 21f), p)
                c.drawLine(3f, 12f, 21f, 12f, p)
                c.drawLine(4.6f, 7.2f, 19.4f, 7.2f, p)
                c.drawLine(4.6f, 16.8f, 19.4f, 16.8f, p)
            }
            "enter" -> {
                c.drawPath(path(false, 20f, 5f, 20f, 13f, 5f, 13f), p)
                c.drawPath(path(false, 9f, 9f, 5f, 13f, 9f, 17f), p)
            }
            "send" -> {
                c.drawPath(path(true, 3f, 11f, 21f, 3f, 14f, 21f, 11f, 14f), p)
                c.drawLine(11f, 14f, 21f, 3f, p)
            }
            "back" -> {
                c.drawPath(path(true, 9f, 5f, 21f, 5f, 21f, 19f, 9f, 19f, 2.5f, 12f), p)
                c.drawLine(13f, 9.5f, 18f, 14.5f, p)
                c.drawLine(18f, 9.5f, 13f, 14.5f, p)
            }
            "shift", "shift_on", "caps" -> {
                val bottom = if (kind == "caps") 17f else 20f
                val a = path(true, 12f, 3f, 21f, 12f, 16f, 12f, 16f, bottom, 8f, bottom, 8f, 12f, 3f, 12f)
                if (kind != "shift") c.drawPath(a, f)
                c.drawPath(a, p)
                if (kind == "caps") c.drawLine(8f, 21.5f, 16f, 21.5f, p)
            }
            "clock" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawPath(path(false, 12f, 7f, 12f, 12f, 16f, 14f), p)
            }
            "close" -> {
                c.drawLine(6f, 6f, 18f, 18f, p)
                c.drawLine(18f, 6f, 6f, 18f, p)
            }
            "insert" -> {
                c.drawLine(12f, 3f, 12f, 15f, p)
                c.drawPath(path(false, 7f, 10f, 12f, 15f, 17f, 10f), p)
                c.drawLine(5f, 20f, 19f, 20f, p)
            }
            "copy" -> {
                val front = RectF(10f, 9f, 20f, 21f)
                c.save()
                c.clipRect(front, Region.Op.DIFFERENCE)
                c.drawRoundRect(RectF(4f, 3f, 15f, 15f), 2f, 2f, p)
                c.restore()
                c.drawRoundRect(front, 2f, 2f, p)
            }
            "undo" -> {
                val a = Path()
                a.moveTo(4f, 10f); a.lineTo(14f, 10f); a.quadTo(20f, 10f, 20f, 15f)
                a.quadTo(20f, 20f, 14f, 20f); a.lineTo(8f, 20f)
                c.drawPath(a, p)
                c.drawPath(path(false, 8f, 6f, 4f, 10f, 8f, 14f), p)
            }
            "keyboard" -> {
                c.drawRoundRect(RectF(2f, 5.5f, 22f, 18.5f), 3f, 3f, p)
                for (x in listOf(6f, 10f, 14f, 18f)) c.drawCircle(x, 9.6f, 0.9f, f)
                for (x in listOf(8f, 12f, 16f)) c.drawCircle(x, 12.8f, 0.9f, f)
                c.drawLine(8f, 15.8f, 16f, 15.8f, p)
            }
            "read" -> {
                // bingkai pemindai di sudut + baris teks di tengah
                c.drawPath(path(false, 3f, 8f, 3f, 3f, 8f, 3f), p)
                c.drawPath(path(false, 16f, 3f, 21f, 3f, 21f, 8f), p)
                c.drawPath(path(false, 3f, 16f, 3f, 21f, 8f, 21f), p)
                c.drawPath(path(false, 16f, 21f, 21f, 21f, 21f, 16f), p)
                c.drawLine(7.5f, 9f, 16.5f, 9f, p)
                c.drawLine(7.5f, 12.5f, 16.5f, 12.5f, p)
                c.drawLine(7.5f, 16f, 13f, 16f, p)
            }
            "grid" -> {
                for (r in listOf(RectF(4f, 4f, 10.5f, 10.5f), RectF(13.5f, 4f, 20f, 10.5f), RectF(4f, 13.5f, 10.5f, 20f), RectF(13.5f, 13.5f, 20f, 20f)))
                    c.drawRoundRect(r, 1.8f, 1.8f, p)
            }
            "win" -> {
                for (r in listOf(RectF(3.5f, 3.5f, 11.2f, 11.2f), RectF(12.8f, 3.5f, 20.5f, 11.2f), RectF(3.5f, 12.8f, 11.2f, 20.5f), RectF(12.8f, 12.8f, 20.5f, 20.5f)))
                    c.drawRoundRect(r, 1.2f, 1.2f, f)
            }
            "eye" -> {
                c.drawPath(path(true, 2.5f, 12f, 7f, 6.5f, 17f, 6.5f, 21.5f, 12f, 17f, 17.5f, 7f, 17.5f), p)
                c.drawCircle(12f, 12f, 3f, p)
            }
            "eyeoff" -> {
                c.drawPath(path(true, 2.5f, 12f, 7f, 6.5f, 17f, 6.5f, 21.5f, 12f, 17f, 17.5f, 7f, 17.5f), p)
                c.drawCircle(12f, 12f, 3f, p)
                c.drawLine(4f, 20f, 20f, 4f, p)
            }
            "calc" -> {
                c.drawRoundRect(RectF(5f, 3f, 19f, 21f), 2.5f, 2.5f, p)
                c.drawRoundRect(RectF(8f, 6f, 16f, 9.5f), 0.8f, 0.8f, f)
                for (yy in listOf(13f, 17f)) for (xx in listOf(8.5f, 12f, 15.5f)) c.drawCircle(xx, yy, 1f, f)
            }
            "clock" -> {
                c.drawCircle(12f, 12f, 9f, p)
                c.drawPath(path(false, 12f, 6.5f, 12f, 12f, 16f, 14f), p)
            }
            "calendar" -> {
                c.drawRoundRect(RectF(4f, 5f, 20f, 20f), 2.5f, 2.5f, p)
                c.drawLine(4f, 10f, 20f, 10f, p)
                c.drawLine(8.5f, 3f, 8.5f, 6.5f, p); c.drawLine(15.5f, 3f, 15.5f, 6.5f, p)
            }
            "dice" -> {
                c.drawRoundRect(RectF(4f, 4f, 20f, 20f), 3.5f, 3.5f, p)
                c.drawCircle(8.5f, 8.5f, 1.3f, f); c.drawCircle(12f, 12f, 1.3f, f); c.drawCircle(15.5f, 15.5f, 1.3f, f)
            }
            "key" -> {
                c.drawCircle(8f, 12f, 4f, p)
                c.drawLine(12f, 12f, 21f, 12f, p)
                c.drawLine(18f, 12f, 18f, 15.5f, p); c.drawLine(21f, 12f, 21f, 15f, p)
            }
            "textcase" -> {
                tp.textSize = 12f
                c.drawText("Aa", 12f, 16.5f, tp)
                c.drawLine(5f, 20f, 19f, 20f, p)
            }
            "palette" -> {
                c.drawOval(RectF(3f, 3.5f, 21f, 20.5f), p)
                c.drawCircle(8f, 10f, 1.3f, f); c.drawCircle(12f, 7.3f, 1.3f, f); c.drawCircle(16f, 10f, 1.3f, f)
                c.drawCircle(8.5f, 15f, 1.3f, f)
                c.drawCircle(15f, 15.5f, 2.2f, p)
            }
            "fonttile" -> {
                c.drawRoundRect(RectF(3f, 3f, 21f, 21f), 3f, 3f, p)
                c.drawLine(8f, 8f, 16f, 8f, p); c.drawLine(12f, 8f, 12f, 17f, p); c.drawLine(10f, 17f, 14f, 17f, p)
            }
            "cursor" -> {
                c.drawLine(12f, 5f, 12f, 19f, p); c.drawLine(9.5f, 5f, 14.5f, 5f, p); c.drawLine(9.5f, 19f, 14.5f, 19f, p)
                c.drawPath(path(false, 6f, 9f, 3f, 12f, 6f, 15f), p)
                c.drawPath(path(false, 18f, 9f, 21f, 12f, 18f, 15f), p)
            }
            "translate" -> {
                c.drawCircle(11.5f, 11f, 8f, p)
                c.drawPath(path(false, 6f, 17f, 4f, 21f, 10f, 19f), p)
                tp.textSize = 10f
                c.drawText("A", 11.5f, 14.5f, tp)
            }
            "numrow" -> {
                c.drawRoundRect(RectF(2.5f, 4f, 21.5f, 20f), 3f, 3f, p)
                tp.textSize = 8f
                c.drawText("123", 12f, 14.8f, tp)
            }
            "speaker" -> {
                c.drawPath(path(true, 4f, 9f, 8f, 9f, 13f, 5f, 13f, 19f, 8f, 15f, 4f, 15f), p)
                c.drawArc(RectF(11f, 8f, 19f, 16f), -50f, 100f, false, p)
                c.drawArc(RectF(9f, 5f, 22f, 19f), -50f, 100f, false, p)
            }
            "textsize" -> {
                tp.textSize = 16f
                c.drawText("A", 8.5f, 18f, tp)
                tp.textSize = 10f
                c.drawText("A", 18f, 18f, tp)
            }
            "at" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 20f), 4f, 4f, p)
                tp.textSize = 11f
                c.drawText("@", 12f, 15.5f, tp)
            }
            "up" -> c.drawPath(path(false, 5f, 15f, 12f, 8f, 19f, 15f), p)
            "arrowback" -> {
                c.drawLine(20f, 12f, 5f, 12f, p)
                c.drawPath(path(false, 11f, 6f, 5f, 12f, 11f, 18f), p)
            }
            "trash" -> {
                c.drawLine(4f, 7f, 20f, 7f, p)
                c.drawPath(path(false, 9f, 7f, 9f, 4f, 15f, 4f, 15f, 7f), p)
                c.drawPath(path(false, 6f, 7f, 7f, 20f, 17f, 20f, 18f, 7f), p)
                c.drawLine(10f, 11f, 10f, 16f, p); c.drawLine(14f, 11f, 14f, 16f, p)
            }
            "pencil" -> {
                c.drawPath(path(true, 4f, 20f, 5f, 15f, 16f, 4f, 20f, 8f, 9f, 19f), p)
                c.drawLine(13f, 7f, 17f, 11f, p)
            }
            "chat" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 16f), 3.5f, 3.5f, p)
                c.drawPath(path(false, 8f, 16f, 7f, 21f, 12.5f, 16f), p)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) { p.alpha = alpha; f.alpha = alpha; tp.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf; f.colorFilter = cf; tp.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Petunjuk kecil di pojok kanan atas tombol (angka/simbol, atau ikon bila diawali "@"). Hanya tampilan. */
class HintDrawable(
    private val text: String,
    private val tint: Int,
    private val sizePx: Float,
    private val padPx: Float,
    private val topPx: Float
) : Drawable() {
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tint; textAlign = Paint.Align.RIGHT; textSize = sizePx
    }
    override fun draw(c: Canvas) {
        val b = bounds
        // "@mic" = ikon; "@" sendirian adalah simbol biasa (hint huruf A)
        if (text.length > 1 && text[0] == '@' && text[1].isLetter()) {
            val ic = IconDrawable(text.substring(1), tint, sizePx * 1.15f)
            val s = (sizePx * 1.15f).toInt()
            val r = (b.right - padPx).toInt()
            val t = (b.top + topPx).toInt()
            ic.setBounds(r - s, t, r, t + s)
            ic.draw(c)
        } else {
            // garis bawah "_" tergambar di bawah garis dasar teks, jadi dinaikkan supaya terlihat (hint huruf F)
            val dy = if (text == "_") -sizePx * 0.28f else 0f
            c.drawText(text, b.right - padPx, b.top + topPx + sizePx * 0.85f + dy, tp)
        }
    }
    override fun setAlpha(alpha: Int) { tp.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { tp.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Bulatan pratinjau tema: latar tema + deretan tombol mini; bertanda centang kalau sedang dipakai. */
class ThemeDotDrawable(private val t: KbTheme, private val selected: Boolean) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas) {
        val b = bounds
        val w = b.width().toFloat(); val h = b.height().toFloat()
        val r = minOf(w, h) / 2f
        val cx = b.exactCenterX(); val cy = b.exactCenterY()
        val clip = Path(); clip.addCircle(cx, cy, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        p.color = t.bg
        c.drawCircle(cx, cy, r, p)
        p.color = t.key
        val kw = w * 0.2f; val kh = h * 0.17f; val gap = w * 0.05f
        val y0 = cy - h * 0.26f
        for (row in 0 until 3) {
            val n = 4
            val total = n * kw + (n - 1) * gap
            val x0 = cx - total / 2f + (if (row == 1) kw * 0.3f else 0f)
            for (k in 0 until n) {
                val l = x0 + k * (kw + gap)
                val tp = y0 + row * (kh + gap)
                c.drawRoundRect(RectF(l, tp, l + kw, tp + kh), kh * 0.3f, kh * 0.3f, p)
            }
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1f, w * 0.02f)
        p.color = Color.argb(90, 160, 160, 160)
        c.drawCircle(cx, cy, r - p.strokeWidth / 2f, p)
        if (selected) {
            p.style = Paint.Style.FILL
            p.color = Color.argb(235, 255, 255, 255)
            c.drawCircle(cx, cy, r * 0.42f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = r * 0.12f
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.color = Color.parseColor("#222222")
            val ck = Path()
            ck.moveTo(cx - r * 0.2f, cy + r * 0.0f)
            ck.lineTo(cx - r * 0.05f, cy + r * 0.16f)
            ck.lineTo(cx + r * 0.22f, cy - r * 0.15f)
            c.drawPath(ck, p)
        }
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
