package com.byhas.aikeyboard

import java.text.Normalizer
import java.util.Locale

/**
 * Tata letak keyboard asli per bahasa/negara.
 * rows = karakter baris 1..3 (tanpa baris angka); shift = lapisan shift (sama panjang per baris) untuk aksara tanpa huruf besar.
 * mode: 0 = huruf biasa, 1 = Hangul dubeolsik (disusun jadi suku kata), 2 = kana 12 tombol (Jepang).
 */
class LangKb(
    val rows: List<String>,
    val shift: List<String>? = null,
    val comma: String = ",",
    val period: String = ".",
    val mode: Int = 0,
    val hasCase: Boolean = true,
    val turkish: Boolean = false,
    val telex: Boolean = false
) {
    val shiftMap: Map<Char, String> = HashMap<Char, String>().also { m ->
        if (shift != null) for (i in rows.indices) {
            val a = rows[i]; val b = shift.getOrNull(i) ?: continue
            for (j in a.indices) if (j < b.length) m[a[j]] = b[j].toString()
        }
    }
}

object Layouts {
    private val qwerty = LangKb(listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"))

    private val table: Map<String, LangKb> = mapOf(
        // QWERTY asli negaranya (huruf sama dengan keyboard di sana; aksen lewat tahan huruf, lihat altsFor)
        "id-ID" to qwerty, "en-US" to qwerty, "ms-MY" to qwerty, "jv-ID" to qwerty, "su-ID" to qwerty,
        "nl-NL" to qwerty, "it-IT" to qwerty, "fil-PH" to qwerty,
        // Vietnam: QWERTY + pengetikan Telex (aa=â, aw=ă, dd=đ, s/f/r/x/j/z = tanda nada)
        "vi-VN" to LangKb(listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), telex = true),
        // Latin dengan tata letak khas negaranya
        "fr-FR" to LangKb(listOf("azertyuiop", "qsdfghjklm", "wxcvbn")),
        "de-DE" to LangKb(listOf("qwertzuiop\u00FC", "asdfghjkl\u00F6\u00E4", "yxcvbnm")),
        "es-ES" to LangKb(listOf("qwertyuiop", "asdfghjkl\u00F1", "zxcvbnm")),
        "pt-BR" to LangKb(listOf("qwertyuiop", "asdfghjkl\u00E7", "zxcvbnm")),
        "tr-TR" to LangKb(listOf("qwertyu\u0131op\u011F\u00FC", "asdfghjkl\u015Fi", "zxcvbnm\u00F6\u00E7"), turkish = true),
        // Kiril: JCUKEN
        "ru-RU" to LangKb(listOf("\u0439\u0446\u0443\u043A\u0435\u043D\u0433\u0448\u0449\u0437\u0445\u044A", "\u0444\u044B\u0432\u0430\u043F\u0440\u043E\u043B\u0434\u0436\u044D", "\u044F\u0447\u0441\u043C\u0438\u0442\u044C\u0431\u044E")),
        // Arab: standar 101 + lapisan shift (harakat)
        "ar-SA" to LangKb(
            listOf("\u0636\u0635\u062B\u0642\u0641\u063A\u0639\u0647\u062E\u062D\u062C\u062F", "\u0634\u0633\u064A\u0628\u0644\u0627\u062A\u0646\u0645\u0643\u0637", "\u0626\u0621\u0624\u0631\u0649\u0629\u0648\u0632\u0638"),
            listOf("\u064E\u064B\u064F\u064C\uFEF9\u0625\u2018\u00F7\u00D7\u061B<>", "\u0650\u064D][\uFEF7\u0623\u0640\u060C/:\"", "~\u0652}{\u0622\u2019,.\u061F"),
            comma = "\u060C", period = ".", hasCase = false),
        // Thai: Kedmanee + lapisan shift
        "th-TH" to LangKb(
            listOf("\u0E46\u0E44\u0E33\u0E1E\u0E30\u0E31\u0E35\u0E23\u0E19\u0E22\u0E1A\u0E25", "\u0E1F\u0E2B\u0E01\u0E14\u0E40\u0E49\u0E48\u0E32\u0E2A\u0E27\u0E07", "\u0E1C\u0E1B\u0E41\u0E2D\u0E34\u0E37\u0E17\u0E21\u0E43\u0E1D"),
            listOf("\u0E50\"\u0E0E\u0E11\u0E18\u0E4D\u0E4A\u0E13\u0E2F\u0E0D\u0E10,", "\u0E24\u0E06\u0E0F\u0E42\u0E0C\u0E47\u0E4B\u0E29\u0E28\u0E0B.", "()\u0E09\u0E2E\u0E3A\u0E4C?\u0E12\u0E2C\u0E26"),
            hasCase = false),
        // Hindi: Inscript + lapisan shift
        "hi-IN" to LangKb(
            listOf("\u094C\u0948\u093E\u0940\u0942\u092C\u0939\u0917\u0926\u091C\u0921\u093C", "\u094B\u0947\u094D\u093F\u0941\u092A\u0930\u0915\u0924\u091A\u091F", "\u0946\u0902\u092E\u0928\u0935\u0932\u0938\u092F"),
            listOf("\u0914\u0910\u0906\u0908\u090A\u092D\u0919\u0918\u0927\u091D\u0922\u091E", "\u0913\u090F\u0905\u0907\u0909\u092B\u0931\u0916\u0925\u091B\u0920", "\u090E\u0901\u0923\u0929\u0934\u0933\u0936\u095F"),
            period = "\u0964", hasCase = false),
        // Korea: dubeolsik (disusun jadi suku kata Hangul)
        "ko-KR" to LangKb(
            listOf("\u3142\u3148\u3137\u3131\u3145\u315B\u3155\u3151\u3150\u3154", "\u3141\u3134\u3147\u3139\u314E\u3157\u3153\u314F\u3163", "\u314B\u314C\u314A\u314D\u3160\u315C\u3161"),
            listOf("\u3143\u3149\u3138\u3132\u3146\u315B\u3155\u3151\u3152\u3156", "\u3141\u3134\u3147\u3139\u314E\u3157\u3153\u314F\u3163", "\u314B\u314C\u314A\u314D\u3160\u315C\u3161"),
            mode = 1, hasCase = false),
        // Jepang: kana 12 tombol
        "ja-JP" to LangKb(listOf("", "", ""), comma = "\u3001", period = "\u3002", mode = 2, hasCase = false),
        // Mandarin: QWERTY pinyin, tanda baca Tionghoa
        "zh-CN" to LangKb(listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), comma = "\uFF0C", period = "\u3002", hasCase = false)
    )

    fun forLang(code: String): LangKb = table[code] ?: qwerty

    fun upper(c: Char, kb: LangKb): String {
        if (kb.turkish) {
            if (c == 'i') return "\u0130"
            if (c == '\u0131') return "I"
            return c.toString().uppercase(Locale("tr"))
        }
        return c.uppercaseChar().toString()
    }

    /** Aksen tahan-huruf persis seperti keyboard negaranya. null = pakai daftar aksen umum. */
    fun altsFor(code: String, c: Char): String? = when (code) {
        "es-ES" -> when (c) { 'a' -> "\u00E1"; 'e' -> "\u00E9"; 'i' -> "\u00ED"; 'o' -> "\u00F3"; 'u' -> "\u00FA\u00FC"; 'n' -> "\u00F1"; else -> "" }
        "fr-FR" -> when (c) { 'a' -> "\u00E0\u00E2\u00E6"; 'e' -> "\u00E9\u00E8\u00EA\u00EB"; 'i' -> "\u00EE\u00EF"; 'o' -> "\u00F4\u0153"; 'u' -> "\u00F9\u00FB\u00FC"; 'c' -> "\u00E7"; 'y' -> "\u00FF"; else -> "" }
        "de-DE" -> when (c) { 's' -> "\u00DF"; 'e' -> "\u00E9\u00E8\u00EA"; 'a' -> "\u00E0\u00E1\u00E2"; 'o' -> "\u00F3\u00F2\u00F4"; 'u' -> "\u00FA\u00F9\u00FB"; 'i' -> "\u00ED\u00EC\u00EE"; else -> "" }
        "pt-BR" -> when (c) { 'a' -> "\u00E1\u00E0\u00E2\u00E3\u00E4"; 'e' -> "\u00E9\u00E8\u00EA\u00EB"; 'i' -> "\u00ED\u00EC\u00EE\u00EF"; 'o' -> "\u00F3\u00F2\u00F4\u00F5\u00F6"; 'u' -> "\u00FA\u00F9\u00FB\u00FC"; 'c' -> "\u00E7"; else -> "" }
        "it-IT" -> when (c) { 'a' -> "\u00E0\u00E1\u00E2"; 'e' -> "\u00E8\u00E9\u00EA\u00EB"; 'i' -> "\u00EC\u00ED\u00EE\u00EF"; 'o' -> "\u00F2\u00F3\u00F4\u00F6"; 'u' -> "\u00F9\u00FA\u00FB\u00FC"; else -> "" }
        "nl-NL" -> when (c) { 'a' -> "\u00E1\u00E0\u00E2\u00E4"; 'e' -> "\u00E9\u00E8\u00EA\u00EB"; 'i' -> "\u00ED\u00EC\u00EE\u00EF"; 'o' -> "\u00F3\u00F2\u00F4\u00F6"; 'u' -> "\u00FA\u00F9\u00FB\u00FC"; 'c' -> "\u00E7"; 'n' -> "\u00F1"; else -> "" }
        "tr-TR" -> when (c) { 'a' -> "\u00E2"; 'i' -> "\u00EE"; 'u' -> "\u00FB"; 'e' -> "\u00E9"; else -> "" }
        "fil-PH" -> when (c) { 'n' -> "\u00F1"; 'a' -> "\u00E1\u00E0\u00E2"; 'e' -> "\u00E9\u00E8\u00EA"; 'i' -> "\u00ED\u00EC\u00EE"; 'o' -> "\u00F3\u00F2\u00F4"; 'u' -> "\u00FA\u00F9\u00FB"; else -> "" }
        "jv-ID" -> when (c) { 'e' -> "\u00E9\u00E8\u00EA\u00EB"; 'a' -> "\u00E2"; 'o' -> "\u00F2\u00F4"; 'i' -> "\u00EE"; 'u' -> "\u00FB"; else -> "" }
        "su-ID" -> when (c) { 'e' -> "\u00E9\u00E8\u00EA\u00EB"; 'a' -> "\u00E2"; 'o' -> "\u00F2\u00F4"; 'i' -> "\u00EE"; 'u' -> "\u00FB"; else -> "" }
        "vi-VN" -> extraAlts(code, c) ?: ""
        "ms-MY" -> ""
        "id-ID" -> ""
        else -> null
    }

    /** Alternatif tahan-huruf khas bahasa (di luar daftar aksen umum). */
    fun extraAlts(code: String, c: Char): String? = when (code) {
        "ru-RU" -> if (c == '\u0435') "\u0451" else null
        "ar-SA" -> when (c) { '\u0627' -> "\u0623\u0625\u0622\u0621"; '\u064A' -> "\u0649\u0626"; '\u0648' -> "\u0624"; '\u0647' -> "\u0629"; else -> null }
        "vi-VN" -> when (c) {
            'a' -> "\u00E0\u00E1\u1EA3\u00E3\u1EA1\u0103\u1EB1\u1EAF\u1EB3\u1EB5\u1EB7\u00E2\u1EA7\u1EA5\u1EA9\u1EAB\u1EAD"
            'e' -> "\u00E8\u00E9\u1EBB\u1EBD\u1EB9\u00EA\u1EC1\u1EBF\u1EC3\u1EC5\u1EC7"
            'i' -> "\u00EC\u00ED\u1EC9\u0129\u1ECB"
            'o' -> "\u00F2\u00F3\u1ECF\u00F5\u1ECD\u00F4\u1ED3\u1ED1\u1ED5\u1ED7\u1ED9\u01A1\u1EDD\u1EDB\u1EDF\u1EE1\u1EE3"
            'u' -> "\u00F9\u00FA\u1EE7\u0169\u1EE5\u01B0\u1EEB\u1EE9\u1EED\u1EEF\u1EF1"
            'y' -> "\u1EF3\u00FD\u1EF7\u1EF9\u1EF5"
            'd' -> "\u0111"
            else -> null
        }
        else -> null
    }
}

/** Menyusun jamo Hangul (dubeolsik) menjadi suku kata. */
class HangulComposer {
    private val cho = "\u3131\u3132\u3134\u3137\u3138\u3139\u3141\u3142\u3143\u3145\u3146\u3147\u3148\u3149\u314A\u314B\u314C\u314D\u314E"
    private val jung = "\u314F\u3150\u3151\u3152\u3153\u3154\u3155\u3156\u3157\u3158\u3159\u315A\u315B\u315C\u315D\u315E\u315F\u3160\u3161\u3162\u3163"
    private val jong = arrayOf("", "\u3131", "\u3132", "\u3133", "\u3134", "\u3135", "\u3136", "\u3137", "\u3139", "\u313A", "\u313B", "\u313C", "\u313D", "\u313E", "\u313F", "\u3140", "\u3141", "\u3142", "\u3144", "\u3145", "\u3146", "\u3147", "\u3148", "\u314A", "\u314B", "\u314C", "\u314D", "\u314E")
    // gabungan batang akhir: [asli, tambahan, hasil]
    private val compJ = listOf("\u3131\u3145\u3133", "\u3134\u3148\u3135", "\u3134\u314E\u3136", "\u3139\u3131\u313A", "\u3139\u3141\u313B", "\u3139\u3142\u313C", "\u3139\u3145\u313D", "\u3139\u314C\u313E", "\u3139\u314D\u313F", "\u3139\u314E\u3140", "\u3142\u3145\u3144")
    private val compV = listOf("\u3157\u314F\u3158", "\u3157\u3150\u3159", "\u3157\u3163\u315A", "\u315C\u3153\u315D", "\u315C\u3154\u315E", "\u315C\u3163\u315F", "\u3161\u3163\u3162")

    private var c = -1
    private var v = -1
    private var f = 0

    fun active() = c >= 0 || v >= 0
    fun reset() { c = -1; v = -1; f = 0 }

    fun current(): String = when {
        c < 0 && v < 0 -> ""
        v < 0 -> cho[c].toString()
        c < 0 -> jung[v].toString()
        else -> (0xAC00 + (c * 21 + v) * 28 + f).toChar().toString()
    }

    private fun jongIdx(j: Char): Int = jong.indexOf(j.toString())

    /** Masukkan satu jamo. Hasil: (teks yang sudah selesai, teks yang masih disusun). */
    fun input(j: Char): Pair<String, String> {
        var done = ""
        val vi = jung.indexOf(j)
        if (vi >= 0) {
            if (v < 0) {
                v = vi
            } else if (f == 0) {
                val t = compV.firstOrNull { it[0] == jung[v] && it[1] == j }
                if (t != null) v = jung.indexOf(t[2]) else { done = current(); reset(); v = vi }
            } else {
                val fc = jong[f][0]
                val sp = compJ.firstOrNull { it[2] == fc }
                val newCho: Int
                if (sp != null) { f = jongIdx(sp[0]); newCho = cho.indexOf(sp[1]) } else { newCho = cho.indexOf(fc); f = 0 }
                done = current(); reset(); c = newCho; v = vi
            }
        } else {
            val ci = cho.indexOf(j)
            if (ci < 0) {
                done = current(); reset()
                return Pair(done + j, "")
            }
            if (c < 0 && v < 0) {
                c = ci
            } else if (c < 0 || v < 0) {
                done = current(); reset(); c = ci
            } else if (f == 0) {
                val ji = jongIdx(j)
                if (ji > 0) f = ji else { done = current(); reset(); c = ci }
            } else {
                val t = compJ.firstOrNull { it[0] == jong[f][0] && it[1] == j }
                if (t != null) f = jongIdx(t[2]) else { done = current(); reset(); c = ci }
            }
        }
        return Pair(done, current())
    }

    /** Hapus satu langkah dari susunan sekarang. */
    fun back() {
        if (f > 0) {
            val t = compJ.firstOrNull { it[2] == jong[f][0] }
            f = if (t != null) jongIdx(t[0]) else 0
        } else if (v >= 0) {
            val t = compV.firstOrNull { it[2] == jung[v] }
            v = if (t != null) jung.indexOf(t[0]) else -1
        } else {
            c = -1
        }
    }
}

/** Kana 12 tombol: ketuk berulang untuk huruf berikutnya. */
object Kana {
    val labels = listOf("\u3042", "\u304B", "\u3055", "\u305F", "\u306A", "\u306F", "\u307E", "\u3084", "\u3089", "\u308F", "\u3001\u3002?!")
    val sets = listOf(
        "\u3042\u3044\u3046\u3048\u304A", "\u304B\u304D\u304F\u3051\u3053", "\u3055\u3057\u3059\u305B\u305D", "\u305F\u3061\u3064\u3066\u3068",
        "\u306A\u306B\u306C\u306D\u306E", "\u306F\u3072\u3075\u3078\u307B", "\u307E\u307F\u3080\u3081\u3082", "\u3084\u3086\u3088",
        "\u3089\u308A\u308B\u308C\u308D", "\u308F\u3092\u3093\u30FC", "\u3001\u3002?!\u30FB"
    )
    // siklus tombol ゛゜小
    private val cycles = listOf(
        "\u304B\u304C", "\u304D\u304E", "\u304F\u3050", "\u3051\u3052", "\u3053\u3054", "\u3055\u3056", "\u3057\u3058", "\u3059\u305A", "\u305B\u305C", "\u305D\u305E",
        "\u305F\u3060", "\u3061\u3062", "\u3064\u3065\u3063", "\u3066\u3067", "\u3068\u3069",
        "\u306F\u3070\u3071", "\u3072\u3073\u3074", "\u3075\u3076\u3077", "\u3078\u3079\u307A", "\u307B\u307C\u307D",
        "\u3046\u3094\u3045", "\u3042\u3041", "\u3044\u3043", "\u3048\u3047", "\u304A\u3049", "\u3084\u3083", "\u3086\u3085", "\u3088\u3087", "\u308F\u308E"
    )
    fun next(c: Char): Char? {
        for (s in cycles) {
            val i = s.indexOf(c)
            if (i >= 0) return s[(i + 1) % s.length]
        }
        return null
    }
}

/** Pengetikan Telex Vietnam: kata di depan kursor + satu huruf baru -> kata pengganti (null = ketik biasa). */
object Telex {
    private const val NONE = '\u0000'
    private const val CIRC = '\u0302'
    private const val BREVE = '\u0306'
    private const val HORN = '\u031B'
    private val toneMarks = mapOf('s' to '\u0301', 'f' to '\u0300', 'r' to '\u0309', 'x' to '\u0303', 'j' to '\u0323')

    private class Ch(var b: Char, var up: Boolean, var mod: Char = NONE, var tone: Char = NONE, var stroke: Boolean = false)

    private fun parse(word: String): MutableList<Ch> {
        val out = ArrayList<Ch>()
        for (ch in word) {
            if (ch == '\u0111' || ch == '\u0110') { out.add(Ch('d', ch == '\u0110', stroke = true)); continue }
            val d = Normalizer.normalize(ch.toString(), Normalizer.Form.NFD)
            val base = d[0]
            val c = Ch(base.lowercaseChar(), base.isUpperCase())
            for (k in 1 until d.length) {
                val m = d[k]
                if (m == CIRC || m == BREVE || m == HORN) c.mod = m
                else if (toneMarks.containsValue(m)) c.tone = m
            }
            out.add(c)
        }
        return out
    }

    private fun isV(c: Ch) = !c.stroke && c.b in "aeiouy"

    private fun vowelIdx(w: List<Ch>): List<Int> {
        val r = ArrayList<Int>()
        for (i in w.indices) {
            val c = w[i]
            if (!isV(c)) continue
            if (i > 0 && c.b == 'u' && w[i - 1].b == 'q') continue
            if (i > 0 && c.b == 'i' && w[i - 1].b == 'g' && i + 1 < w.size && isV(w[i + 1])) continue
            r.add(i)
        }
        return r
    }

    /** Letak tanda nada pada gugus vokal terakhir (aturan umum ejaan Vietnam). */
    private fun toneIdx(w: List<Ch>): Int {
        val v = vowelIdx(w)
        if (v.isEmpty()) return -1
        var s = v.size - 1
        while (s > 0 && v[s - 1] == v[s] - 1) s--
        val cl = v.subList(s, v.size)
        val mods = cl.filter { w[it].mod != NONE }
        if (mods.isNotEmpty()) return mods.last()
        if (cl.size == 1) return cl[0]
        val finalCons = cl.last() < w.size - 1
        if (cl.size == 2) {
            if (finalCons) return cl[1]
            val pair = "" + w[cl[0]].b + w[cl[1]].b
            return if (pair == "oa" || pair == "oe" || pair == "uy") cl[1] else cl[0]
        }
        return cl[1]
    }

    private fun build(w: List<Ch>, tone: Char): String {
        val ti = if (tone != NONE) toneIdx(w) else -1
        val sb = StringBuilder()
        for ((i, c) in w.withIndex()) {
            if (c.stroke) { sb.append(if (c.up) '\u0110' else '\u0111'); continue }
            val base = if (c.up) c.b.uppercaseChar() else c.b
            var s = base.toString()
            if (c.mod != NONE) s += c.mod
            if (i == ti) s += tone
            sb.append(Normalizer.normalize(s, Normalizer.Form.NFC))
        }
        return sb.toString()
    }

    fun apply(word: String, key: Char): String? {
        val k = key.lowercaseChar()
        val w = parse(word)
        val tone = w.firstOrNull { it.tone != NONE }?.tone ?: NONE
        w.forEach { it.tone = NONE }
        val hasV = vowelIdx(w).isNotEmpty()
        val toneKey = toneMarks[k]
        if (toneKey != null) {
            if (!hasV) return null
            return if (tone == toneKey) build(w, NONE) + key else build(w, toneKey)
        }
        if (k == 'z') return if (tone == NONE) null else build(w, NONE)
        if (k == 'd') {
            val last = w.lastOrNull() ?: return null
            if (last.b != 'd') return null
            return if (!last.stroke) { last.stroke = true; build(w, tone) } else { last.stroke = false; build(w, tone) + key }
        }
        // vokal terakhir (boleh diikuti konsonan akhir)
        var i = w.size - 1
        while (i >= 0 && !isV(w[i])) i--
        if (k == 'a' || k == 'e' || k == 'o') {
            if (i < 0 || w[i].b != k) return null
            val c = w[i]
            return when (c.mod) {
                NONE -> { c.mod = CIRC; build(w, tone) }
                CIRC -> { c.mod = NONE; build(w, tone) + key }
                else -> null
            }
        }
        if (k == 'w') {
            if (i < 0) {
                if (w.any { isV(it) }) return null
                return build(w, tone) + (if (key.isUpperCase()) '\u01AF' else '\u01B0')
            }
            val c = w[i]
            val prev = if (i > 0) w[i - 1] else null
            when (c.b) {
                'a' -> {
                    if (prev != null && prev.b == 'u' && prev.mod == NONE && !(i > 1 && w[i - 2].b == 'q') && c.mod == NONE) {
                        prev.mod = HORN; return build(w, tone)
                    }
                    return when (c.mod) {
                        NONE -> { c.mod = BREVE; build(w, tone) }
                        BREVE -> { c.mod = NONE; build(w, tone) + key }
                        else -> null
                    }
                }
                'o' -> {
                    if (prev != null && prev.b == 'u' && (prev.mod == NONE || prev.mod == HORN) && !(i > 1 && w[i - 2].b == 'q') && (c.mod == NONE || c.mod == HORN)) {
                        return if (c.mod == HORN) { prev.mod = NONE; c.mod = NONE; build(w, tone) + key }
                        else { prev.mod = HORN; c.mod = HORN; build(w, tone) }
                    }
                    return when (c.mod) {
                        NONE -> { c.mod = HORN; build(w, tone) }
                        HORN -> { c.mod = NONE; build(w, tone) + key }
                        else -> null
                    }
                }
                'u' -> return when (c.mod) {
                    NONE -> { c.mod = HORN; build(w, tone) }
                    HORN -> { c.mod = NONE; build(w, tone) + key }
                    else -> null
                }
                else -> return null
            }
        }
        return null
    }
}
