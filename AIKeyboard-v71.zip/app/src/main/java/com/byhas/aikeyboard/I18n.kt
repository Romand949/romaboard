package com.byhas.aikeyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/**
 * Terjemahan seluruh teks antarmuka (keyboard + app).
 * Kunci = teks Indonesia di dalam kode (daftar lengkap di assets/i18n_keys.txt).
 * Bahasa antarmuka = bahasa utama yang dipilih di Menu -> Bahasa.
 * Terjemahan dibuat sekali lewat Groq (API key milik sendiri), disimpan di HP, lalu dipakai offline.
 * Teks buatan pengguna (clipboard, ketikan, dll) tidak pernah diterjemahkan atau dikirim.
 */
object I18n {
    private val main = Handler(Looper.getMainLooper())
    private var code = ""
    private val mem = HashMap<String, String>()
    private var keyCache: List<String>? = null
    private val listeners = ArrayList<() -> Unit>()

    @Volatile var running = false
    @Volatile var percent = 0
    @Volatile var error = ""

    fun addListener(l: () -> Unit) { if (!listeners.contains(l)) listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }
    private fun fire() { for (l in ArrayList(listeners)) try { l() } catch (e: Exception) { } }

    /** Kode bahasa antarmuka yang aktif. Belum dikonfigurasi = Indonesia (bahasa asli kode). */
    fun lang(c: Context): String = if (Prefs.langConfigured(c)) Prefs.voiceLang(c) else "id-ID"

    private fun file(c: Context, lc: String) = File(c.filesDir, "i18n_$lc.json")

    private fun ensure(c: Context, lc: String) {
        if (code == lc) return
        code = lc
        mem.clear()
        try {
            val f = file(c, lc)
            if (f.exists()) {
                val o = JSONObject(f.readText())
                val it = o.keys()
                while (it.hasNext()) { val k = it.next(); mem[k] = o.getString(k) }
            }
        } catch (e: Exception) { }
    }

    private fun decode(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                val n = s[i + 1]
                if (n == 'n') { sb.append('\n'); i += 2; continue }
                if (n == '\\') { sb.append('\\'); i += 2; continue }
            }
            sb.append(ch); i++
        }
        return sb.toString()
    }

    private fun keys(c: Context): List<String> {
        keyCache?.let { return it }
        val out = ArrayList<String>()
        try {
            c.applicationContext.assets.open("i18n_keys.txt").bufferedReader().useLines { seq ->
                for (line in seq) if (line.isNotEmpty()) out.add(decode(line))
            }
        } catch (e: Exception) { }
        keyCache = out
        return out
    }

    private fun exact(s: String): String? = mem[s] ?: mem["\n" + s]?.trimStart('\n')

    /** Terjemahkan satu teks. Kalau belum ada terjemahannya, kembalikan teks aslinya. */
    fun t(c: Context, s: String): String {
        if (s.length < 3) return s
        val lc = lang(c)
        if (lc == "id-ID") return s
        ensure(c, lc)
        if (mem.isEmpty()) return s
        exact(s)?.let { return it }
        // teks dinamis "Judul: nilai" atau beberapa baris: terjemahkan bagian judulnya saja
        if (s.indexOf('\n') >= 0) {
            val parts = s.split("\n")
            var changed = false
            val outp = parts.map { p -> val r = tLine(p); if (r != p) changed = true; r }
            return if (changed) outp.joinToString("\n") else s
        }
        return tLine(s)
    }

    private fun tLine(p: String): String {
        if (p.length < 3) return p
        exact(p)?.let { return it }
        val i = p.indexOf(": ")
        if (i in 2..48) {
            val head = p.substring(0, i + 2)
            val tr = exact(head)
            if (tr != null) return tr + p.substring(i + 2)
        }
        return p
    }

    /** Ganti semua teks tombol/label di dalam view (dan hint kolom ketik) ke bahasa aktif. */
    fun apply(c: Context, v: View?) {
        if (v == null) return
        if (lang(c) == "id-ID") return
        walk(c, v)
    }

    private fun walk(c: Context, v: View) {
        if (v is TextView) {
            if (v is EditText) {
                val h = v.hint?.toString()
                if (!h.isNullOrEmpty()) { val r = t(c, h); if (r != h) v.hint = r }
            } else {
                val tx = v.text?.toString()
                if (!tx.isNullOrEmpty()) { val r = t(c, tx); if (r != tx) v.text = r }
            }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(c, v.getChildAt(i))
    }

    fun ready(c: Context): Boolean {
        val lc = lang(c)
        if (lc == "id-ID") return true
        ensure(c, lc)
        return keys(c).all { mem.containsKey(it) }
    }

    fun statusText(c: Context): String {
        val lc = lang(c)
        if (lc == "id-ID") return ""
        if (running) return t(c, "Menerjemahkan antarmuka…") + " $percent%"
        if (error.isNotEmpty()) return t(c, "Terjemahan antarmuka terhenti: ") + error
        return if (ready(c)) "" else t(c, "Terjemahan antarmuka belum lengkap (butuh API key + internet).")
    }

    /** Mulai membuat terjemahan lengkap untuk bahasa aktif (berjalan di latar, hasil disimpan per bahasa). */
    fun prefetch(c: Context) {
        val app = c.applicationContext
        val lc = lang(app)
        error = ""
        if (lc == "id-ID" || running) return
        ensure(app, lc)
        val english = Prefs.langInfo(lc)?.english ?: return
        if (Prefs.keyList(app).isEmpty()) { error = "API key belum diisi"; fire(); return }
        val todo = keys(app).filter { !mem.containsKey(it) }
        if (todo.isEmpty()) { percent = 100; fire(); return }
        val total = todo.size
        val queue = ArrayDeque<List<String>>()
        for (ch in todo.chunked(22)) queue.addLast(ch)
        running = true
        percent = 0
        var retries = 0
        var chunksDone = 0
        fun save() {
            try {
                val o = JSONObject()
                for ((k, v) in mem) o.put(k, v)
                file(app, lc).writeText(o.toString())
            } catch (e: Exception) { }
        }
        fun finish(err: String) {
            running = false
            error = err
            if (err.isEmpty()) percent = 100
            save()
            fire()
        }
        fun step() {
            if (code != lc || lang(app) != lc) { running = false; return }   // bahasa diganti di tengah jalan
            val chunk = queue.removeFirstOrNull()
            if (chunk == null) { finish(""); return }
            val sys = "Translate the UI strings of an Android keyboard app from Indonesian into $english. " +
                "Each input line looks like 'number|text'. Reply with exactly one line per input line in the format 'number|translation'. " +
                "Keep the symbol ⏎, emoji, numbers, arrows and punctuation unchanged. Keep translations short and natural for buttons and labels. " +
                "Do not explain, do not add or skip lines."
            val user = chunk.mapIndexed { i, s -> "${i + 1}|" + s.replace("\n", "⏎") }.joinToString("\n")
            AiClient.askAuto(app, Prefs.model(app), sys, user, { out ->
                val got = HashMap<Int, String>()
                for (line in out.split("\n")) {
                    val b = line.indexOf('|')
                    if (b <= 0) continue
                    val n = line.substring(0, b).trim().toIntOrNull() ?: continue
                    val tx = line.substring(b + 1).trim().replace("⏎", "\n")
                    if (tx.isNotEmpty()) got[n] = tx
                }
                val missing = ArrayList<String>()
                for ((i, s) in chunk.withIndex()) {
                    val tx = got[i + 1]
                    if (tx == null) { missing.add(s); continue }
                    val lead = s.takeWhile { it == ' ' }
                    val trail = s.takeLastWhile { it == ' ' }
                    mem[s] = lead + tx.trim() + trail
                }
                if (missing.isNotEmpty()) {
                    if (missing.size == chunk.size) {
                        retries++
                        if (retries > 6) { finish("balasan AI tidak terbaca"); return@askAuto }
                    }
                    for (h in missing.chunked(maxOf(1, missing.size / 2)).asReversed()) queue.addFirst(h)
                }
                chunksDone++
                percent = (100 * (total - queue.sumOf { it.size }) / total).coerceIn(0, 99)
                save()
                if (chunksDone % 6 == 0) fire()
                main.postDelayed({ step() }, 1200)
            }, { msg ->
                retries++
                if (retries > 6) { finish(msg.take(80)); return@askAuto }
                queue.addFirst(chunk)
                main.postDelayed({ step() }, 15000)
            }, 2000)
        }
        step()
    }
}
