package com.byhas.aikeyboard

/** Kalkulator panel Fitur+: + − × ÷ ( ) %, plus mode ilmiah: ^ √ ! π e sin cos tan asin acos atan ln log abs. Mengembalikan null kalau ekspresi belum lengkap atau tidak valid. */
object Calc {
    /** true = sudut dalam derajat (DEG), false = radian (RAD). */
    @Volatile var deg = true

    fun eval(src: String): Double? {
        val s = src.replace('×', '*').replace('÷', '/').replace('−', '-').replace('x', '*').replace(" ", "").replace(',', '.')
        if (s.isEmpty()) return null
        return try {
            val p = Parser(s)
            val v = p.expr()
            if (p.i != s.length) null else if (v.isNaN() || v.isInfinite()) null else v
        } catch (e: Exception) { null }
    }

    fun fmt(d: Double): String {
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return java.math.BigDecimal(d).round(java.math.MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var i = 0
        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (true) {
                val c = peek()
                if (c == '*' || c == '/') {
                    i++
                    val r = factor()
                    v = if (c == '*') v * r else v / r
                } else if (c == 'π' || c == '(' || c == '√' || c in 'a'..'z') {
                    v *= factor()   // perkalian tersirat, mis. 2π atau 3(4+1)
                } else break
            }
            return v
        }

        private fun factor(): Double {
            if (peek() == '-') { i++; return -factor() }
            if (peek() == '+') { i++; return factor() }
            return power()
        }

        private fun power(): Double {
            val b = postfix()
            if (peek() == '^') { i++; return Math.pow(b, factor()) }
            return b
        }

        private fun postfix(): Double {
            var v = primary()
            while (true) {
                if (peek() == '%') { i++; v /= 100.0 }
                else if (peek() == '!') { i++; v = fact(v) }
                else break
            }
            return v
        }

        private fun fact(x: Double): Double {
            if (x < 0 || x != Math.rint(x) || x > 170) throw IllegalArgumentException("faktorial")
            var r = 1.0
            for (k in 2..x.toInt()) r *= k
            return r
        }

        private fun clean(v: Double): Double = Math.rint(v * 1e12) / 1e12

        private fun toRad(v: Double) = if (deg) Math.toRadians(v) else v
        private fun fromRad(v: Double) = if (deg) Math.toDegrees(v) else v

        private fun primary(): Double {
            val c = peek()
            if (c == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("kurung")
                i++
                return v
            }
            if (c == 'π') { i++; return Math.PI }
            if (c == '√') {
                i++
                val v = postfixNoBang()
                if (v < 0) throw IllegalArgumentException("akar")
                return Math.sqrt(v)
            }
            if (c in 'a'..'z') {
                val st = i
                while (peek() in 'a'..'z') i++
                val name = s.substring(st, i)
                if (name == "e" && peek() != '(') return Math.E
                if (peek() != '(') throw IllegalArgumentException("fungsi")
                i++
                val a = expr()
                if (peek() != ')') throw IllegalArgumentException("kurung")
                i++
                return when (name) {
                    "sin" -> clean(Math.sin(toRad(a)))
                    "cos" -> clean(Math.cos(toRad(a)))
                    "tan" -> clean(Math.tan(toRad(a)))
                    "asin" -> clean(fromRad(Math.asin(a)))
                    "acos" -> clean(fromRad(Math.acos(a)))
                    "atan" -> clean(fromRad(Math.atan(a)))
                    "ln" -> Math.log(a)
                    "log" -> clean(Math.log10(a))
                    "abs" -> Math.abs(a)
                    "sqrt" -> Math.sqrt(a)
                    else -> throw IllegalArgumentException("fungsi")
                }
            }
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            if (st == i) throw IllegalArgumentException("angka")
            return s.substring(st, i).toDouble()
        }

        /** Operan √ tanpa menelan "!" atau "^" supaya √9! tetap masuk akal. */
        private fun postfixNoBang(): Double = primary()
    }
}
