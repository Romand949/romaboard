package com.byhas.aikeyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class AiKeyboardService : InputMethodService() {
    private val main = Handler(Looper.getMainLooper())
    private lateinit var th: KbTheme
    private var themeIdx = -1
    private lateinit var body: LinearLayout
    private lateinit var status: TextView
    private var mode = "letters"
    private var shift = false
    private var caps = false
    private val clips = ArrayList<String>()

    private val emojis = listOf(
        "😀","😂","🤣","😊","😍","😘","😎","🤔","😭","😡","🥳","😴",
        "👍","👎","👏","🙏","💪","🔥","❤️","💔","✨","🎉","💯","✅",
        "😅","🙄","😬","🤗","🤭","😇","😜","🥺","😱","🤯","😢","😤",
        "🐶","🐱","🐼","🦁","🌹","🌞","🌙","⭐","🍕","🍔","☕","🍺",
        "⚽","🎮","🎵","📱","💻","🚗","✈️","🏠","💰","🎁","📷","🔒"
    )

    override fun onCreate() {
        super.onCreate()
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank()) { clips.remove(t); clips.add(0, t); if (clips.size > 30) clips.removeAt(30) }
        }
    }

    override fun onCreateInputView(): View = build()

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (themeIdx != Prefs.theme(this)) setInputView(build())
        mode = "letters"; shift = false; caps = false
        render()
        autoShift()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun build(): View {
        themeIdx = Prefs.theme(this)
        th = Prefs.themes[themeIdx]
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(th.bg)
        root.setPadding(dp(3), dp(3), dp(3), dp(6))

        val bar = row()
        bar.addView(btn("ABC", 1f, true) { mode = "letters"; render() })
        bar.addView(btn("✨ AI", 1.3f, true) { mode = "ai"; render() })
        bar.addView(btn("😀", 1f, true) { mode = "emoji"; render() })
        bar.addView(btn("⚡", 1f, true) { mode = "snip"; render() })
        bar.addView(btn("📋", 1f, true) { mode = "clip"; render() })
        bar.addView(btn("⚙", 1f, true) {
            val i = android.content.Intent(this, SettingsActivity::class.java)
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        root.addView(bar)

        status = TextView(this)
        status.setTextColor(th.accent)
        status.textSize = 12f
        status.setPadding(dp(8), 0, dp(8), 0)
        status.visibility = View.GONE
        root.addView(status)

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        root.addView(body)
        render()
        return root
    }

    private fun say(s: String?) {
        if (s == null) { status.visibility = View.GONE } else { status.text = s; status.visibility = View.VISIBLE }
    }

    private fun row(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun btn(label: String, w: Float = 1f, special: Boolean = false, size: Float = 18f, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.textSize = size
        t.setTextColor(th.text)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(8).toFloat()
        bg.setColor(if (special) th.fn else th.key)
        t.background = bg
        val lp = LinearLayout.LayoutParams(0, dp(46), w)
        lp.setMargins(dp(2), dp(3), dp(2), dp(3))
        t.layoutParams = lp
        t.setOnClickListener {
            if (Prefs.haptic(this)) t.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onClick()
        }
        return t
    }

    private fun backspace(w: Float): TextView {
        val t = btn("⌫", w, true) {}
        val rep = object : Runnable {
            override fun run() { del(); main.postDelayed(this, 60) }
        }
        t.setOnClickListener(null)
        t.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    if (Prefs.haptic(this)) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    del(); main.postDelayed(rep, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> main.removeCallbacks(rep)
            }
            true
        }
        return t
    }

    private fun del() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        if (!sendDefaultEditorAction(true)) {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        main.postDelayed({ autoShift() }, 60)
    }

    private fun spaceTap() {
        val ic = currentInputConnection ?: return
        val b = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (Prefs.dblSpace(this) && b.length == 2 && b[1] == ' ' && b[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
        } else ic.commitText(" ", 1)
        autoShift()
    }

    private fun autoShift() {
        if (!Prefs.autoCap(this) || mode != "letters" || caps) return
        val b = currentInputConnection?.getTextBeforeCursor(3, 0)?.toString() ?: ""
        val want = b.isEmpty() || b.endsWith(". ") || b.endsWith("! ") || b.endsWith("? ") || b.endsWith("\n")
        if (want != shift) { shift = want; render() }
    }

    private fun render() {
        body.removeAllViews()
        say(null)
        when (mode) {
            "letters" -> letters()
            "symbols" -> symbols()
            "emoji" -> emoji()
            "clip" -> clipboard()
            "snip" -> snippets()
            "ai" -> ai()
        }
    }

    private fun letters() {
        if (Prefs.numRow(this)) {
            val nr = row()
            for (c in "1234567890") nr.addView(btn(c.toString(), 1f, false, 15f) { type(c.toString()) })
            body.addView(nr)
        }
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        for ((i, r) in rows.withIndex()) {
            val row = row()
            if (i == 1) row.setPadding(dp(14), 0, dp(14), 0)
            if (i == 2) row.addView(btn(if (caps) "⇪" else "⇧", 1.5f, true) {
                if (shift) { shift = false; caps = false } else if (caps) { caps = false } else { shift = true }
                render()
            })
            for (c in r) {
                val ch = if (shift || caps) c.uppercaseChar().toString() else c.toString()
                row.addView(btn(ch) {
                    type(ch)
                    if (shift) { shift = false; render() }
                })
            }
            if (i == 2) row.addView(backspace(1.5f))
            body.addView(row)
        }
        val bottom = row()
        bottom.addView(btn("123", 1.4f, true) { mode = "symbols"; render() })
        bottom.addView(btn(",") { type(",") })
        bottom.addView(btn("space", 5f) { spaceTap() })
        bottom.addView(btn(".") { type(".") })
        bottom.addView(btn("⏎", 1.4f, true) { enter() })
        body.addView(bottom)
    }

    private fun symbols() {
        val rows = listOf("1234567890", "@#$%&-+()/", "*\"':;!?_=")
        for ((i, r) in rows.withIndex()) {
            val row = row()
            for (c in r) row.addView(btn(c.toString()) { type(c.toString()) })
            if (i == 2) row.addView(backspace(1.5f))
            body.addView(row)
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.4f, true) { mode = "letters"; render() })
        bottom.addView(btn(",") { type(",") })
        bottom.addView(btn("space", 5f) { spaceTap() })
        bottom.addView(btn(".") { type(".") })
        bottom.addView(btn("⏎", 1.4f, true) { enter() })
        body.addView(bottom)
    }

    private fun emoji() {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(190))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        emojis.chunked(8).forEach { chunk ->
            val r = row()
            chunk.forEach { e -> r.addView(btn(e) { type(e) }) }
            col.addView(r)
        }
        sv.addView(col)
        body.addView(sv)
        val bottom = row()
        bottom.addView(btn("ABC", 1.4f, true) { mode = "letters"; render() })
        bottom.addView(btn("space", 5f) { spaceTap() })
        bottom.addView(backspace(1.4f))
        body.addView(bottom)
    }

    private fun listPanel(items: List<String>, empty: String) {
        val sv = ScrollView(this)
        sv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        if (items.isEmpty()) {
            val t = TextView(this)
            t.text = empty
            t.setTextColor(th.text); t.setPadding(dp(12), dp(12), dp(12), dp(12))
            col.addView(t)
        }
        items.forEach { c ->
            val t = btn(if (c.length > 60) c.take(60) + "…" else c, 1f, false, 14f) { type(c) }
            t.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(42)).also {
                it.setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            t.setPadding(dp(10), 0, dp(10), 0)
            t.gravity = Gravity.CENTER_VERTICAL
            col.addView(t)
        }
        sv.addView(col)
        body.addView(sv)
    }

    private fun key(code: Int) {
        val ic = currentInputConnection ?: return
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun clipboard() {
        val tools = row()
        tools.addView(btn("◀", 1f, true, 14f) { key(KeyEvent.KEYCODE_DPAD_LEFT) })
        tools.addView(btn("▶", 1f, true, 14f) { key(KeyEvent.KEYCODE_DPAD_RIGHT) })
        tools.addView(btn("Semua", 1.4f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.selectAll) })
        tools.addView(btn("Salin", 1.2f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.copy) })
        tools.addView(btn("Potong", 1.3f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.cut) })
        tools.addView(btn("Tempel", 1.3f, true, 13f) { currentInputConnection?.performContextMenuAction(android.R.id.paste) })
        body.addView(tools)
        listPanel(clips, "Belum ada riwayat salinan. Salin teks, nanti muncul di sini.")
        val bottom = row()
        bottom.addView(btn("ABC", 1.4f, true) { mode = "letters"; render() })
        bottom.addView(btn("Hapus riwayat", 2f, true, 14f) { clips.clear(); render() })
        body.addView(bottom)
    }

    private fun snippets() {
        val list = Prefs.snippets(this).split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        listPanel(list, "Belum ada teks cepat. Isi di aplikasi AI Keyboard (satu baris = satu teks).")
        val bottom = row()
        bottom.addView(btn("ABC", 1.4f, true) { mode = "letters"; render() })
        bottom.addView(btn("space", 4f) { spaceTap() })
        bottom.addView(backspace(1.4f))
        body.addView(bottom)
    }

    private var undoOrig: String? = null
    private var undoOut: String? = null

    private fun undoAi() {
        val ic = currentInputConnection ?: return
        val o = undoOut; val orig = undoOrig
        if (o == null || orig == null) { say("Belum ada hasil AI untuk dibatalkan."); return }
        val before = ic.getTextBeforeCursor(o.length, 0)?.toString() ?: ""
        if (before != o) { say("Teks sudah berubah, tidak bisa dibatalkan."); return }
        ic.deleteSurroundingText(o.length, 0)
        ic.commitText(orig, 1)
        undoOut = null; undoOrig = null
        say("↩ Dibatalkan.")
    }

    private fun ai() {
        val lang = Prefs.lang(this)
        val items = listOf(
            Triple("Perbaiki", "Fix grammar, spelling and punctuation. Keep the same language and meaning. Output only the corrected text.", true),
            Triple("Formal", "Rewrite in a formal, polite tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Santai", "Rewrite in a casual, friendly, natural chat tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Lucu", "Rewrite in a funny, witty tone. Keep the same language. Output only the rewritten text.", true),
            Triple("Ringkas", "Make it shorter and clearer. Keep the same language. Output only the result.", true),
            Triple("Baku", "Rewrite in standard formal Indonesian with correct spelling (PUEBI). Output only the text.", true),
            Triple("Emoji-in", "Add fitting emojis to this text without changing the words. Output only the text.", true),
            Triple("Terjemah $lang", "Translate to $lang. Output only the translation.", true),
            Triple("Tanya AI", "Answer the question briefly and helpfully in the same language as the question. Output only the answer.", true),
            Triple("Balas", "The text is a message I received. Write a short, natural reply in the same language. Output only the reply.", false),
            Triple("Lanjutkan", "Continue writing this text naturally in the same language and style. Output only the continuation.", false),
            Triple("Kustom", "CUSTOM", true)
        )
        val hint = TextView(this)
        hint.text = "Ketik/pilih teks dulu, lalu tekan fitur."
        hint.setTextColor(th.text); hint.textSize = 12f
        hint.setPadding(dp(8), dp(2), dp(8), dp(2))
        body.addView(hint)
        items.chunked(3).forEach { tri ->
            val r = row()
            tri.forEach { (label, prompt, replace) ->
                r.addView(btn(label, 1f, false, 14f) {
                    if (prompt == "CUSTOM") {
                        val c = Prefs.custom(this)
                        if (c.isBlank()) say("Isi prompt kustom di aplikasi AI Keyboard.")
                        else runAi("$c Output only the result.", true)
                    } else runAi(prompt, replace)
                })
            }
            body.addView(r)
        }
        val bottom = row()
        bottom.addView(btn("ABC", 1.4f, true) { mode = "letters"; render() })
        bottom.addView(btn("↩ Batal", 1.6f, true, 14f) { undoAi() })
        bottom.addView(btn("space", 3f) { spaceTap() })
        bottom.addView(backspace(1.4f))
        body.addView(bottom)
    }

    private fun runAi(system: String, replace: Boolean) {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)?.toString() ?: ""
        val before = if (sel.isEmpty()) (ic.getTextBeforeCursor(1500, 0)?.toString() ?: "") else ""
        val src = if (sel.isNotEmpty()) sel else before
        if (src.isBlank()) { say("Ketik atau pilih teks dulu."); return }
        say("⏳ AI sedang memproses…")
        AiClient.ask(Prefs.apiKey(this), Prefs.model(this), system, src, { out ->
            val c = currentInputConnection
            if (c != null) {
                if (replace) {
                    if (sel.isEmpty()) c.deleteSurroundingText(before.length, 0)
                    c.commitText(out, 1)
                    undoOrig = src; undoOut = out
                } else {
                    val ins = (if (sel.isEmpty() && !before.endsWith(" ")) " " else "") + out
                    c.commitText(ins, 1)
                    undoOrig = ""; undoOut = ins
                }
            }
            say(null)
        }, { err -> say("⚠ $err") })
    }
}
