package com.byhas.aikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = if (bold) 18f else 14f
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(14), 0, dp(4))
        return v
    }

    private fun model0() = Prefs.model(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(24), dp(18), dp(24))

        col.addView(label("AI Keyboard", true))
        col.addView(label("1) Aktifkan keyboard, 2) pilih sebagai keyboard utama."))
        val b1 = Button(this); b1.text = "Aktifkan keyboard"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        col.addView(b1)
        val b2 = Button(this); b2.text = "Pilih keyboard"
        b2.setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        col.addView(b2)

        col.addView(label("3) Isi API key Groq milikmu sendiri (gratis, tiap orang pakai key sendiri)"))
        val getKey = Button(this); getKey.text = "Buka situs Groq untuk buat key"
        getKey.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://console.groq.com/keys"))) }
        col.addView(getKey)
        val key = EditText(this)
        key.setText(Prefs.ownKey(this)); key.setSingleLine(true)
        key.hint = "gsk_..."
        key.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(key)

        val test = Button(this); test.text = "Tes key"
        test.setOnClickListener {
            test.text = "Menguji…"
            AiClient.ask(key.text.toString().trim(), model0(), "Reply with OK.", "ping",
                { test.text = "Key berfungsi ✓" }, { e -> test.text = "Gagal: $e" })
        }
        col.addView(test)

        col.addView(label("Model AI"))
        val model = EditText(this)
        model.setText(Prefs.model(this)); model.setSingleLine(true)
        col.addView(model)
        col.addView(label("Cepat & limit besar: llama-3.1-8b-instant. Lebih pintar: llama-3.3-70b-versatile"))

        col.addView(label("Bahasa terjemahan"))
        val lang = EditText(this)
        lang.setText(Prefs.lang(this)); lang.setSingleLine(true)
        col.addView(lang)

        val hap = CheckBox(this); hap.text = "Getar saat mengetik"; hap.isChecked = Prefs.haptic(this)
        col.addView(hap)

        val numRow = CheckBox(this); numRow.text = "Baris angka di atas"; numRow.isChecked = Prefs.numRow(this)
        col.addView(numRow)
        val autoCap = CheckBox(this); autoCap.text = "Huruf besar otomatis di awal kalimat"; autoCap.isChecked = Prefs.autoCap(this)
        col.addView(autoCap)
        val dbl = CheckBox(this); dbl.text = "Spasi dua kali = titik"; dbl.isChecked = Prefs.dblSpace(this)
        col.addView(dbl)

        col.addView(label("Teks cepat ⚡ (satu baris = satu teks)"))
        val snip = EditText(this)
        snip.setText(Prefs.snippets(this)); snip.minLines = 3
        col.addView(snip)

        col.addView(label("Prompt kustom untuk tombol Kustom (contoh: Ubah jadi caption Instagram singkat)"))
        val custom = EditText(this)
        custom.setText(Prefs.custom(this)); custom.minLines = 2
        col.addView(custom)

        col.addView(label("Tema"))
        Prefs.themes.forEachIndexed { i, t ->
            val b = Button(this); b.text = t.name
            b.setOnClickListener { Prefs.setTheme(this, i); b.text = t.name + " ✓" }
            col.addView(b)
        }

        val save = Button(this); save.text = "Simpan"
        save.setOnClickListener {
            Prefs.setKey(this, key.text.toString().trim())
            Prefs.setModel(this, model.text.toString().trim().ifBlank { "llama-3.1-8b-instant" })
            Prefs.setLang(this, lang.text.toString().trim().ifBlank { "English" })
            Prefs.setHaptic(this, hap.isChecked)
            Prefs.setNumRow(this, numRow.isChecked)
            Prefs.setAutoCap(this, autoCap.isChecked)
            Prefs.setDblSpace(this, dbl.isChecked)
            Prefs.setSnippets(this, snip.text.toString())
            Prefs.setCustom(this, custom.text.toString().trim())
            save.text = "Tersimpan ✓"
        }
        col.addView(save)

        col.addView(label("Coba ketik di sini:"))
        col.addView(EditText(this))

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }
}
