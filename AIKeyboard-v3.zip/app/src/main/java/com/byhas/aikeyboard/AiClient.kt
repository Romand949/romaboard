package com.byhas.aikeyboard

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    private val main = Handler(Looper.getMainLooper())

    fun ask(key: String, model: String, system: String, user: String,
            onOk: (String) -> Unit, onErr: (String) -> Unit) {
        if (key.isBlank()) { onErr("API key kosong. Buka app AI Keyboard lalu isi API key."); return }
        Thread {
            try {
                val body = JSONObject().apply {
                    put("model", model)
                    put("temperature", 0.5)
                    put("max_tokens", 600)
                    put("messages", JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", system))
                        put(JSONObject().put("role", "user").put("content", user))
                    })
                }
                val con = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
                con.requestMethod = "POST"
                con.connectTimeout = 15000
                con.readTimeout = 30000
                con.doOutput = true
                con.setRequestProperty("Content-Type", "application/json")
                con.setRequestProperty("Authorization", "Bearer $key")
                con.outputStream.use { it.write(body.toString().toByteArray()) }
                val code = con.responseCode
                val stream = if (code in 200..299) con.inputStream else con.errorStream
                val text = stream?.bufferedReader()?.readText() ?: ""
                if (code in 200..299) {
                    val out = JSONObject(text).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content").trim()
                    main.post { onOk(out) }
                } else {
                    val msg = when (code) {
                        401 -> "API key salah"
                        429 -> "Limit habis, coba lagi sebentar"
                        else -> "Error $code"
                    }
                    main.post { onErr(msg) }
                }
            } catch (e: Exception) {
                main.post { onErr("Gagal koneksi: " + (e.message ?: "")) }
            }
        }.start()
    }
}
