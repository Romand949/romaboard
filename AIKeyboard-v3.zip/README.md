# AI Keyboard

Keyboard Android buatan sendiri: QWERTY, simbol, emoji, riwayat clipboard, 4 tema, dan fitur AI (perbaiki, formal, santai, ringkas, terjemah, balas, lanjutkan, tanya AI) memakai Groq (gratis).

## Cara build (100% di GitHub)
1. Upload zip ini ke repo GitHub, lalu buat `.github/workflows/build.yml`.
2. Tab Actions > Build APK > Run workflow, download artifact `AIKeyboard-apk`.
3. Install APK. Tidak ada API key di dalam APK.

## Cara pakai
Buka app AI Keyboard, aktifkan dan pilih keyboard, lalu tempel API key Groq milikmu sendiri (gratis di console.groq.com/keys). Tiap pengguna memakai key sendiri.

## Fitur
- Keyboard: baris angka, shift/caps, huruf besar otomatis, spasi 2x = titik, simbol, emoji, 4 tema
- Clipboard: riwayat salinan + alat Semua/Salin/Potong/Tempel/geser kursor
- Teks cepat (⚡): kalimat favorit, diatur di app
- AI: Perbaiki, Formal, Santai, Lucu, Ringkas, Baku, Emoji-in, Terjemah, Tanya AI, Balas, Lanjutkan, Kustom (prompt buatan sendiri), dan tombol Batal untuk mengembalikan teks asli
