package com.byhas.aikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.SeekBar
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable

class SettingsActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = if (bold) 18f else 14f
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(14), 0, dp(4))
        return v
    }

    private fun checkUpdate(info: TextView, btn: Button) {
        if (BuildConfig.REPO.isBlank()) { runOnUiThread { info.text = "Cek update nonaktif (repo tidak terdeteksi)"; info.visibility = android.view.View.VISIBLE }; return }
        Thread {
            try {
                val con = URL("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").openConnection() as HttpURLConnection
                con.connectTimeout = 10000
                con.readTimeout = 10000
                con.setRequestProperty("Accept", "application/vnd.github+json")
                con.setRequestProperty("User-Agent", "AIKeyboard/1.0 (Android)")
                if (con.responseCode != 200) {
                    val rc = con.responseCode
                    runOnUiThread { info.text = "Cek update gagal (kode $rc). Repo harus publik."; info.visibility = android.view.View.VISIBLE }
                } else {
                    val j = JSONObject(con.inputStream.bufferedReader().readText())
                    val n = j.getString("tag_name").filter { it.isDigit() }.toIntOrNull() ?: 0
                    val assets = j.getJSONArray("assets")
                    var url = ""
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
                    }
                    if (url.isEmpty() || n <= BuildConfig.VERSION_CODE) {
                        runOnUiThread { info.text = "Sudah versi terbaru (build ${BuildConfig.VERSION_CODE})"; info.visibility = android.view.View.VISIBLE }
                    }
                    if (url.isNotEmpty() && n > BuildConfig.VERSION_CODE) {
                        runOnUiThread {
                            info.text = "Versi baru tersedia (build $n). Versi kamu: build ${BuildConfig.VERSION_CODE}."
                            info.visibility = android.view.View.VISIBLE
                            btn.visibility = android.view.View.VISIBLE
                            btn.setOnClickListener { download(url, btn) }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { info.text = "Cek update gagal: " + (e.message ?: e.javaClass.simpleName).take(60); info.visibility = android.view.View.VISIBLE }
            }
        }.start()
    }

    private fun download(url: String, btn: Button) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Izinkan install dari aplikasi ini, lalu tekan Update lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        btn.isEnabled = false
        btn.text = "Mengunduh…"
        Thread {
            try {
                val f = File(cacheDir, "update.apk")
                val con = URL(url).openConnection() as HttpURLConnection
                con.connectTimeout = 15000
                con.readTimeout = 60000
                con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread {
                    btn.isEnabled = true
                    btn.text = "Update sekarang"
                    installApk(f)
                }
            } catch (e: Exception) {
                runOnUiThread { btn.isEnabled = true; btn.text = "Gagal, coba lagi" }
            }
        }.start()
    }

    private fun installApk(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun model0() = Prefs.model(this)

    private var preview: LinearLayout? = null
    private lateinit var permStatus: TextView
    private lateinit var permBtn: Button

    private fun slider(col: LinearLayout, title: String, unit: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val tv = label("")
        tv.textSize = 13f
        fun upd(v: Int) { tv.text = "$title: $v$unit" }
        upd(get())
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = get() - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                set(p + min); upd(p + min); updatePreview()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { PermanentService.instance?.refresh() }
        })
        col.addView(tv); col.addView(sb)
    }

    private var preview2: LinearLayout? = null

    private fun updatePreview() {
        preview?.let { fillPreview(it) }
        preview2?.let { fillPreview(it) }
    }

    private fun fillPreview(p: LinearLayout) {
        p.removeAllViews()
        val th = Prefs.currentTheme(this)
        p.setBackgroundColor(th.bg)
        p.setPadding(dp(Prefs.sidePad(this)), dp(Prefs.topPad(this)), dp(Prefs.sidePad(this)), dp(Prefs.bottomPad(this)))
        val row = LinearLayout(this)
        for ((i, l) in listOf("Q", "W", "E", "R", "⌫", "space").withIndex()) {
            val special = l == "⌫"
            val t = TextView(this)
            t.text = l
            t.gravity = android.view.Gravity.CENTER
            t.textSize = 18f * Prefs.fontScale(this) / 100f
            t.typeface = Prefs.typeface(this)
            t.setTextColor(th.text)
            val bg = GradientDrawable()
            bg.cornerRadius = dp(Prefs.radius(this)).toFloat()
            bg.setColor(if (special) th.fn else th.key)
            bg.alpha = Prefs.keyAlpha(this) * 255 / 100
            t.background = InsetDrawable(bg, dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)))
            val style = Prefs.animPress(this)
            if (style == KeyAnim.RIPPLE) t.background = KeyAnim.ripple(t.background, dp(Prefs.radius(this)).toFloat(), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), th.accent)
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> KeyAnim.press(v, true, style, Prefs.animSpeed(this) / 100f, e.x, e.y)
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> KeyAnim.press(v, false, style, Prefs.animSpeed(this) / 100f, e.x, e.y)
                }
                true
            }
            t.layoutParams = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), if (l == "space") 2.5f else 1f)
            row.addView(t)
        }
        p.addView(row)
    }

    private fun refreshPerm() {
        val run = Prefs.permanent(this)
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val active = cur.startsWith(packageName)
        permStatus.text = when {
            run && active -> "Status: keyboard permanen SEDANG MENYALA"
            run -> "Status: permanen aktif, tapi Romaboard belum dipilih sebagai keyboard"
            else -> "Status: keyboard permanen mati"
        }
        permBtn.text = if (run) "⏹ STOP keyboard permanen" else "▶ Mulai keyboard permanen"
    }

    override fun onResume() {
        super.onResume()
        if (::permStatus.isInitialized) refreshPerm()
    }

    override fun onPause() {
        super.onPause()
        PermanentService.instance?.refresh()
    }

    private val pickFont = 4711
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFont && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { i -> Prefs.customFontFile(this).outputStream().use { o -> i.copyTo(o) } }
                android.graphics.Typeface.createFromFile(Prefs.customFontFile(this)) // uji: lempar error kalau bukan font
                Prefs.setFontIdx(this, Prefs.fontNames.size - 1)
                Prefs.bumpFontRev(this)
                Toast.makeText(this, "Font dipakai ✓", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Prefs.customFontFile(this).delete()
                Toast.makeText(this, "File bukan font yang valid (.ttf / .otf)", Toast.LENGTH_LONG).show()
            }
            updatePreview()
            PermanentService.instance?.refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(24), dp(18), dp(24))

        col.addView(label("Romaboard", true))
        col.addView(label("Versi: ${BuildConfig.VERSION_NAME}"))
        val upInfo = TextView(this)
        upInfo.visibility = android.view.View.GONE
        val upBtn = Button(this); upBtn.text = "Update sekarang"
        upBtn.visibility = android.view.View.GONE
        val upCheck = Button(this); upCheck.text = "Cek update"
        upCheck.setOnClickListener {
            upInfo.text = "Memeriksa versi terbaru…"
            upInfo.visibility = android.view.View.VISIBLE
            upBtn.visibility = android.view.View.GONE
            upBtn.text = "Update sekarang"
            upBtn.isEnabled = true
            checkUpdate(upInfo, upBtn)
        }
        col.addView(upCheck)
        col.addView(upInfo)
        col.addView(upBtn)
        checkUpdate(upInfo, upBtn)
        col.addView(label("1) Aktifkan keyboard, 2) pilih sebagai keyboard utama."))
        val b1 = Button(this); b1.text = "Aktifkan keyboard"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        col.addView(b1)
        val b2 = Button(this); b2.text = "Pilih keyboard"
        b2.setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        col.addView(b2)

        col.addView(label("3) Isi API key Groq milikmu sendiri (gratis). Bisa lebih dari satu: kalau key aktif kena limit, keyboard otomatis pindah ke key berikutnya.", true))
        val getKey = Button(this); getKey.text = "Buka situs Groq untuk buat key"
        getKey.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://console.groq.com/keys"))) }
        col.addView(getKey)

        val keyBox = LinearLayout(this); keyBox.orientation = LinearLayout.VERTICAL
        col.addView(keyBox)
        fun mask(k: String) = if (k.length <= 8) "••••" else k.take(4) + "…" + k.takeLast(4)
        fun renderKeys() {
            keyBox.removeAllViews()
            val keys = Prefs.keyList(this)
            val act = Prefs.keyIdx(this)
            if (keys.isEmpty()) keyBox.addView(label("Belum ada API key. Tambahkan di bawah."))
            keys.forEachIndexed { i, k ->
                val head = label("Key #${i + 1}   ${mask(k)}  (${k.length} karakter)" + (if (i == act) "   ✓ AKTIF" else ""), i == act)
                keyBox.addView(head)
                val u = label(Prefs.usage(this, k) ?: "Belum ada data pemakaian. Tekan Tes untuk melihat sisa limit.")
                u.textSize = 12f
                keyBox.addView(u)
                val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL
                val bUse = Button(this); bUse.text = "Pakai"
                bUse.setOnClickListener { Prefs.setKeyIdx(this, i); renderKeys() }
                val bTest = Button(this); bTest.text = "Tes"
                bTest.setOnClickListener {
                    bTest.text = "Menguji…"
                    AiClient.ask(k, model0(), "Reply with OK.", "ping",
                        { renderKeys(); Toast.makeText(this, "Key #${i + 1} berfungsi ✓", Toast.LENGTH_SHORT).show() },
                        { e -> bTest.text = "Tes"; u.text = "Gagal: $e" }, this)
                }
                val bDel = Button(this); bDel.text = "Hapus"
                bDel.setOnClickListener { Prefs.removeKey(this, i); renderKeys() }
                for (b in listOf(bUse, bTest, bDel)) r.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                keyBox.addView(r)
            }
        }
        val newKey = EditText(this)
        newKey.setSingleLine(true)
        newKey.hint = "Tempel API key baru (gsk_...)"
        newKey.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(newKey)
        val addKey = Button(this); addKey.text = "➕ Tambah API key"
        addKey.setOnClickListener {
            val k = Prefs.clean(newKey.text.toString())
            if (k.isEmpty()) Toast.makeText(this, "Tempel API key dulu", Toast.LENGTH_SHORT).show()
            else if (!Prefs.addKey(this, k)) Toast.makeText(this, "Key itu sudah ada", Toast.LENGTH_SHORT).show()
            else {
                newKey.setText(""); renderKeys()
                val warn = if (!k.startsWith("gsk_") || k.length < 40) " Key Groq biasanya diawali gsk_ dan sekitar 56 karakter, key ini ${k.length} karakter, mungkin terpotong." else ""
                Toast.makeText(this, "Key ditambahkan, sedang diuji…", Toast.LENGTH_SHORT).show()
                AiClient.ask(k, model0(), "Reply with OK.", "ping",
                    { renderKeys(); Toast.makeText(this, "Key berfungsi ✓", Toast.LENGTH_SHORT).show() },
                    { e -> Toast.makeText(this, "Gagal: $e.$warn", Toast.LENGTH_LONG).show() }, this)
            }
        }
        col.addView(addKey)
        col.addView(label("Penting: menurut dokumentasi Groq, limit dihitung per akun/organisasi, bukan per key. Beberapa key dari akun yang sama TIDAK menambah jatah. Buat key dari akun Groq yang berbeda supaya pindah key benar-benar membantu. Keyboard otomatis pindah kalau key kena limit (429) atau salah (401)."))
        renderKeys()

        col.addView(label("Model AI (ketuk untuk memilih, atau ketik nama model sendiri)", true))
        val model = EditText(this)
        model.setText(Prefs.model(this)); model.setSingleLine(true)
        col.addView(model)
        val modelBox = LinearLayout(this); modelBox.orientation = LinearLayout.VERTICAL
        col.addView(modelBox)
        val infos = listOf(
            arrayOf("llama-3.1-8b-instant", "MODEL KECIL · paling cepat · jawaban sederhana · LIMIT BESAR", "30 permintaan/menit · ~14.400 permintaan/hari · ~6.000 token/menit · ~500 rb token/hari"),
            arrayOf("llama-3.3-70b-versatile", "MODEL BESAR · lebih pintar untuk umum · agak lambat · LIMIT KECIL", "30 permintaan/menit · ~1.000 permintaan/hari · ~12.000 token/menit · ~100 rb token/hari"),
            arrayOf("openai/gpt-oss-20b", "MODEL SEDANG · bernalar (reasoning) cepat · LIMIT SEDANG", "30 permintaan/menit · ~1.000 permintaan/hari · ~8.000 token/menit · ~200 rb token/hari"),
            arrayOf("openai/gpt-oss-120b", "MODEL BESAR · paling kuat, bernalar dalam · LIMIT SEDANG-KECIL", "30 permintaan/menit · ~1.000 permintaan/hari · ~8.000 token/menit · ~200 rb token/hari")
        )
        fun renderModels() {
            modelBox.removeAllViews()
            val cur = model.text.toString().trim()
            for (m in infos) {
                val b = Button(this)
                b.isAllCaps = false
                b.gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
                b.text = (if (m[0] == cur) "✓ " else "") + m[0] + "\n" + m[1] + "\n" + m[2]
                b.setOnClickListener { model.setText(m[0]); Prefs.setModel(this, m[0]); renderModels() }
                modelBox.addView(b)
            }
        }
        renderModels()
        col.addView(label("Angka di atas perkiraan paket gratis Groq dan bisa berubah atau berbeda per akun. Angka sebenarnya milik key-mu muncul di bawah tiap key setelah menekan Tes. Kalau satu model kena limit harian, ganti ke model lain, karena limit dihitung per model."))

        col.addView(label("Bahasa terjemahan"))
        val lang = EditText(this)
        lang.setText(Prefs.lang(this)); lang.setSingleLine(true)
        col.addView(lang)

        val hap = CheckBox(this); hap.text = "Getar saat mengetik"; hap.isChecked = Prefs.haptic(this)
        col.addView(hap)
        val sound = CheckBox(this); sound.text = "Suara ketik"; sound.isChecked = Prefs.sound(this)
        col.addView(sound)
        val sug = CheckBox(this); sug.text = "Saran kata (belajar dari yang kamu ketik)"; sug.isChecked = Prefs.suggest(this)
        col.addView(sug)
        val hd = Button(this)
        val hdNames = listOf("Mati", "Kiri", "Kanan")
        hd.text = "Mode satu tangan: " + hdNames[Prefs.hand(this)]
        hd.setOnClickListener {
            Prefs.setHand(this, (Prefs.hand(this) + 1) % 3)
            hd.text = "Mode satu tangan: " + hdNames[Prefs.hand(this)]
        }
        col.addView(hd)
        val vlCodes = listOf("id-ID", "en-US", "ms-MY")
        val vlNames = listOf("Indonesia", "English", "Melayu")
        val vl = Button(this)
        fun vlIdx() = vlCodes.indexOf(Prefs.voiceLang(this)).let { if (it < 0) 0 else it }
        vl.text = "Bahasa suara ke teks: " + vlNames[vlIdx()]
        vl.setOnClickListener {
            Prefs.setVoiceLang(this, vlCodes[(vlIdx() + 1) % vlCodes.size])
            vl.text = "Bahasa suara ke teks: " + vlNames[vlIdx()]
        }
        col.addView(vl)

        val numRow = CheckBox(this); numRow.text = "Baris angka di atas"; numRow.isChecked = Prefs.numRow(this)
        col.addView(numRow)
        val autoCap = CheckBox(this); autoCap.text = "Huruf besar otomatis di awal kalimat"; autoCap.isChecked = Prefs.autoCap(this)
        col.addView(autoCap)
        val dbl = CheckBox(this); dbl.text = "Spasi dua kali = titik"; dbl.isChecked = Prefs.dblSpace(this)
        col.addView(dbl)

        col.addView(label("Teks cepat ⚡ (satu baris = satu teks). Singkatan: tulis kode=teks panjang, misal oms=Oke makasih ya, lalu di keyboard ketik oms + spasi"))
        val snip = EditText(this)
        snip.setText(Prefs.snippets(this)); snip.minLines = 3
        col.addView(snip)

        col.addView(label("Prompt kustom untuk tombol Kustom (contoh: Ubah jadi caption Instagram singkat)"))
        val custom = EditText(this)
        custom.setText(Prefs.custom(this)); custom.minLines = 2
        col.addView(custom)

        col.addView(label("Tema"))
        Prefs.themes.forEachIndexed { i, t ->
            val b = Button(this); b.text = t.name
            b.setOnClickListener { Prefs.setTheme(this, i); b.text = t.name + " ✓"; updatePreview(); PermanentService.instance?.refresh() }
            col.addView(b)
        }

        col.addView(label("Tampilan keyboard (atur sesukamu)", true))
        preview = LinearLayout(this)
        preview!!.orientation = LinearLayout.VERTICAL
        col.addView(preview)
        updatePreview()
        slider(col, "Tinggi tombol", " dp", 28, 100, { Prefs.keyHeightDp(this) }) { Prefs.setKeyHeightDp(this, it) }
        slider(col, "Ukuran font", "%", 50, 220, { Prefs.fontScale(this) }) { Prefs.setFontScale(this, it) }
        slider(col, "Jarak antar tombol (kiri-kanan)", " dp", 0, 12, { Prefs.gapX(this) }) { Prefs.setGapX(this, it) }
        slider(col, "Jarak antar tombol (atas-bawah)", " dp", 0, 12, { Prefs.gapY(this) }) { Prefs.setGapY(this, it) }
        slider(col, "Kelengkungan sudut tombol", " dp", 0, 30, { Prefs.radius(this) }) { Prefs.setRadius(this, it) }
        slider(col, "Transparansi tombol (100 = solid)", "%", 10, 100, { Prefs.keyAlpha(this) }) { Prefs.setKeyAlpha(this, it) }
        slider(col, "Margin kiri-kanan keyboard", " dp", 0, 40, { Prefs.sidePad(this) }) { Prefs.setSidePad(this, it) }
        slider(col, "Margin atas keyboard", " dp", 0, 40, { Prefs.topPad(this) }) { Prefs.setTopPad(this, it) }
        slider(col, "Margin bawah keyboard", " dp", 0, 60, { Prefs.bottomPad(this) }) { Prefs.setBottomPad(this, it) }
        slider(col, "Tinggi baris tombol atas (ABC, AI, emoji…)", " dp", 24, 80, { Prefs.tbH(this) }) { Prefs.setTbH(this, it) }
        slider(col, "Lebar tombol baris atas", " dp", 32, 120, { Prefs.tbW(this) }) { Prefs.setTbW(this, it) }

        val boldCb = CheckBox(this); boldCb.text = "Huruf tebal"; boldCb.isChecked = Prefs.bold(this)
        boldCb.setOnCheckedChangeListener { _, v -> Prefs.setBold(this, v); updatePreview(); PermanentService.instance?.refresh() }
        col.addView(boldCb)
        val fontBtn = Button(this)
        fun fontTxt() { fontBtn.text = "Jenis font: " + Prefs.fontNames[Prefs.fontIdx(this)] + " (ketuk untuk ganti)"; fontBtn.typeface = Prefs.typeface(this) }
        fontTxt()
        fontBtn.setOnClickListener {
            var i = (Prefs.fontIdx(this) + 1) % Prefs.fontNames.size
            if (i == Prefs.fontNames.size - 1 && !Prefs.customFontFile(this).exists()) i = 0
            Prefs.setFontIdx(this, i); Prefs.bumpFontRev(this)
            fontTxt(); updatePreview(); PermanentService.instance?.refresh()
        }
        col.addView(fontBtn)
        val fontFile = Button(this); fontFile.text = "Pilih file font sendiri (.ttf / .otf)"
        fontFile.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, pickFont)
        }
        col.addView(fontFile)

        col.addView(label("Warna tema Kustom (kode hex, contoh #1E1E24). Pilih tema \"Kustom\" di atas agar dipakai."))
        for ((k, name) in Prefs.colorKeys) {
            val tv = label(name); tv.textSize = 12f
            col.addView(tv)
            val e = EditText(this)
            e.setText(Prefs.colorHex(this, k)); e.setSingleLine(true)
            e.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val v = s?.toString()?.trim() ?: ""
                    if (Prefs.parseHex(v) != null) {
                        Prefs.setColorHex(this@SettingsActivity, k, if (v.startsWith("#")) v else "#$v")
                        if (Prefs.theme(this@SettingsActivity) == 4) { updatePreview(); PermanentService.instance?.refresh() }
                    }
                }
            })
            col.addView(e)
        }
        val useCustom = Button(this); useCustom.text = "Pakai tema Kustom"
        useCustom.setOnClickListener { Prefs.setTheme(this, 4); useCustom.text = "Tema Kustom dipakai ✓"; updatePreview(); PermanentService.instance?.refresh() }
        col.addView(useCustom)
        val reset = Button(this); reset.text = "Kembalikan tampilan ke bawaan"
        reset.setOnClickListener {
            val sp = getSharedPreferences("kb", Context.MODE_PRIVATE).edit()
            for (k in listOf("keyH", "gapX", "gapY", "radius", "fontScale", "keyAlpha", "sidePad", "topPad", "bottomPad", "tbH", "tbW", "bold", "font", "animPress", "animTrans", "animAppear", "animSpeed", "cBg", "cKey", "cFn", "cText", "cAccent")) sp.remove(k)
            sp.apply()
            Toast.makeText(this, "Dikembalikan. Buka ulang halaman ini untuk melihat slider.", Toast.LENGTH_LONG).show()
            updatePreview(); PermanentService.instance?.refresh()
        }
        col.addView(reset)

        col.addView(label("Animasi keyboard", true))
        col.addView(label("Ketuk tombol di pratinjau ini untuk mencoba animasi tekan. Pilihan lain bisa dicoba lewat tombol di bawahnya."))
        preview2 = LinearLayout(this)
        preview2!!.orientation = LinearLayout.VERTICAL
        col.addView(preview2)
        fun density() = resources.displayMetrics.density
        fun playTrans() { preview2?.let { KeyAnim.transition(it, Prefs.animTrans(this), Prefs.animSpeed(this) / 100f, density()) } }
        fun playAppear() { preview2?.let { KeyAnim.appear(it, Prefs.animAppear(this), Prefs.animSpeed(this) / 100f, density()) } }
        fun pick(title: String, names: List<String>, get: () -> Int, set: (Int) -> Unit, after: () -> Unit): Button {
            val b = Button(this)
            b.isAllCaps = false
            fun txt() { b.text = title + ": " + names[get()] + "  (ketuk untuk ganti)" }
            txt()
            b.setOnClickListener {
                android.app.AlertDialog.Builder(this).setTitle(title)
                    .setSingleChoiceItems(names.toTypedArray(), get()) { d, which ->
                        set(which); txt(); updatePreview(); PermanentService.instance?.refresh(); d.dismiss(); after()
                    }
                    .setNegativeButton("Batal", null).show()
            }
            return b
        }
        col.addView(pick("Animasi tekan tombol", KeyAnim.pressNames, { Prefs.animPress(this) }, { Prefs.setAnimPress(this, it) }) {})
        col.addView(pick("Animasi pindah layar", KeyAnim.transNames, { Prefs.animTrans(this) }, { Prefs.setAnimTrans(this, it) }) { playTrans() })
        col.addView(pick("Animasi keyboard muncul", KeyAnim.appearNames, { Prefs.animAppear(this) }, { Prefs.setAnimAppear(this, it) }) { playAppear() })
        slider(col, "Kecepatan animasi (100 = normal)", "%", 40, 300, { Prefs.animSpeed(this) }) { Prefs.setAnimSpeed(this, it) }
        val tryTrans = Button(this); tryTrans.text = "Coba animasi pindah layar"
        tryTrans.setOnClickListener { playTrans() }
        col.addView(tryTrans)
        val tryApp = Button(this); tryApp.text = "Coba animasi muncul"
        tryApp.setOnClickListener { playAppear() }
        col.addView(tryApp)
        updatePreview()

        col.addView(label("Keyboard permanen 📌", true))
        col.addView(label("Keyboard tampil terus di layar walau kamu belum menyentuh kotak ketik, dan tetap muncul sampai kamu menekan tombol ⏹ STOP (di keyboard atau di sini). Keyboard ini terdaftar sebagai keyboard biasa (bukan overlay), jadi tidak ditutup otomatis oleh sistem. Pastikan Romaboard dipilih sebagai keyboard aktif. Tombol ▾ memperkecil keyboard jadi ikon bulat yang bisa digeser ke mana saja; ketuk ikon itu untuk membuka keyboard lagi. Tidak perlu layanan aksesibilitas, dan kolom sandi pun didukung."))
        permStatus = TextView(this)
        col.addView(permStatus)
        permBtn = Button(this)
        permBtn.setOnClickListener {
            val ime = AiKeyboardService.instance
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            if (Prefs.permanent(this)) {
                if (ime != null) ime.stopPermanentMode() else Prefs.setPermanent(this, false)
                refreshPerm()
            } else {
                Prefs.setPermanent(this, true)
                val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
                if (!cur.startsWith(packageName)) {
                    Toast.makeText(this, "Pilih \"Romaboard\" sebagai keyboard aktif, lalu ketuk kotak ketik", Toast.LENGTH_LONG).show()
                    imm.showInputMethodPicker()
                } else ime?.startPermanentMode()
                refreshPerm()
            }
        }
        col.addView(permBtn)
        val accBtn = Button(this); accBtn.text = "Buka pengaturan aksesibilitas"
        accBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(accBtn)
        val restr = Button(this); restr.text = "Info aplikasi (untuk 'Izinkan setelan terbatas')"
        restr.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        col.addView(restr)
        col.addView(label("Android 13+ : kalau layanan aksesibilitas abu-abu/terblokir karena APK dipasang di luar Play Store, buka Info aplikasi → titik tiga (⋮) → Izinkan setelan terbatas, lalu nyalakan layanannya."))
        refreshPerm()

        val save = Button(this); save.text = "Simpan"
        save.setOnClickListener {
            Prefs.setModel(this, model.text.toString().trim().ifBlank { "llama-3.1-8b-instant" })
            Prefs.setLang(this, lang.text.toString().trim().ifBlank { "English" })
            Prefs.setHaptic(this, hap.isChecked)
            Prefs.setSound(this, sound.isChecked)
            Prefs.setSuggest(this, sug.isChecked)
            Prefs.setNumRow(this, numRow.isChecked)
            Prefs.setAutoCap(this, autoCap.isChecked)
            Prefs.setDblSpace(this, dbl.isChecked)
            Prefs.setSnippets(this, snip.text.toString())
            Prefs.setCustom(this, custom.text.toString().trim())
            save.text = "Tersimpan ✓"
        }
        col.addView(save)

        col.addView(label("Coba ketik di sini:"))
        col.addView(EditText(this))

        val sv = ScrollView(this)
        sv.addView(col)
        sv.alpha = 0f
        setContentView(sv)
        sv.animate().alpha(1f).setDuration(250).start()
    }
}
