package com.byhas.aikeyboard

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiClient {
    private val main = Handler(Looper.getMainLooper())
    private val fallbacks = listOf("llama-3.1-8b-instant", "llama-3.3-70b-versatile", "openai/gpt-oss-20b")

    private class Res(val code: Int, val text: String, val usage: String)

    private fun call(key: String, m: String, system: String, user: String): Res {
        val body = JSONObject().apply {
            put("model", m)
            put("temperature", 0.5)
            put("max_tokens", 600)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", system))
                put(JSONObject().put("role", "user").put("content", user))
            })
        }
        val con = URL("https://api.groq.com/openai/v1/chat/completions").openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 15000
        con.readTimeout = 30000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        con.setRequestProperty("Accept", "application/json")
        con.setRequestProperty("User-Agent", "AIKeyboard/1.0 (Android)")
        con.setRequestProperty("Authorization", "Bearer " + key.trim())
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        val text = stream?.bufferedReader()?.readText() ?: ""
        fun h(n: String) = con.getHeaderField(n)
        val reqL = h("x-ratelimit-limit-requests"); val reqR = h("x-ratelimit-remaining-requests")
        val tokL = h("x-ratelimit-limit-tokens"); val tokR = h("x-ratelimit-remaining-tokens")
        val parts = ArrayList<String>()
        if (reqL != null && reqR != null) parts.add("sisa $reqR dari $reqL permintaan/hari" + (h("x-ratelimit-reset-requests")?.let { " (reset $it)" } ?: ""))
        if (tokL != null && tokR != null) parts.add("sisa $tokR dari $tokL token/menit" + (h("x-ratelimit-reset-tokens")?.let { " (reset $it)" } ?: ""))
        if (code == 429) h("retry-after")?.let { parts.add("coba lagi ${it}s lagi") }
        val usage = if (parts.isEmpty()) "" else m + ": " + parts.joinToString(" · ")
        return Res(code, text, usage)
    }

    /** Satu key saja (dipakai untuk tombol Tes). ctx opsional untuk menyimpan info sisa limit. */
    fun ask(key: String, model: String, system: String, user: String,
            onOk: (String) -> Unit, onErr: (String) -> Unit, ctx: Context? = null) {
        if (key.isBlank()) { onErr("API key kosong. Buka app AI Keyboard lalu isi API key."); return }
        run(ctx, listOf(key), 0, model, system, user, onOk, onErr)
    }

    /** Pakai semua key tersimpan; kalau key aktif kena limit/salah, otomatis pindah ke key berikutnya. */
    fun askAuto(ctx: Context, model: String, system: String, user: String,
                onOk: (String) -> Unit, onErr: (String) -> Unit) {
        val keys = Prefs.keyList(ctx)
        if (keys.isEmpty()) { onErr("API key kosong. Buka app AI Keyboard lalu isi API key."); return }
        run(ctx, keys, Prefs.keyIdx(ctx), model, system, user, onOk, onErr)
    }

    private fun run(ctx: Context?, keys: List<String>, start: Int, model: String, system: String, user: String,
                    onOk: (String) -> Unit, onErr: (String) -> Unit) {
        Thread {
            val models = (listOf(model.trim()) + fallbacks).filter { it.isNotEmpty() }.distinct()
            var lastErr = "Gagal"
            val fails = ArrayList<String>()
            try {
                for (step in keys.indices) {
                    val idx = (start + step) % keys.size
                    val key = keys[idx]
                    var keyErr = "Gagal"
                    for (m in models) {
                        val r = call(key, m, system, user)
                        if (ctx != null && r.usage.isNotEmpty()) Prefs.setUsage(ctx, key, r.usage)
                        if (r.code in 200..299) {
                            val out = JSONObject(r.text).getJSONArray("choices").getJSONObject(0)
                                .getJSONObject("message").getString("content").trim()
                            if (ctx != null && idx != Prefs.keyIdx(ctx)) Prefs.setKeyIdx(ctx, idx)
                            main.post { onOk(out) }
                            return@Thread
                        }
                        val detail = try {
                            JSONObject(r.text).optJSONObject("error")?.optString("message") ?: ""
                        } catch (e: Exception) { "" }
                        keyErr = when (r.code) {
                            401 -> "API key ditolak Groq" + (if (detail.isNotEmpty()) " (" + detail.take(60) + ")" else "")
                            429 -> "Limit habis, coba lagi sebentar"
                            else -> "Error ${r.code} " + detail.take(90)
                        }
                        if (r.code != 404) break
                    }
                    lastErr = keyErr
                    fails.add("Key #${idx + 1}: $keyErr")
                }
            } catch (e: Exception) {
                lastErr = when (e) {
                    is java.net.UnknownHostException -> "Tidak bisa menjangkau api.groq.com (DNS/internet/VPN?)"
                    is java.net.SocketTimeoutException -> "Koneksi timeout, coba lagi"
                    is javax.net.ssl.SSLException -> "Gagal SSL/jam HP salah? " + (e.message ?: "").take(60)
                    is org.json.JSONException -> "Balasan AI tidak terbaca, coba model lain"
                    else -> "Gagal: " + e.javaClass.simpleName + " " + (e.message ?: "").take(70)
                }
                fails.clear()
            }
            val msg = if (keys.size > 1 && fails.size > 1) "Semua ${keys.size} API key gagal. " + fails.joinToString("; ") else lastErr
            main.post { onErr(msg) }
        }.start()
    }
}
