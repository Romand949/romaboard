package com.byhas.aikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.view.Gravity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.SeekBar
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable

class SettingsActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()


    // ---------- tampilan ----------
    private val cBg = Color.parseColor("#0E1016")
    private val cCard = Color.parseColor("#1A1D29")
    private val cField = Color.parseColor("#11131B")
    private val cStroke = Color.parseColor("#2C3146")
    private val cTonal = Color.parseColor("#272B3D")
    private val cAcc = Color.parseColor("#7C5CFF")
    private val cTxt = Color.parseColor("#F2F3F8")
    private val cSub = Color.parseColor("#9AA1BA")

    private fun rounded(fill: Int, r: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(r).toFloat()
        g.setColor(fill)
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private lateinit var page: LinearLayout

    private fun card(title: String, sub: String? = null): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(cCard, 20, cStroke)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(7), 0, dp(7))
        page.addView(c, lp)
        val t = TextView(this)
        t.text = title
        t.textSize = 17f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(cTxt)
        c.addView(t)
        val bar = android.view.View(this)
        bar.setBackgroundColor(cAcc)
        val blp = LinearLayout.LayoutParams(dp(28), dp(3))
        blp.setMargins(0, dp(6), 0, dp(4))
        c.addView(bar, blp)
        if (sub != null) { val s = label(sub); s.setPadding(0, dp(4), 0, dp(4)); c.addView(s) }
        return c
    }

    private fun tint(v: android.view.View) {
        if (v is android.widget.Switch) {
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            v.thumbTintList = android.content.res.ColorStateList(states, intArrayOf(Color.WHITE, Color.WHITE))
            v.trackTintList = android.content.res.ColorStateList(states, intArrayOf(Color.parseColor("#22C55E"), Color.parseColor("#EF4444")))
        }
    }

    private fun decorate(v: android.view.View) {
        if (v.tag == "keep") return
        when (v) {
            is android.widget.CompoundButton -> {
                v.setTextColor(cTxt); v.textSize = 15f
                v.setPadding(0, dp(10), 0, dp(10))
                tint(v)
            }
            is Button -> {
                val primary = v.text.toString().let { it.contains("Simpan") || it.contains("Tambah") || it.startsWith("Update") || it.contains("Mulai") }
                val danger = v.text.toString().let { it == "Hapus" || it.contains("STOP") }
                v.isAllCaps = false
                v.stateListAnimator = null
                v.setTextColor(Color.WHITE)
                v.textSize = 14f
                v.minHeight = dp(44); v.minimumHeight = dp(44)
                v.setPadding(dp(14), dp(8), dp(14), dp(8))
                val fill = if (primary) cAcc else if (danger) Color.parseColor("#4A2430") else cTonal
                v.background = android.graphics.drawable.RippleDrawable(
                    android.content.res.ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), rounded(fill, 12), null)
                (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.setMargins(dp(2), dp(4), dp(2), dp(4)) }
            }
            is EditText -> {
                v.setTextColor(cTxt); v.setHintTextColor(cSub); v.textSize = 14f
                v.background = rounded(cField, 12, cStroke)
                v.setPadding(dp(14), dp(11), dp(14), dp(11))
                (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.setMargins(0, dp(4), 0, dp(4)) }
            }
            is android.view.ViewGroup -> for (i in 0 until v.childCount) decorate(v.getChildAt(i))
        }
    }

    private fun label(t: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = if (bold) 16f else 13f
        v.setTextColor(if (bold) cTxt else cSub)
        v.setLineSpacing(0f, 1.1f)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(if (bold) 12 else 8), 0, dp(4))
        return v
    }

    private fun checkUpdate(info: TextView, btn: Button) {
        if (BuildConfig.REPO.isBlank()) { runOnUiThread { info.text = "Cek update nonaktif (repo tidak terdeteksi)"; info.visibility = android.view.View.VISIBLE }; return }
        Thread {
            try {
                val con = URL("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest").openConnection() as HttpURLConnection
                con.connectTimeout = 10000
                con.readTimeout = 10000
                con.setRequestProperty("Accept", "application/vnd.github+json")
                con.setRequestProperty("User-Agent", "AIKeyboard/1.0 (Android)")
                if (con.responseCode != 200) {
                    val rc = con.responseCode
                    runOnUiThread { info.text = "Cek update gagal (kode $rc). Repo harus publik."; info.visibility = android.view.View.VISIBLE }
                } else {
                    val j = JSONObject(con.inputStream.bufferedReader().readText())
                    val n = j.getString("tag_name").filter { it.isDigit() }.toIntOrNull() ?: 0
                    val assets = j.getJSONArray("assets")
                    var url = ""
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.getString("name").endsWith(".apk")) url = a.getString("browser_download_url")
                    }
                    if (url.isEmpty() || n <= BuildConfig.VERSION_CODE) {
                        runOnUiThread { info.text = "Sudah versi terbaru (build ${BuildConfig.VERSION_CODE})"; info.visibility = android.view.View.VISIBLE }
                    }
                    if (url.isNotEmpty() && n > BuildConfig.VERSION_CODE) {
                        runOnUiThread {
                            info.text = "Versi baru tersedia (build $n). Versi kamu: build ${BuildConfig.VERSION_CODE}."
                            info.visibility = android.view.View.VISIBLE
                            btn.visibility = android.view.View.VISIBLE
                            btn.setOnClickListener { download(url, btn) }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { info.text = "Cek update gagal: " + (e.message ?: e.javaClass.simpleName).take(60); info.visibility = android.view.View.VISIBLE }
            }
        }.start()
    }

    private fun download(url: String, btn: Button) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Izinkan install dari aplikasi ini, lalu tekan Update lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        btn.isEnabled = false
        btn.text = "Mengunduh…"
        Thread {
            try {
                val f = File(cacheDir, "update.apk")
                val con = URL(url).openConnection() as HttpURLConnection
                con.connectTimeout = 15000
                con.readTimeout = 60000
                con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread {
                    btn.isEnabled = true
                    btn.text = "Update sekarang"
                    installApk(f)
                }
            } catch (e: Exception) {
                runOnUiThread { btn.isEnabled = true; btn.text = "Gagal, coba lagi" }
            }
        }.start()
    }

    private fun installApk(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun model0() = Prefs.model(this)

    private var preview: LinearLayout? = null
    private val miniBtns = ArrayList<Pair<Button, () -> Boolean>>()
    private fun miniRefresh() { for ((b, v) in miniBtns) b.visibility = if (v()) android.view.View.VISIBLE else android.view.View.GONE }
    private var miniPrevH: android.view.View? = null
    private var miniPrevI: android.view.View? = null
    private fun miniPrevRefresh() {
        val th = Prefs.currentTheme(this)
        for ((pv, hidden) in listOf(miniPrevH to true, miniPrevI to false)) {
            val view = pv ?: continue
            val bg = MiniStyle.background(this, hidden, th.accent, th.bg)
            view.background = if (hidden) bg else android.graphics.drawable.LayerDrawable(arrayOf(bg, IconDrawable("keyboard", MiniStyle.inkFor(this, th.accent), dp(26).toFloat())))
            val lp = view.layoutParams
            lp.width = dp(MiniStyle.widthDp(this, hidden))
            lp.height = dp(MiniStyle.heightDp(this, hidden))
            view.layoutParams = lp
        }
    }
    private lateinit var permStatus: TextView
    private lateinit var permBtn: Button

    private fun slider(col: LinearLayout, title: String, unit: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val tv = label("")
        tv.textSize = 13f
        tv.setTextColor(cTxt)
        fun upd(v: Int) { tv.text = "$title: $v$unit" }
        upd(get())
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progressTintList = android.content.res.ColorStateList.valueOf(cAcc)
        sb.thumbTintList = android.content.res.ColorStateList.valueOf(cAcc)
        sb.progress = get() - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                set(p + min); upd(p + min); updatePreview()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { PermanentService.instance?.refresh() }
        })
        col.addView(tv); col.addView(sb)
    }

    private var preview2: LinearLayout? = null

    private fun updatePreview() {
        preview?.let { fillPreview(it) }
        preview2?.let { fillPreview(it) }
    }

    private fun fillPreview(p: LinearLayout) {
        p.removeAllViews()
        val th = Prefs.currentTheme(this)
        p.setBackgroundColor(th.bg)
        p.setPadding(dp(Prefs.sidePad(this)), dp(Prefs.topPad(this)), dp(Prefs.sidePad(this)), dp(Prefs.bottomPad(this)))
        val row = LinearLayout(this)
        for ((i, l) in listOf("Q", "W", "E", "R", "⌫", "space").withIndex()) {
            val special = l == "⌫"
            val t = TextView(this)
            t.text = l
            t.gravity = android.view.Gravity.CENTER
            t.textSize = 18f * Prefs.fontScale(this) / 100f
            t.typeface = Prefs.typeface(this)
            t.setTextColor(th.text)
            val bg = GradientDrawable()
            bg.cornerRadius = dp(Prefs.radius(this)).toFloat()
            bg.setColor(if (special) th.fn else th.key)
            bg.alpha = Prefs.keyAlpha(this) * 255 / 100
            t.background = InsetDrawable(bg, dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)))
            val style = Prefs.animPress(this)
            if (style == KeyAnim.RIPPLE) t.background = KeyAnim.ripple(t.background, dp(Prefs.radius(this)).toFloat(), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), dp(Prefs.gapX(this)), dp(Prefs.gapY(this)), th.accent)
            t.setOnTouchListener { v, e ->
                when (e.action) {
                    android.view.MotionEvent.ACTION_DOWN -> KeyAnim.press(v, true, style, Prefs.animSpeed(this) / 100f, e.x, e.y)
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> KeyAnim.press(v, false, style, Prefs.animSpeed(this) / 100f, e.x, e.y)
                }
                true
            }
            t.layoutParams = LinearLayout.LayoutParams(0, dp(Prefs.keyHeightDp(this)), if (l == "space") 2.5f else 1f)
            row.addView(t)
        }
        p.addView(row)
    }

    // ---------- tombol status: hijau = sudah aktif, merah = belum ----------
    private val statusBtns = mutableListOf<Pair<Button, () -> Boolean>>()

    private fun imeEnabled(): Boolean = try {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).enabledInputMethodList.any { it.packageName == packageName }
    } catch (e: Exception) { false }

    private fun imePicked(): Boolean =
        (Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: "").startsWith(packageName)

    private fun accOn(): Boolean =
        (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "").contains(packageName)

    private fun applyStatus() {
        for ((b, ok) in statusBtns) {
            val on = try { ok() } catch (e: Exception) { false }
            b.tag = "keep"
            b.isAllCaps = false
            b.stateListAnimator = null
            b.setTextColor(Color.WHITE)
            b.textSize = 14f
            b.minHeight = dp(44); b.minimumHeight = dp(44)
            b.setPadding(dp(14), dp(8), dp(14), dp(8))
            val fill = Color.parseColor(if (on) "#16A34A" else "#DC2626")
            b.background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf(Color.parseColor("#44FFFFFF")), rounded(fill, 12), null)
            (b.layoutParams as? LinearLayout.LayoutParams)?.setMargins(dp(2), dp(4), dp(2), dp(4))
        }
    }

    private fun statusBtn(b: Button, ok: () -> Boolean) { statusBtns.add(b to ok) }

    private fun refreshPerm() {
        val run = Prefs.permanent(this)
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val active = cur.startsWith(packageName)
        permStatus.text = when {
            run && active -> "Status: keyboard permanen SEDANG MENYALA"
            run -> "Status: permanen aktif, tapi Romaboard belum dipilih sebagai keyboard"
            else -> "Status: keyboard permanen mati"
        }
        permBtn.text = if (run) "⏹ STOP keyboard permanen" else "▶ Mulai keyboard permanen"
        applyStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::permStatus.isInitialized) refreshPerm()
        applyStatus()
    }

    override fun onPause() {
        super.onPause()
        PermanentService.instance?.refresh()
    }

    private val pickFont = 4711
    private val pickBg = 4712
    private val pickStk = 4713
    private var stkInfo: TextView? = null
    private fun stkRefresh() {
        val n = Prefs.stickerDir(this).listFiles()?.count { it.isFile } ?: 0
        stkInfo?.text = "Stiker tersimpan: $n"
    }

    private fun decodeScaled(uri: Uri, maxSide: Int): android.graphics.Bitmap? {
        return try {
            val o1 = android.graphics.BitmapFactory.Options()
            o1.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o1) }
            var sample = 1
            while (o1.outWidth / sample > maxSide * 2 || o1.outHeight / sample > maxSide * 2) sample *= 2
            val o2 = android.graphics.BitmapFactory.Options()
            o2.inSampleSize = sample
            val raw = contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) } ?: return null
            val big = Math.max(raw.width, raw.height)
            if (big <= maxSide) raw
            else {
                val f = maxSide.toFloat() / big
                android.graphics.Bitmap.createScaledBitmap(raw, (raw.width * f).toInt().coerceAtLeast(1), (raw.height * f).toInt().coerceAtLeast(1), true)
            }
        } catch (e: Exception) { null }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickBg && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val bmp = decodeScaled(uri, 1200)
            if (bmp == null) Toast.makeText(this, "Gambar tidak bisa dibuka.", Toast.LENGTH_LONG).show()
            else {
                try {
                    Prefs.bgFile(this).outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, it) }
                    Prefs.bumpBgRev(this)
                    Toast.makeText(this, "Foto latar dipakai \u2713", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) { Toast.makeText(this, "Gagal menyimpan foto.", Toast.LENGTH_LONG).show() }
            }
            PermanentService.instance?.refresh()
            return
        }
        if (requestCode == pickStk && resultCode == RESULT_OK) {
            val uris = ArrayList<Uri>()
            data?.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
            if (uris.isEmpty()) data?.data?.let { uris.add(it) }
            val dir = Prefs.stickerDir(this); dir.mkdirs()
            var n = 0
            for (u in uris) {
                val b = decodeScaled(u, 512) ?: continue
                try {
                    File(dir, "stk_" + System.currentTimeMillis() + "_" + n + ".png").outputStream().use { b.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    n++
                } catch (e: Exception) {}
            }
            Toast.makeText(this, "$n stiker ditambahkan", Toast.LENGTH_SHORT).show()
            stkRefresh()
            return
        }
        if (requestCode == pickFont && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri)?.use { i -> Prefs.customFontFile(this).outputStream().use { o -> i.copyTo(o) } }
                android.graphics.Typeface.createFromFile(Prefs.customFontFile(this)) // uji: lempar error kalau bukan font
                Prefs.setFontIdx(this, Prefs.fontNames.size - 1)
                Prefs.bumpFontRev(this)
                Toast.makeText(this, "Font dipakai ✓", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Prefs.customFontFile(this).delete()
                Toast.makeText(this, "File bukan font yang valid (.ttf / .otf)", Toast.LENGTH_LONG).show()
            }
            updatePreview()
            PermanentService.instance?.refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(14), dp(16), dp(14), dp(28))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        val hg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#7C5CFF"), Color.parseColor("#3B82F6")))
        hg.cornerRadius = dp(24).toFloat()
        head.background = hg
        head.setPadding(dp(20), dp(24), dp(20), dp(22))
        val h1 = TextView(this); h1.text = "⌨️  Romaboard"; h1.textSize = 26f
        h1.setTypeface(null, Typeface.BOLD); h1.setTextColor(Color.WHITE)
        val h2 = TextView(this); h2.text = "Keyboard AI buatanmu sendiri  ·  v${BuildConfig.VERSION_NAME}"
        h2.textSize = 13f; h2.setTextColor(Color.parseColor("#E6E8FF")); h2.setPadding(0, dp(4), 0, 0)
        head.addView(h1); head.addView(h2)
        page.addView(head)

        var col = card("🔄 Pembaruan")
        val upInfo = TextView(this)
        upInfo.visibility = android.view.View.GONE
        val upBtn = Button(this); upBtn.text = "Update sekarang"
        upBtn.visibility = android.view.View.GONE
        val upCheck = Button(this); upCheck.text = "Cek update"
        upCheck.setOnClickListener {
            upInfo.text = "Memeriksa versi terbaru…"
            upInfo.visibility = android.view.View.VISIBLE
            upBtn.visibility = android.view.View.GONE
            upBtn.text = "Update sekarang"
            upBtn.isEnabled = true
            checkUpdate(upInfo, upBtn)
        }
        col.addView(upCheck)
        col.addView(upInfo)
        col.addView(upBtn)
        checkUpdate(upInfo, upBtn)
        col = card("🚀 Mulai pakai", "1) Aktifkan keyboard, 2) pilih sebagai keyboard utama.")
        val b1 = Button(this); b1.text = "Aktifkan keyboard"
        b1.setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        col.addView(b1); statusBtn(b1) { imeEnabled() }
        val b2 = Button(this); b2.text = "Pilih keyboard"
        b2.setOnClickListener { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        col.addView(b2); statusBtn(b2) { imePicked() }

        col = card("🔑 API Key Groq", "Isi API key Groq milikmu sendiri (gratis). Bisa lebih dari satu: kalau key aktif kena limit, keyboard otomatis pindah ke key berikutnya.")
        val getKey = Button(this); getKey.text = "Buka situs Groq untuk buat key"
        getKey.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://console.groq.com/keys"))) }
        col.addView(getKey)

        val keyBox = LinearLayout(this); keyBox.orientation = LinearLayout.VERTICAL
        col.addView(keyBox)
        fun mask(k: String) = if (k.length <= 8) "••••" else k.take(4) + "…" + k.takeLast(4)
        fun renderKeys() {
            keyBox.removeAllViews()
            val keys = Prefs.keyList(this)
            val act = Prefs.keyIdx(this)
            if (keys.isEmpty()) keyBox.addView(label("Belum ada API key. Tambahkan di bawah."))
            keys.forEachIndexed { i, k ->
                val head = label("Key #${i + 1}   ${mask(k)}  (${k.length} karakter)" + (if (i == act) "   ✓ AKTIF" else ""), i == act)
                keyBox.addView(head)
                val u = label(Prefs.usage(this, k) ?: "Belum ada data pemakaian. Tekan Tes untuk melihat sisa limit.")
                u.textSize = 12f
                keyBox.addView(u)
                val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL
                val bUse = Button(this); bUse.text = "Pakai"
                bUse.setOnClickListener { Prefs.setKeyIdx(this, i); renderKeys() }
                val bTest = Button(this); bTest.text = "Tes"
                bTest.setOnClickListener {
                    bTest.text = "Menguji…"
                    AiClient.ask(k, model0(), "Reply with OK.", "ping",
                        { renderKeys(); Toast.makeText(this, "Key #${i + 1} berfungsi ✓", Toast.LENGTH_SHORT).show() },
                        { e -> bTest.text = "Tes"; u.text = "Gagal: $e" }, this)
                }
                val bDel = Button(this); bDel.text = "Hapus"
                bDel.setOnClickListener { Prefs.removeKey(this, i); renderKeys() }
                for (b in listOf(bUse, bTest, bDel)) r.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                keyBox.addView(r)
            }
            decorate(keyBox)
        }
        val newKey = EditText(this)
        newKey.setSingleLine(true)
        newKey.hint = "Tempel API key baru (gsk_...)"
        newKey.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        col.addView(newKey)
        val addKey = Button(this); addKey.text = "➕ Tambah API key"
        addKey.setOnClickListener {
            val k = Prefs.clean(newKey.text.toString())
            if (k.isEmpty()) Toast.makeText(this, "Tempel API key dulu", Toast.LENGTH_SHORT).show()
            else if (!Prefs.addKey(this, k)) Toast.makeText(this, "Key itu sudah ada", Toast.LENGTH_SHORT).show()
            else {
                newKey.setText(""); renderKeys()
                val warn = if (!k.startsWith("gsk_") || k.length < 40) " Key Groq biasanya diawali gsk_ dan sekitar 56 karakter, key ini ${k.length} karakter, mungkin terpotong." else ""
                Toast.makeText(this, "Key ditambahkan, sedang diuji…", Toast.LENGTH_SHORT).show()
                AiClient.ask(k, model0(), "Reply with OK.", "ping",
                    { renderKeys(); Toast.makeText(this, "Key berfungsi ✓", Toast.LENGTH_SHORT).show() },
                    { e -> Toast.makeText(this, "Gagal: $e.$warn", Toast.LENGTH_LONG).show() }, this)
            }
        }
        col.addView(addKey)
        col.addView(label("Penting: menurut dokumentasi Groq, limit dihitung per akun/organisasi, bukan per key. Beberapa key dari akun yang sama TIDAK menambah jatah. Buat key dari akun Groq yang berbeda supaya pindah key benar-benar membantu. Keyboard otomatis pindah kalau key kena limit (429) atau salah (401)."))
        renderKeys()

        col = card("🤖 Model AI", "Ketuk untuk memilih, atau ketik nama model sendiri.")
        val model = EditText(this)
        model.setText(Prefs.model(this)); model.setSingleLine(true)
        col.addView(model)
        val modelBox = LinearLayout(this); modelBox.orientation = LinearLayout.VERTICAL
        col.addView(modelBox)
        val infos = listOf(
            arrayOf("llama-3.1-8b-instant", "MODEL KECIL · paling cepat · jawaban sederhana · LIMIT BESAR", "30 permintaan/menit · ~14.400 permintaan/hari · ~6.000 token/menit · ~500 rb token/hari"),
            arrayOf("llama-3.3-70b-versatile", "MODEL BESAR · lebih pintar untuk umum · agak lambat · LIMIT KECIL", "30 permintaan/menit · ~1.000 permintaan/hari · ~12.000 token/menit · ~100 rb token/hari"),
            arrayOf("openai/gpt-oss-20b", "MODEL SEDANG · bernalar (reasoning) cepat · LIMIT SEDANG", "30 permintaan/menit · ~1.000 permintaan/hari · ~8.000 token/menit · ~200 rb token/hari"),
            arrayOf("openai/gpt-oss-120b", "MODEL BESAR · paling kuat, bernalar dalam · LIMIT SEDANG-KECIL", "30 permintaan/menit · ~1.000 permintaan/hari · ~8.000 token/menit · ~200 rb token/hari")
        )
        fun renderModels() {
            modelBox.removeAllViews()
            val cur = model.text.toString().trim()
            for (m in infos) {
                val b = Button(this)
                b.isAllCaps = false
                b.gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
                b.text = (if (m[0] == cur) "✓ " else "") + m[0] + "\n" + m[1] + "\n" + m[2]
                b.setOnClickListener { model.setText(m[0]); Prefs.setModel(this, m[0]); renderModels() }
                modelBox.addView(b)
            }
            decorate(modelBox)
        }
        renderModels()
        col.addView(label("Angka di atas perkiraan paket gratis Groq dan bisa berubah atau berbeda per akun. Angka sebenarnya milik key-mu muncul di bawah tiap key setelah menekan Tes. Kalau satu model kena limit harian, ganti ke model lain, karena limit dihitung per model."))

        col = card("⚙️ Pengaturan umum")
        col.addView(label("Bahasa terjemahan"))
        val lang = EditText(this)
        lang.setText(Prefs.lang(this)); lang.setSingleLine(true)
        col.addView(lang)

        val hap = android.widget.Switch(this); hap.text = "Getar saat mengetik"; hap.isChecked = Prefs.haptic(this)
        col.addView(hap)
        val sound = android.widget.Switch(this); sound.text = "Suara ketik"; sound.isChecked = Prefs.sound(this)
        col.addView(sound)
        val sug = android.widget.Switch(this); sug.text = "Saran kata (belajar dari yang kamu ketik)"; sug.isChecked = Prefs.suggest(this)
        col.addView(sug)
        val hd = Button(this)
        val hdNames = listOf("Mati", "Kiri", "Kanan")
        hd.text = "Mode satu tangan: " + hdNames[Prefs.hand(this)]
        hd.setOnClickListener {
            Prefs.setHand(this, (Prefs.hand(this) + 1) % 3)
            hd.text = "Mode satu tangan: " + hdNames[Prefs.hand(this)]
        }
        col.addView(hd)
        val vlCodes = listOf("id-ID", "en-US", "ms-MY")
        val vlNames = listOf("Indonesia", "English", "Melayu")
        val vl = Button(this)
        fun vlIdx() = vlCodes.indexOf(Prefs.voiceLang(this)).let { if (it < 0) 0 else it }
        vl.text = "Bahasa suara ke teks: " + vlNames[vlIdx()]
        vl.setOnClickListener {
            Prefs.setVoiceLang(this, vlCodes[(vlIdx() + 1) % vlCodes.size])
            vl.text = "Bahasa suara ke teks: " + vlNames[vlIdx()]
        }
        col.addView(vl)

        val lay = Button(this); lay.isAllCaps = false
        fun layTxt() { lay.text = "Tata letak keyboard: " + Prefs.layoutNames[Prefs.layout(this)] + "  (ketuk untuk ganti)" }
        layTxt()
        lay.setOnClickListener {
            android.app.AlertDialog.Builder(this).setTitle("Tata letak keyboard")
                .setSingleChoiceItems(Prefs.layoutNames.toTypedArray(), Prefs.layout(this)) { d, which ->
                    Prefs.setLayout(this, which); layTxt(); PermanentService.instance?.refresh(); d.dismiss()
                }
                .setNegativeButton("Batal", null).show()
        }
        col.addView(lay)
        val numRow = android.widget.Switch(this); numRow.text = "Baris angka di atas"; numRow.isChecked = Prefs.numRow(this)
        col.addView(numRow)
        val autoCap = android.widget.Switch(this); autoCap.text = "Huruf besar otomatis di awal kalimat"; autoCap.isChecked = Prefs.autoCap(this)
        col.addView(autoCap)
        val dbl = android.widget.Switch(this); dbl.text = "Spasi dua kali = titik"; dbl.isChecked = Prefs.dblSpace(this)
        col.addView(dbl)

        col.addView(label("Teks cepat ⚡ (satu baris = satu teks). Singkatan: tulis kode=teks panjang, misal oms=Oke makasih ya, lalu di keyboard ketik oms + spasi"))
        val snip = EditText(this)
        snip.setText(Prefs.snippets(this)); snip.minLines = 3
        col.addView(snip)

        col.addView(label("Prompt kustom untuk tombol Kustom (contoh: Ubah jadi caption Instagram singkat)"))
        val custom = EditText(this)
        custom.setText(Prefs.custom(this)); custom.minLines = 2
        col.addView(custom)

        col = card("🎨 Tema keyboard")
        val themeRow = LinearLayout(this); themeRow.orientation = LinearLayout.HORIZONTAL
        val themeScroll = android.widget.HorizontalScrollView(this)
        themeScroll.isHorizontalScrollBarEnabled = false
        themeScroll.addView(themeRow)
        col.addView(themeScroll)
        fun renderThemes() {
            themeRow.removeAllViews()
            val sel = Prefs.theme(this)
            Prefs.themes.forEachIndexed { i, t ->
                val b = Button(this)
                b.tag = "keep"
                b.isAllCaps = false; b.stateListAnimator = null
                b.text = t.name; b.textSize = 12f
                b.setTextColor(t.text)
                b.setPadding(dp(2), dp(14), dp(2), dp(14))
                val g = rounded(t.bg, 14, if (i == sel) t.accent else cStroke)
                if (i == sel) g.setStroke(dp(3), t.accent)
                b.background = g
                b.setOnClickListener { Prefs.setTheme(this, i); renderThemes(); updatePreview(); PermanentService.instance?.refresh() }
                val lp = LinearLayout.LayoutParams(dp(84), LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.setMargins(dp(3), dp(4), dp(3), dp(4))
                themeRow.addView(b, lp)
            }
        }
        renderThemes()


        col = card("📐 Tampilan keyboard", "Atur sesukamu. Pratinjau di bawah ikut berubah.")
        preview = LinearLayout(this)
        preview!!.orientation = LinearLayout.VERTICAL
        col.addView(preview)
        updatePreview()
        slider(col, "Tinggi tombol", " dp", 28, 100, { Prefs.keyHeightDp(this) }) { Prefs.setKeyHeightDp(this, it) }
        slider(col, "Ukuran font", "%", 50, 220, { Prefs.fontScale(this) }) { Prefs.setFontScale(this, it) }
        slider(col, "Jarak antar tombol (kiri-kanan)", " dp", 0, 12, { Prefs.gapX(this) }) { Prefs.setGapX(this, it) }
        slider(col, "Jarak antar tombol (atas-bawah)", " dp", 0, 12, { Prefs.gapY(this) }) { Prefs.setGapY(this, it) }
        slider(col, "Kelengkungan sudut tombol", " dp", 0, 30, { Prefs.radius(this) }) { Prefs.setRadius(this, it) }
        slider(col, "Transparansi tombol (100 = solid)", "%", 10, 100, { Prefs.keyAlpha(this) }) { Prefs.setKeyAlpha(this, it) }
        slider(col, "Margin kiri-kanan keyboard", " dp", 0, 40, { Prefs.sidePad(this) }) { Prefs.setSidePad(this, it) }
        slider(col, "Margin atas keyboard", " dp", 0, 40, { Prefs.topPad(this) }) { Prefs.setTopPad(this, it) }
        slider(col, "Margin bawah keyboard", " dp", 0, 60, { Prefs.bottomPad(this) }) { Prefs.setBottomPad(this, it) }
        slider(col, "Tinggi baris tombol atas (ABC, AI, emoji…)", " dp", 24, 80, { Prefs.tbH(this) }) { Prefs.setTbH(this, it) }
        slider(col, "Lebar tombol baris atas", " dp", 32, 120, { Prefs.tbW(this) }) { Prefs.setTbW(this, it) }
        col.addView(label("Lebar tombol khusus (100% = selebar tombol huruf)"))
        slider(col, "Lebar Shift & Hapus", "%", 80, 300, { Prefs.wShift(this) }) { Prefs.setWShift(this, it) }
        slider(col, "Lebar tombol 123 / ABC", "%", 80, 300, { Prefs.wMode(this) }) { Prefs.setWMode(this, it) }
        slider(col, "Lebar Spasi", "%", 150, 800, { Prefs.wSpace(this) }) { Prefs.setWSpace(this, it) }
        slider(col, "Lebar Enter", "%", 80, 300, { Prefs.wEnter(this) }) { Prefs.setWEnter(this, it) }
        slider(col, "Lebar koma, titik & ganti keyboard", "%", 60, 200, { Prefs.wPunct(this) }) { Prefs.setWPunct(this, it) }
        col.addView(label("Panel emoji & simbol"))
        slider(col, "Ukuran emoji & simbol", " sp", 12, 36, { Prefs.emoSize(this) }) { Prefs.setEmoSize(this, it) }
        slider(col, "Tinggi panel emoji & simbol", " dp", 100, 260, { Prefs.emoH(this) }) { Prefs.setEmoH(this, it) }

        col = card("↕️ Urutan tombol baris atas", "Paling atas = paling kiri.")
        val orderBox = LinearLayout(this); orderBox.orientation = LinearLayout.VERTICAL
        col.addView(orderBox)
        fun renderOrder() {
            orderBox.removeAllViews()
            val ord = Prefs.toolbarOrder(this).toMutableList()
            ord.forEachIndexed { i, id ->
                val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
                val t = TextView(this); t.text = "${i + 1}. " + (Prefs.toolbarNames[id] ?: id); t.textSize = 14f
                r.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                fun move(to: Int) {
                    if (to !in ord.indices) return
                    val x = ord.removeAt(i); ord.add(to, x)
                    Prefs.setToolbarOrder(this, ord); renderOrder(); PermanentService.instance?.refresh()
                }
                val up = Button(this); up.text = "↑"; up.isEnabled = i > 0; up.setOnClickListener { move(i - 1) }
                val dn = Button(this); dn.text = "↓"; dn.isEnabled = i < ord.size - 1; dn.setOnClickListener { move(i + 1) }
                r.addView(up, LinearLayout.LayoutParams(dp(56), LinearLayout.LayoutParams.WRAP_CONTENT))
                r.addView(dn, LinearLayout.LayoutParams(dp(56), LinearLayout.LayoutParams.WRAP_CONTENT))
                orderBox.addView(r)
            }
            decorate(orderBox)
        }
        renderOrder()
        val resetOrder = Button(this); resetOrder.text = "Kembalikan urutan tombol ke bawaan"
        resetOrder.setOnClickListener {
            Prefs.setToolbarOrder(this, Prefs.toolbarIds); renderOrder(); PermanentService.instance?.refresh()
        }
        col.addView(resetOrder)

        col = card("🔤 Font & warna")
        val boldCb = android.widget.Switch(this); boldCb.text = "Huruf tebal"; boldCb.isChecked = Prefs.bold(this)
        boldCb.setOnCheckedChangeListener { _, v -> Prefs.setBold(this, v); updatePreview(); PermanentService.instance?.refresh() }
        col.addView(boldCb)
        val fontBtn = Button(this)
        fun fontTxt() { fontBtn.text = "Jenis font: " + Prefs.fontNames[Prefs.fontIdx(this)] + " (ketuk untuk ganti)"; fontBtn.typeface = Prefs.typeface(this) }
        fontTxt()
        fontBtn.setOnClickListener {
            var i = (Prefs.fontIdx(this) + 1) % Prefs.fontNames.size
            if (i == Prefs.fontNames.size - 1 && !Prefs.customFontFile(this).exists()) i = 0
            Prefs.setFontIdx(this, i); Prefs.bumpFontRev(this)
            fontTxt(); updatePreview(); PermanentService.instance?.refresh()
        }
        col.addView(fontBtn)
        val fontFile = Button(this); fontFile.text = "Pilih file font sendiri (.ttf / .otf)"
        fontFile.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, pickFont)
        }
        col.addView(fontFile)

        col.addView(label("Warna tema Kustom (kode hex, contoh #1E1E24). Pilih tema \"Kustom\" di atas agar dipakai."))
        for ((k, name) in Prefs.colorKeys) {
            val tv = label(name); tv.textSize = 12f
            col.addView(tv)
            val e = EditText(this)
            e.setText(Prefs.colorHex(this, k)); e.setSingleLine(true)
            e.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val v = s?.toString()?.trim() ?: ""
                    if (Prefs.parseHex(v) != null) {
                        Prefs.setColorHex(this@SettingsActivity, k, if (v.startsWith("#")) v else "#$v")
                        if (Prefs.theme(this@SettingsActivity) == 4) { updatePreview(); PermanentService.instance?.refresh() }
                    }
                }
            })
            col.addView(e)
        }
        val useCustom = Button(this); useCustom.text = "Pakai tema Kustom"
        useCustom.setOnClickListener { Prefs.setTheme(this, 4); useCustom.text = "Tema Kustom dipakai ✓"; updatePreview(); PermanentService.instance?.refresh() }
        col.addView(useCustom)
        val reset = Button(this); reset.text = "Kembalikan tampilan ke bawaan"
        reset.setOnClickListener {
            val sp = getSharedPreferences("kb", Context.MODE_PRIVATE).edit()
            for (k in listOf("keyH", "keyH2", "gapX", "gapY", "radius", "fontScale", "keyAlpha", "sidePad", "topPad", "bottomPad", "tbH", "tbW", "tbOrder", "bold", "font", "animPress", "animTrans", "animAppear", "animSpeed", "cBg", "cKey", "cFn", "cText", "cAccent", "miniShape", "miniColor", "miniAlphaH", "miniAlphaI", "miniSizeH", "miniSizeI")) sp.remove(k)
            sp.apply()
            Toast.makeText(this, "Dikembalikan. Buka ulang halaman ini untuk melihat slider.", Toast.LENGTH_LONG).show()
            updatePreview(); PermanentService.instance?.refresh()
        }
        col.addView(reset)

        col = card("\uD83D\uDDBC\uFE0F Kustom keyboard", "Foto latar, gradasi, stiker, dan emoji buatanmu sendiri. Untuk foto, kecilkan 'Transparansi tombol' di atas supaya fotonya kelihatan.")
        col.addView(label("Foto latar keyboard"))
        val bgPick = Button(this); bgPick.isAllCaps = false; bgPick.text = "Pilih foto latar dari galeri"
        bgPick.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE); i.type = "image/*"
            startActivityForResult(i, pickBg)
        }
        col.addView(bgPick)
        val bgDel = Button(this); bgDel.isAllCaps = false; bgDel.text = "Hapus foto latar"
        bgDel.setOnClickListener {
            Prefs.bgFile(this).delete(); Prefs.bumpBgRev(this)
            Toast.makeText(this, "Foto latar dihapus", Toast.LENGTH_SHORT).show()
            PermanentService.instance?.refresh()
        }
        col.addView(bgDel)
        slider(col, "Gelapkan foto (biar tulisan terbaca)", "%", 0, 80, { Prefs.bgDim(this) }) { Prefs.setBgDim(this, it) }

        col.addView(label("Gradasi latar (dipakai kalau tidak ada foto)"))
        val gSw = android.widget.Switch(this); gSw.text = "Aktifkan gradasi"; gSw.isChecked = Prefs.gradOn(this)
        gSw.setOnCheckedChangeListener { _, on -> Prefs.setGradOn(this, on); PermanentService.instance?.refresh() }
        col.addView(gSw)
        for ((title, k) in listOf("Warna gradasi 1 (kode hex)" to "gradC1", "Warna gradasi 2 (kode hex)" to "gradC2")) {
            val tv = label(title); tv.textSize = 12f
            col.addView(tv)
            val e = EditText(this)
            e.setText(Prefs.gradHex(this, k)); e.setSingleLine(true)
            e.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) {
                    val v = s?.toString()?.trim() ?: ""
                    if (Prefs.parseHex(v) != null) {
                        Prefs.setGradHex(this@SettingsActivity, k, if (v.startsWith("#")) v else "#$v")
                        PermanentService.instance?.refresh()
                    }
                }
            })
            col.addView(e)
        }
        val gDir = Button(this); gDir.isAllCaps = false
        fun gDirTxt() { gDir.text = "Arah gradasi: " + Prefs.gradDirNames[Prefs.gradDir(this)] + "  (ketuk untuk ganti)" }
        gDirTxt()
        gDir.setOnClickListener {
            android.app.AlertDialog.Builder(this).setTitle("Arah gradasi")
                .setSingleChoiceItems(Prefs.gradDirNames.toTypedArray(), Prefs.gradDir(this)) { d, which ->
                    Prefs.setGradDir(this, which); gDirTxt(); d.dismiss(); PermanentService.instance?.refresh()
                }
                .setNegativeButton("Batal", null).show()
        }
        col.addView(gDir)

        col.addView(label("Stiker (dikirim dari keyboard: menu 4 kotak \u2192 Stiker). Aplikasi tujuan harus mendukung gambar; kalau tidak, stiker disalin dan bisa ditempel manual."))
        val stkLbl = label("")
        stkInfo = stkLbl
        col.addView(stkLbl)
        val stkAdd = Button(this); stkAdd.isAllCaps = false; stkAdd.text = "Tambah stiker dari galeri (boleh banyak)"
        stkAdd.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE); i.type = "image/*"
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            startActivityForResult(i, pickStk)
        }
        col.addView(stkAdd)
        val stkDel = Button(this); stkDel.isAllCaps = false; stkDel.text = "Hapus semua stiker"
        stkDel.setOnClickListener {
            Prefs.stickerDir(this).listFiles()?.forEach { it.delete() }
            stkRefresh()
        }
        col.addView(stkDel)
        stkRefresh()

        col.addView(label("Emoji & teks favoritmu (pisahkan dengan spasi). Muncul di tab \u2B50 pada panel emoji."))
        val favEdit = EditText(this)
        favEdit.setText(Prefs.customEmoji(this)); favEdit.minLines = 2
        favEdit.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { Prefs.setCustomEmoji(this@SettingsActivity, s?.toString() ?: "") }
        })
        col.addView(favEdit)

        col = card("✨ Animasi keyboard", "Ketuk tombol di pratinjau ini untuk mencoba animasi tekan. Pilihan lain bisa dicoba lewat tombol di bawahnya.")
        preview2 = LinearLayout(this)
        preview2!!.orientation = LinearLayout.VERTICAL
        col.addView(preview2)
        fun density() = resources.displayMetrics.density
        fun playTrans() { preview2?.let { KeyAnim.transition(it, Prefs.animTrans(this), Prefs.animSpeed(this) / 100f, density()) } }
        fun playAppear() { preview2?.let { KeyAnim.appear(it, Prefs.animAppear(this), Prefs.animSpeed(this) / 100f, density()) } }
        fun pick(title: String, names: List<String>, get: () -> Int, set: (Int) -> Unit, after: () -> Unit): Button {
            val b = Button(this)
            b.isAllCaps = false
            fun txt() { b.text = title + ": " + names[get()] + "  (ketuk untuk ganti)" }
            txt()
            b.setOnClickListener {
                android.app.AlertDialog.Builder(this).setTitle(title)
                    .setSingleChoiceItems(names.toTypedArray(), get()) { d, which ->
                        set(which); txt(); updatePreview(); PermanentService.instance?.refresh(); d.dismiss(); after()
                    }
                    .setNegativeButton("Batal", null).show()
            }
            return b
        }
        col.addView(pick("Animasi tekan tombol", KeyAnim.pressNames, { Prefs.animPress(this) }, { Prefs.setAnimPress(this, it) }) {})
        col.addView(pick("Animasi pindah layar", KeyAnim.transNames, { Prefs.animTrans(this) }, { Prefs.setAnimTrans(this, it) }) { playTrans() })
        col.addView(pick("Animasi keyboard muncul", KeyAnim.appearNames, { Prefs.animAppear(this) }, { Prefs.setAnimAppear(this, it) }) { playAppear() })
        slider(col, "Kecepatan animasi (100 = normal)", "%", 40, 300, { Prefs.animSpeed(this) }) { Prefs.setAnimSpeed(this, it) }
        val tryTrans = Button(this); tryTrans.text = "Coba animasi pindah layar"
        tryTrans.setOnClickListener { playTrans() }
        col.addView(tryTrans)
        val tryApp = Button(this); tryApp.text = "Coba animasi muncul"
        tryApp.setOnClickListener { playAppear() }
        col.addView(tryApp)
        updatePreview()

        col = card("📌 Keyboard permanen")
        col.addView(label("Keyboard tampil terus di layar walau kamu belum menyentuh kotak ketik, dan tetap muncul sampai kamu menekan tombol ⏹ STOP (di keyboard atau di sini). Keyboard ini terdaftar sebagai keyboard biasa (bukan overlay), jadi tidak ditutup otomatis oleh sistem. Pastikan Romaboard dipilih sebagai keyboard aktif. Di baris atas keyboard ada dua tombol: ▾ memperkecil jadi ikon kecil yang bisa digeser, dan ikon mata dicoret menyembunyikan keyboard jadi area tak terlihat yang dibuka dengan ketuk 1x/2x/3x (juga ada di menu 4 kotak). Warna, bentuk, opasitas, dan ukurannya diatur di bawah. Tidak perlu layanan aksesibilitas, dan kolom sandi pun didukung."))
        permStatus = TextView(this)
        permStatus.setTextColor(cTxt); permStatus.textSize = 14f; permStatus.setPadding(0, dp(8), 0, dp(4))
        col.addView(permStatus)
        permBtn = Button(this)
        permBtn.setOnClickListener {
            val ime = AiKeyboardService.instance
            val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
            if (Prefs.permanent(this)) {
                if (ime != null) ime.stopPermanentMode() else Prefs.setPermanent(this, false)
                refreshPerm()
            } else {
                Prefs.setPermanent(this, true)
                val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
                if (!cur.startsWith(packageName)) {
                    Toast.makeText(this, "Pilih \"Romaboard\" sebagai keyboard aktif, lalu ketuk kotak ketik", Toast.LENGTH_LONG).show()
                    imm.showInputMethodPicker()
                } else ime?.startPermanentMode()
                refreshPerm()
            }
        }
        col.addView(permBtn); statusBtn(permBtn) { Prefs.permanent(this) }
        val accBtn = Button(this); accBtn.text = "Buka pengaturan aksesibilitas"
        accBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        col.addView(accBtn); statusBtn(accBtn) { accOn() }
        val restr = Button(this); restr.text = "Info aplikasi (untuk 'Izinkan setelan terbatas')"
        restr.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        col.addView(restr)
        col.addView(label("Android 13+ : kalau layanan aksesibilitas abu-abu/terblokir karena APK dipasang di luar Play Store, buka Info aplikasi → titik tiga (⋮) → Izinkan setelan terbatas, lalu nyalakan layanannya."))
        col.addView(label("Saat keyboard permanen diperkecil (tombol ▾ di keyboard):"))
        fun miniPick(title: String, names: List<String>, get: () -> Int, set: (Int) -> Unit, visible: () -> Boolean): Button {
            val b = Button(this); b.isAllCaps = false
            fun txt() { b.text = title + ": " + names[get()] + "  (ketuk untuk ganti)" }
            txt()
            b.setOnClickListener {
                android.app.AlertDialog.Builder(this).setTitle(title)
                    .setSingleChoiceItems(names.toTypedArray(), get()) { d, which -> set(which); txt(); d.dismiss(); miniRefresh() }
                    .setNegativeButton("Batal", null).show()
            }
            miniBtns.add(b to visible)
            return b
        }
        col.addView(miniPick("Bentuk saat diperkecil", Prefs.miniModeNames, { Prefs.miniMode(this) }, { Prefs.setMiniMode(this, it) }) { true })
        col.addView(miniPick("Cara membuka lagi", Prefs.miniTapNames, { Prefs.miniTaps(this) - 1 }, { Prefs.setMiniTaps(this, it + 1) }) { true })
        col.addView(miniPick("Area ketuk tersembunyi", Prefs.miniCornerNames, { Prefs.miniCorner(this) }, { Prefs.setMiniCorner(this, it) }) { Prefs.miniMode(this) == 1 })

        col.addView(label("Tampilan tombol saat diperkecil: bentuk, warna, opasitas, dan ukuran. Semua ini juga bisa diatur langsung dari keyboard (menu 4 kotak → Atur tombol sembunyi, atau Fitur+ lewat ikon logo Windows di baris atas)."))
        col.addView(miniPick("Bentuk tombol", Prefs.miniShapeNames, { Prefs.miniShape(this) }, { Prefs.setMiniShape(this, it); miniPrevRefresh() }) { true })
        val prevRow = LinearLayout(this)
        prevRow.orientation = LinearLayout.HORIZONTAL
        prevRow.gravity = Gravity.CENTER
        prevRow.setPadding(0, dp(8), 0, dp(8))
        prevRow.background = rounded(Color.parseColor("#2A2A32"), 12)
        prevRow.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(6), 0, dp(6)) }
        for (hid in listOf(true, false)) {
            val v = android.view.View(this)
            v.layoutParams = LinearLayout.LayoutParams(dp(MiniStyle.widthDp(this, hid)), dp(MiniStyle.heightDp(this, hid))).also { it.setMargins(dp(16), dp(6), dp(16), dp(6)) }
            prevRow.addView(v)
            if (hid) miniPrevH = v else miniPrevI = v
        }
        col.addView(label("Pratinjau (kiri: tersembunyi, kanan: ikon kecil):"))
        col.addView(prevRow)
        col.addView(label("Warna tombol (kode hex, kosong = ikut warna tema)"))
        val miniColorEt = EditText(this)
        miniColorEt.setSingleLine(true)
        miniColorEt.hint = "#7C5CFF"
        miniColorEt.setText(Prefs.miniColor(this))
        miniColorEt.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val v = s?.toString()?.trim() ?: ""
                if (v.isEmpty()) { Prefs.setMiniColor(this@SettingsActivity, ""); miniPrevRefresh() }
                else if (Prefs.parseHex(v) != null) {
                    Prefs.setMiniColor(this@SettingsActivity, if (v.startsWith("#")) v else "#$v")
                    miniPrevRefresh()
                }
            }
        })
        col.addView(miniColorEt)
        val quick = Button(this); quick.isAllCaps = false; quick.text = "Pilih warna cepat"
        quick.setOnClickListener {
            android.app.AlertDialog.Builder(this).setTitle("Warna tombol")
                .setItems(MiniStyle.swatches.map { it.second }.toTypedArray()) { _, which -> miniColorEt.setText(MiniStyle.swatches[which].first) }
                .setNegativeButton("Batal", null).show()
        }
        col.addView(quick)
        slider(col, "Opasitas tombol tersembunyi", "%", 3, 100, { Prefs.miniAlpha(this, true) }) { Prefs.setMiniAlpha(this, true, it); miniPrevRefresh() }
        slider(col, "Ukuran tombol tersembunyi", " dp", 28, 120, { Prefs.miniSize(this, true) }) { Prefs.setMiniSize(this, true, it); miniPrevRefresh() }
        slider(col, "Opasitas ikon kecil", "%", 3, 100, { Prefs.miniAlpha(this, false) }) { Prefs.setMiniAlpha(this, false, it); miniPrevRefresh() }
        slider(col, "Ukuran ikon kecil", " dp", 28, 120, { Prefs.miniSize(this, false) }) { Prefs.setMiniSize(this, false, it); miniPrevRefresh() }
        miniPrevRefresh()
        miniRefresh()
        refreshPerm()

        col = card("💾 Simpan")
        val save = Button(this); save.text = "Simpan"
        save.setOnClickListener {
            Prefs.setModel(this, model.text.toString().trim().ifBlank { "llama-3.1-8b-instant" })
            Prefs.setLang(this, lang.text.toString().trim().ifBlank { "English" })
            Prefs.setHaptic(this, hap.isChecked)
            Prefs.setSound(this, sound.isChecked)
            Prefs.setSuggest(this, sug.isChecked)
            Prefs.setNumRow(this, numRow.isChecked)
            Prefs.setAutoCap(this, autoCap.isChecked)
            Prefs.setDblSpace(this, dbl.isChecked)
            Prefs.setSnippets(this, snip.text.toString())
            Prefs.setCustom(this, custom.text.toString().trim())
            save.text = "Tersimpan ✓"
        }
        col.addView(save)

        col = card("✍️ Coba ketik di sini")
        col.addView(EditText(this))

        val sv = ScrollView(this)
        sv.setBackgroundColor(cBg)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(page)
        decorate(page)
        applyStatus()
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        window.decorView.systemUiVisibility = 0
        sv.alpha = 0f
        setContentView(sv)
        sv.animate().alpha(1f).setDuration(250).start()
    }
}
