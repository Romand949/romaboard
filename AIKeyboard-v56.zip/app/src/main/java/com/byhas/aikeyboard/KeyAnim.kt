package com.byhas.aikeyboard

import android.animation.ObjectAnimator
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.InsetDrawable
import android.graphics.drawable.RippleDrawable
import android.view.View
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.view.MotionEvent
import androidx.core.graphics.ColorUtils

/** Kumpulan animasi keyboard: tekan tombol, pindah layar, dan saat keyboard muncul. */
object KeyAnim {
    val pressNames = listOf(
        "Membal (bawaan)", "Halus", "Jelly", "Pop-up besar", "Miring 3D",
        "Tekan dalam", "Goyang miring", "Getar", "Riak cahaya", "Tanpa animasi", "iPhone (halus)", "iOS Spring (super smooth)"
    )
    val transNames = listOf(
        "Naik & pudar (bawaan)", "Geser dari kanan", "Zoom masuk", "Lipat 3D",
        "Jatuh membal", "Pudar saja", "Tanpa animasi", "iOS (geser + pegas)"
    )
    val appearNames = listOf(
        "Tanpa animasi (bawaan)", "Naik dari bawah", "Pudar", "Zoom dari bawah",
        "Membal naik", "Membuka dari bawah", "iOS naik halus"
    )
    const val RIPPLE = 8

    /** Kurva standar iOS (cepat di awal, melambat sangat halus di akhir). */
    val iosCurve: PathInterpolator by lazy { PathInterpolator(0.32f, 0.72f, 0f, 1f) }

    /** Sentuhan ala iOS: mengecil cepat saat ditekan, lalu kembali dengan pegas lembut. */
    fun attachSpring(v: View, scale: Float = 0.94f) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { view.animate().cancel(); view.animate().scaleX(scale).scaleY(scale).setDuration(90).setInterpolator(iosCurve).start() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { view.animate().cancel(); view.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(SpringInterpolator()).start() }
            }
            false
        }
    }

    private var twist = 1f

    private fun dur(ms: Long, speed: Float): Long {
        val sp = if (speed <= 0f) 1f else speed
        return (ms / sp).toLong().coerceAtLeast(1L)
    }

    /** Bungkus latar tombol dengan efek riak yang terpotong mengikuti sudut tombol. */
    fun ripple(content: Drawable, radiusPx: Float, l: Int, t: Int, r: Int, b: Int, accent: Int): Drawable {
        val m = GradientDrawable()
        m.cornerRadius = radiusPx
        m.setColor(Color.WHITE)
        val mask = InsetDrawable(m, l, t, r, b)
        return RippleDrawable(ColorStateList.valueOf(ColorUtils.setAlphaComponent(accent, 170)), content, mask)
    }

    fun press(v: View, down: Boolean, style: Int, speed: Float, x: Float, y: Float) {
        v.animate().cancel()
        val dens = v.resources.displayMetrics.density
        v.cameraDistance = 9000f * dens
        val a = v.animate()
        when (style) {
            0 -> if (down) a.scaleX(0.9f).scaleY(0.9f).setDuration(dur(50, speed)).start()
                 else a.scaleX(1f).scaleY(1f).setDuration(dur(150, speed)).setInterpolator(OvershootInterpolator(2f)).start()
            1 -> if (down) a.scaleX(0.96f).scaleY(0.96f).alpha(0.8f).setDuration(dur(70, speed)).start()
                 else a.scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur(130, speed)).setInterpolator(DecelerateInterpolator()).start()
            2 -> if (down) a.scaleX(1.10f).scaleY(0.84f).setDuration(dur(70, speed)).start()
                 else a.scaleX(1f).scaleY(1f).setDuration(dur(300, speed)).setInterpolator(OvershootInterpolator(4f)).start()
            3 -> if (down) a.scaleX(1.16f).scaleY(1.16f).translationY(-3f * dens).translationZ(8f * dens).setDuration(dur(70, speed)).start()
                 else a.scaleX(1f).scaleY(1f).translationY(0f).translationZ(0f).setDuration(dur(160, speed)).setInterpolator(DecelerateInterpolator()).start()
            4 -> if (down) a.rotationX(22f).scaleX(0.94f).scaleY(0.94f).setDuration(dur(80, speed)).start()
                 else a.rotationX(0f).scaleX(1f).scaleY(1f).setDuration(dur(220, speed)).setInterpolator(OvershootInterpolator(2.5f)).start()
            5 -> if (down) a.translationY(2.5f * dens).scaleX(0.97f).scaleY(0.9f).setDuration(dur(60, speed)).start()
                 else a.translationY(0f).scaleX(1f).scaleY(1f).setDuration(dur(180, speed)).setInterpolator(OvershootInterpolator(2.2f)).start()
            6 -> if (down) { twist = -twist; a.rotation(7f * twist).scaleX(0.93f).scaleY(0.93f).setDuration(dur(70, speed)).start() }
                 else a.rotation(0f).scaleX(1f).scaleY(1f).setDuration(dur(220, speed)).setInterpolator(OvershootInterpolator(3f)).start()
            7 -> if (down) {
                v.scaleX = 1f; v.scaleY = 1f
                ObjectAnimator.ofFloat(v, "translationX", 0f, -3f * dens, 3f * dens, -2f * dens, 2f * dens, 0f)
                    .setDuration(dur(160, speed)).start()
            }
            10 -> if (down) a.scaleX(0.97f).scaleY(0.97f).setDuration(dur(40, speed)).start()
                  else a.scaleX(1f).scaleY(1f).setDuration(dur(110, speed)).setInterpolator(DecelerateInterpolator()).start()
            11 -> if (down) a.scaleX(0.93f).scaleY(0.93f).setDuration(dur(70, speed)).setInterpolator(iosCurve).start()
                  else a.scaleX(1f).scaleY(1f).setDuration(dur(380, speed)).setInterpolator(SpringInterpolator()).start()
            RIPPLE -> {
                if (down) v.drawableHotspotChanged(x, y)
                v.isPressed = down
                if (down) a.scaleX(0.97f).scaleY(0.97f).setDuration(dur(60, speed)).start()
                else a.scaleX(1f).scaleY(1f).setDuration(dur(120, speed)).start()
            }
            else -> { v.scaleX = 1f; v.scaleY = 1f }
        }
    }

    fun transition(v: View, style: Int, speed: Float, dens: Float) {
        v.animate().cancel()
        v.scaleX = 1f; v.scaleY = 1f; v.rotationX = 0f; v.translationX = 0f; v.translationY = 0f; v.alpha = 1f
        v.pivotX = v.width / 2f; v.pivotY = v.height / 2f
        v.cameraDistance = 9000f * dens
        val a = v.animate()
        when (style) {
            0 -> { v.alpha = 0f; v.translationY = 10f * dens
                a.alpha(1f).translationY(0f).setDuration(dur(170, speed)).setInterpolator(DecelerateInterpolator()).start() }
            1 -> { v.alpha = 0f; v.translationX = 40f * dens
                a.alpha(1f).translationX(0f).setDuration(dur(210, speed)).setInterpolator(DecelerateInterpolator()).start() }
            2 -> { v.alpha = 0f; v.scaleX = 0.85f; v.scaleY = 0.85f
                a.alpha(1f).scaleX(1f).scaleY(1f).setDuration(dur(240, speed)).setInterpolator(OvershootInterpolator(1.3f)).start() }
            3 -> { v.pivotY = 0f; v.rotationX = -75f; v.alpha = 0f
                a.rotationX(0f).alpha(1f).setDuration(dur(300, speed)).setInterpolator(DecelerateInterpolator()).start() }
            4 -> { v.alpha = 0f; v.translationY = -34f * dens
                a.alpha(1f).translationY(0f).setDuration(dur(420, speed)).setInterpolator(BounceInterpolator()).start() }
            5 -> { v.alpha = 0f; a.alpha(1f).setDuration(dur(190, speed)).start() }
            7 -> { v.alpha = 0f; v.translationX = 26f * dens; v.scaleX = 0.985f; v.scaleY = 0.985f
                a.alpha(1f).translationX(0f).scaleX(1f).scaleY(1f).setDuration(dur(340, speed)).setInterpolator(iosCurve).start() }
            else -> {}
        }
    }

    fun appear(v: View, style: Int, speed: Float, dens: Float) {
        v.animate().cancel()
        v.scaleX = 1f; v.scaleY = 1f; v.translationX = 0f; v.translationY = 0f; v.alpha = 1f
        if (style == 0) return
        v.pivotX = v.width / 2f
        v.pivotY = if (v.height > 0) v.height.toFloat() else 200f * dens
        val a = v.animate()
        when (style) {
            1 -> { v.translationY = 140f * dens; v.alpha = 0.4f
                a.translationY(0f).alpha(1f).setDuration(dur(260, speed)).setInterpolator(DecelerateInterpolator()).start() }
            2 -> { v.alpha = 0f; a.alpha(1f).setDuration(dur(220, speed)).start() }
            3 -> { v.scaleX = 0.88f; v.scaleY = 0.88f; v.alpha = 0f
                a.scaleX(1f).scaleY(1f).alpha(1f).setDuration(dur(240, speed)).setInterpolator(OvershootInterpolator(1.1f)).start() }
            4 -> { v.translationY = 90f * dens
                a.translationY(0f).setDuration(dur(340, speed)).setInterpolator(OvershootInterpolator(1.8f)).start() }
            5 -> { v.scaleY = 0.2f; v.alpha = 0f
                a.scaleY(1f).alpha(1f).setDuration(dur(260, speed)).setInterpolator(DecelerateInterpolator()).start() }
            6 -> { v.translationY = 48f * dens; v.alpha = 0f
                a.translationY(0f).alpha(1f).setDuration(dur(380, speed)).setInterpolator(iosCurve).start() }
        }
    }
}

/** Pegas teredam: melewati target sedikit lalu mengendap, seperti animasi pegas iOS. */
class SpringInterpolator(private val damping: Float = 5.5f, private val freq: Float = 11f) : android.view.animation.Interpolator {
    override fun getInterpolation(t: Float): Float {
        if (t >= 1f) return 1f
        return (1.0 - Math.exp((-damping * t).toDouble()) * Math.cos((freq * t).toDouble())).toFloat()
    }
}
