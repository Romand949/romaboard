package com.byhas.aikeyboard

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

/** Latar keyboard dari foto: memenuhi area (center-crop) lalu digelapkan sedikit supaya tulisan tetap terbaca. */
class CropBgDrawable(private val bmp: Bitmap, dim: Int) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shade = Paint().apply { color = Color.argb(dim.coerceIn(0, 90) * 255 / 100, 0, 0, 0) }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.width() <= 0 || b.height() <= 0) return
        val s = Math.max(b.width().toFloat() / bmp.width, b.height().toFloat() / bmp.height)
        val dw = bmp.width * s
        val dh = bmp.height * s
        val dx = b.left + (b.width() - dw) / 2f
        val dy = b.top + (b.height() - dh) / 2f
        c.save()
        c.clipRect(b)
        c.drawBitmap(bmp, null, RectF(dx, dy, dx + dw, dy + dh), paint)
        c.restore()
        c.drawRect(RectF(b), shade)
    }

    override fun setAlpha(alpha: Int) { paint.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
