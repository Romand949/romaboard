package com.byhas.aikeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

/** Tampilan tombol saat keyboard diperkecil (mode tersembunyi / ikon kecil). Dipakai keyboard dan halaman pengaturan. */
object MiniStyle {
    val swatches = listOf(
        "" to "Tema", "#7C5CFF" to "Ungu", "#2E7DFF" to "Biru", "#27D3C3" to "Tosca", "#22C55E" to "Hijau", "#FACC15" to "Kuning",
        "#F97316" to "Oranye", "#EF4444" to "Merah", "#E94B83" to "Pink", "#FFFFFF" to "Putih", "#808080" to "Abu", "#000000" to "Hitam"
    )

    fun color(c: Context, fallback: Int): Int = Prefs.parseHex(Prefs.miniColor(c)) ?: fallback

    fun widthDp(c: Context, hidden: Boolean): Int {
        val s = Prefs.miniSize(c, hidden)
        return if (Prefs.miniShape(c) == 3) s * 2 else s
    }

    fun heightDp(c: Context, hidden: Boolean): Int = Prefs.miniSize(c, hidden)

    /** Latar tombol sesuai bentuk, warna, dan opasitas pilihan. */
    fun background(c: Context, hidden: Boolean, accent: Int, ring: Int): GradientDrawable {
        val d = GradientDrawable()
        val density = c.resources.displayMetrics.density
        val col = color(c, accent)
        val a = (Prefs.miniAlpha(c, hidden) * 255 / 100).coerceIn(0, 255)
        d.setColor(Color.argb(a, Color.red(col), Color.green(col), Color.blue(col)))
        val h = Prefs.miniSize(c, hidden) * density
        when (Prefs.miniShape(c)) {
            0 -> d.shape = GradientDrawable.OVAL
            1 -> { d.shape = GradientDrawable.RECTANGLE; d.cornerRadius = h * 0.28f }
            2 -> { d.shape = GradientDrawable.RECTANGLE; d.cornerRadius = 2f * density }
            else -> { d.shape = GradientDrawable.RECTANGLE; d.cornerRadius = h }
        }
        if (!hidden) d.setStroke((2 * density).toInt(), ring)
        return d
    }

    fun inkFor(c: Context, accent: Int): Int =
        if (androidx.core.graphics.ColorUtils.calculateLuminance(color(c, accent)) > 0.5) Color.BLACK else Color.WHITE
}
