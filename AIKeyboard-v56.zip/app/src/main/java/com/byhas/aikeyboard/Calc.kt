package com.byhas.aikeyboard

/** Kalkulator kecil untuk panel Fitur+: + − × ÷ ( ) dan persen. Mengembalikan null kalau ekspresi belum lengkap atau tidak valid. */
object Calc {
    fun eval(src: String): Double? {
        val s = src.replace('×', '*').replace('÷', '/').replace('−', '-').replace('x', '*').replace(" ", "").replace(',', '.')
        if (s.isEmpty()) return null
        return try {
            val p = Parser(s)
            val v = p.expr()
            if (p.i != s.length) null else if (v.isNaN() || v.isInfinite()) null else v
        } catch (e: Exception) { null }
    }

    fun fmt(d: Double): String {
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return java.math.BigDecimal(d).round(java.math.MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var i = 0
        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (peek() == '*' || peek() == '/') {
                val op = s[i++]
                val r = factor()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        private fun factor(): Double {
            if (peek() == '-') { i++; return -factor() }
            if (peek() == '+') { i++; return factor() }
            var v = primary()
            while (peek() == '%') { i++; v /= 100.0 }
            return v
        }

        private fun primary(): Double {
            if (peek() == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("kurung")
                i++
                return v
            }
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            if (st == i) throw IllegalArgumentException("angka")
            return s.substring(st, i).toDouble()
        }
    }
}
